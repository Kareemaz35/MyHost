# ============================================================
# main.py — نقطة الدخول | روبوت الذهب (Bybit)
# ============================================================
# python main.py --demo          ← محاكاة بدون تنفيذ صفقات حقيقية
# python main.py                 ← تداول حقيقي على Bybit
# python main.py --train-only    ← تدريب النموذج فقط
# python main.py --backtest      ← Backtest 5 سنوات
# python main.py --test-telegram ← اختبار تيليجرام
# ============================================================

import argparse, schedule, time, sys, os
from datetime import datetime
from loguru import logger

import config
from model.trainer              import full_training_pipeline
from model.predictor            import TradingPredictor
from model.self_learning        import SelfLearning
from strategies.ai_strategy     import AITradingStrategy
from strategies.risk_manager    import RiskManager
from broker.bybit_connector     import connect, disconnect, account_summary
from notifications.telegram_bot import (
    notify_bot_started, notify_daily_report, notify_error,
    notify_backtest_results, test_connection, poll_commands, set_risk_manager,
)

# ──────────────────────────────────────────────────────────
# إعداد السجلات
# ──────────────────────────────────────────────────────────
os.makedirs("logs", exist_ok=True)
logger.remove()
logger.add(sys.stdout,
    format="<green>{time:HH:mm:ss}</green> | <level>{level:<8}</level> | {message}",
    colorize=True)
logger.add("logs/gold_bot_{time:YYYY-MM-DD}.log",
    rotation="00:00", retention="30 days", level="DEBUG", encoding="utf-8")


# ──────────────────────────────────────────────────────────
# State مشترك
# ──────────────────────────────────────────────────────────
strategy    = AITradingStrategy()
risk_mgr    = strategy.risk_mgr
self_learn  = strategy.self_learn


# ──────────────────────────────────────────────────────────
# دورة الفحص الرئيسية
# ──────────────────────────────────────────────────────────
def scan_cycle(demo_mode: bool = True):
    logger.info(f"\n{'─'*50}")
    logger.info(f"🔍 فحص السوق | {datetime.now().strftime('%H:%M:%S')} | {'Demo' if demo_mode else 'Live'}")
    try:
        result = strategy.scan_and_trade(demo_mode=demo_mode)
        action = result.get("action", "HOLD")
        reason = result.get("reason", "")
        conf   = result.get("confidence", 0)

        if action != "HOLD":
            logger.info(f"✅ إشارة: {action} | ثقة: {conf*100:.1f}% | {reason}")
        else:
            logger.info(f"⏸️  HOLD | {reason}")

        # فحص أوامر تيليجرام
        poll_commands(demo_mode)

        # تحقق من إعادة التدريب
        if self_learn.should_retrain():
            logger.info("🔄 إعادة التدريب التلقائي...")
            full_training_pipeline()
            strategy.predictor.load()

    except Exception as e:
        msg = f"خطأ في دورة الفحص: {e}"
        logger.error(msg)
        notify_error(msg)


def send_daily_report():
    try:
        acc   = account_summary()
        s     = risk_mgr.get_summary()
        stats = self_learn.get_statistics()
        notify_daily_report(
            balance       = acc.get("balance", 0),
            equity        = acc.get("equity",  0),
            daily_profit  = s["daily_pnl"],
            total_trades  = s["trades_today"],
            winning_trades= s["wins_today"],
        )
        risk_mgr.reset_daily()
    except Exception as e:
        logger.error(f"خطأ في التقرير اليومي: {e}")


# ──────────────────────────────────────────────────────────
# نقطة الدخول
# ──────────────────────────────────────────────────────────
def main():
    parser = argparse.ArgumentParser(description="روبوت الذهب AI | Bybit")
    parser.add_argument("--demo",          action="store_true", help="محاكاة بدون صفقات حقيقية")
    parser.add_argument("--train-only",    action="store_true", help="تدريب النموذج فقط")
    parser.add_argument("--backtest",      action="store_true", help="Backtest 5 سنوات")
    parser.add_argument("--test-telegram", action="store_true", help="اختبار تيليجرام")
    args = parser.parse_args()

    # ── اختبار تيليجرام ──
    if args.test_telegram:
        test_connection()
        return

    # ── تدريب فقط ──
    if args.train_only:
        logger.info("🏋️ تدريب النموذج على بيانات الذهب (5 سنوات)...")
        metrics = full_training_pipeline()
        logger.info(f"✅ اكتمل | Winrate={metrics.get('winrate',0)*100:.1f}% | AUC={metrics.get('auc',0):.3f}")
        return

    # ── Backtest ──
    if args.backtest:
        import joblib
        logger.info("🔬 تشغيل Backtest...")
        if not os.path.exists(config.MODEL_PATH):
            logger.info("📊 تدريب النموذج أولاً...")
            full_training_pipeline()
        model     = joblib.load(config.MODEL_PATH)
        scaler    = joblib.load(config.SCALER_PATH)
        feat_cols = joblib.load(config.FEATURES_PATH)
        from strategies.backtester import run_backtest
        results = run_backtest(model, scaler, feat_cols)
        notify_backtest_results(results)
        return

    # ── الوضع الكامل ──
    demo = args.demo
    mode = "🎭 محاكاة (Demo)" if demo else "🔴 تداول حقيقي"
    logger.info(f"\n{'='*60}")
    logger.info(f"  💰 روبوت الذهب AI | {mode}")
    logger.info(f"  الأصل: {config.SYMBOL}")
    logger.info(f"  الإطار الرئيسي: H{config.TIMEFRAME_PRIMARY}m")
    logger.info(f"  حد الثقة: {config.MIN_CONFIDENCE*100:.0f}%")
    logger.info(f"  وضع Bybit: {'Testnet' if config.BYBIT_TESTNET else 'Real'}")
    logger.info(f"{'='*60}\n")

    # الاتصال بـ Bybit
    connected = connect()
    if not connected:
        if not demo:
            logger.warning("⚠️ فشل الاتصال بـ Bybit — التحويل لـ Demo")
            demo = True
        else:
            logger.info("ℹ️ وضع Demo: لا يحتاج اتصال Bybit")

    # تحميل/تدريب النموذج
    if not os.path.exists(config.MODEL_PATH):
        logger.info("🏋️ تدريب النموذج للمرة الأولى (5 سنوات بيانات)...")
        full_training_pipeline()

    strategy.initialize()
    set_risk_manager(risk_mgr)
    notify_bot_started()

    # فحص فوري
    scan_cycle(demo)

    # ── الجدولة ──
    schedule.every(config.SCAN_INTERVAL_MINUTES).minutes.do(scan_cycle, demo_mode=demo)
    schedule.every(config.RETRAIN_HOURS).hours.do(full_training_pipeline)
    schedule.every().day.at(config.DAILY_REPORT_TIME).do(send_daily_report)

    logger.info(f"⏰ فحص كل {config.SCAN_INTERVAL_MINUTES} دقيقة | Ctrl+C للإيقاف\n")

    try:
        while True:
            schedule.run_pending()
            time.sleep(30)
    except KeyboardInterrupt:
        logger.info("\n🛑 إيقاف البوت")
    finally:
        disconnect()
        logger.info("👋 وداعاً!")


if __name__ == "__main__":
    main()
