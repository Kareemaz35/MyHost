# ============================================================
# indicators/candlestick.py — أنماط الشموع اليابانية
# ============================================================
import pandas as pd
import numpy as np


def add_candlestick_patterns(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or len(df) < 3:
        return df
    df = df.copy()
    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    body  = abs(c - o)
    avg_b = body.rolling(14).mean()

    # Doji
    df["doji"] = (body < avg_b * 0.1).astype(int)

    # Hammer & Shooting Star
    lower_wick = df[["close","open"]].min(axis=1) - l
    upper_wick = h - df[["close","open"]].max(axis=1)
    df["hammer"]        = ((lower_wick > 2*body) & (upper_wick < body) & (body > 0)).astype(int)
    df["shooting_star"] = ((upper_wick > 2*body) & (lower_wick < body) & (body > 0)).astype(int)

    # Engulfing
    prev_body  = body.shift(1)
    prev_bull  = (df["close"].shift(1) > df["open"].shift(1))
    bull_eng   = (~prev_bull) & (c > o) & (c > df["open"].shift(1)) & (o < df["close"].shift(1)) & (body > prev_body)
    bear_eng   = prev_bull & (c < o) & (c < df["open"].shift(1)) & (o > df["close"].shift(1)) & (body > prev_body)
    df["bullish_engulfing"] = bull_eng.astype(int)
    df["bearish_engulfing"] = bear_eng.astype(int)

    # Marubozu (شمعة قوية بلا ظلال)
    df["marubozu_bull"] = ((c > o) & (lower_wick < body*0.05) & (upper_wick < body*0.05) & (body > avg_b)).astype(int)
    df["marubozu_bear"] = ((c < o) & (lower_wick < body*0.05) & (upper_wick < body*0.05) & (body > avg_b)).astype(int)

    # Three White Soldiers / Three Black Crows
    b1 = (c > o) & (body > avg_b)
    b2 = b1.shift(1).fillna(False)
    b3 = b1.shift(2).fillna(False)
    df["three_soldiers"] = (b1 & b2 & b3).astype(int)

    bear1 = (c < o) & (body > avg_b)
    bear2 = bear1.shift(1).fillna(False)
    bear3 = bear1.shift(2).fillna(False)
    df["three_crows"] = (bear1 & bear2 & bear3).astype(int)

    # Morning Star / Evening Star
    mid_doji = df["doji"].shift(1).fillna(0)
    df["morning_star"] = ((c.shift(2) < o.shift(2)) & mid_doji.astype(bool) & (c > o) & (c > (o.shift(2)+c.shift(2))/2)).astype(int)
    df["evening_star"] = ((c.shift(2) > o.shift(2)) & mid_doji.astype(bool) & (c < o) & (c < (o.shift(2)+c.shift(2))/2)).astype(int)

    # إشارة مجمّعة
    df["candle_bull_score"] = (
        df["hammer"] + df["bullish_engulfing"] + df["marubozu_bull"] +
        df["three_soldiers"] + df["morning_star"]
    )
    df["candle_bear_score"] = (
        df["shooting_star"] + df["bearish_engulfing"] + df["marubozu_bear"] +
        df["three_crows"] + df["evening_star"]
    )
    return df
