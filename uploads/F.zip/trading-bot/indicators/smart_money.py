# ============================================================
# indicators/smart_money.py — Smart Money Concepts (SMC)
# ============================================================
# Order Blocks, Break of Structure, Fair Value Gaps, Liquidity
# ============================================================
import pandas as pd
import numpy as np


def add_smc_indicators(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or len(df) < 20:
        return df
    df = df.copy()

    df = _break_of_structure(df)
    df = _order_blocks(df)
    df = _fair_value_gaps(df)
    df = _liquidity_levels(df)
    df = _market_structure(df)
    return df


def _break_of_structure(df: pd.DataFrame) -> pd.DataFrame:
    """كسر الهيكل السعري (BOS)"""
    swing_high = df["high"].rolling(5, center=True).max()
    swing_low  = df["low"].rolling(5, center=True).min()

    bos_bull = (df["close"] > swing_high.shift(1)) & (df["close"].shift(1) <= swing_high.shift(2))
    bos_bear = (df["close"] < swing_low.shift(1))  & (df["close"].shift(1) >= swing_low.shift(2))

    df["bos_bullish"] = bos_bull.astype(int)
    df["bos_bearish"] = bos_bear.astype(int)
    df["swing_high"]  = swing_high
    df["swing_low"]   = swing_low
    return df


def _order_blocks(df: pd.DataFrame, lookback: int = 10) -> pd.DataFrame:
    """
    Order Block: آخر شمعة هابطة قبل حركة صعودية قوية (Bull OB)
                 آخر شمعة صاعدة قبل حركة هبوطية قوية (Bear OB)
    """
    body = abs(df["close"] - df["open"])
    avg_body = body.rolling(20).mean()

    bull_move = (df["close"] > df["open"]) & (body > avg_body * 1.5)
    bear_move = (df["close"] < df["open"]) & (body > avg_body * 1.5)

    df["bull_ob"] = 0
    df["bear_ob"] = 0

    for i in range(2, len(df)):
        if bull_move.iloc[i]:
            j = i - 1
            while j >= max(0, i - lookback):
                if df["close"].iloc[j] < df["open"].iloc[j]:
                    df.at[df.index[j], "bull_ob"] = 1
                    break
                j -= 1
        if bear_move.iloc[i]:
            j = i - 1
            while j >= max(0, i - lookback):
                if df["close"].iloc[j] > df["open"].iloc[j]:
                    df.at[df.index[j], "bear_ob"] = 1
                    break
                j -= 1

    # هل السعر الحالي عند Order Block؟
    recent_bull_ob_high = df[df["bull_ob"] == 1]["high"].rolling(5).max().reindex(df.index, method="ffill")
    recent_bull_ob_low  = df[df["bull_ob"] == 1]["low"].rolling(5).min().reindex(df.index, method="ffill")
    df["near_bull_ob"]  = ((df["close"] >= recent_bull_ob_low.fillna(0)) &
                           (df["close"] <= recent_bull_ob_high.fillna(0))).astype(int)
    return df


def _fair_value_gaps(df: pd.DataFrame) -> pd.DataFrame:
    """
    Fair Value Gap (FVG): فجوة سعرية بين شمعتين
    FVG صاعد: low[i] > high[i-2]
    FVG هابط: high[i] < low[i-2]
    """
    df["fvg_bull"] = (df["low"] > df["high"].shift(2)).astype(int)
    df["fvg_bear"] = (df["high"] < df["low"].shift(2)).astype(int)
    return df


def _liquidity_levels(df: pd.DataFrame, swing: int = 20) -> pd.DataFrame:
    """
    مستويات السيولة: Swing Highs/Lows كأهداف محتملة
    """
    df["liq_high"] = df["high"].rolling(swing).max()
    df["liq_low"]  = df["low"].rolling(swing).min()

    # بُعد السعر عن مستويات السيولة (%)
    df["dist_liq_high"] = (df["liq_high"] - df["close"]) / df["close"] * 100
    df["dist_liq_low"]  = (df["close"] - df["liq_low"])  / df["close"] * 100
    return df


def _market_structure(df: pd.DataFrame) -> pd.DataFrame:
    """
    هيكل السوق: HH/HL (صاعد) أو LH/LL (هابط)
    """
    hi20 = df["high"].rolling(20).max()
    lo20 = df["low"].rolling(20).min()

    df["hh"] = (df["high"] == hi20).astype(int)   # Higher High
    df["ll"] = (df["low"]  == lo20).astype(int)   # Lower Low

    # درجة SMC الكلية
    df["smc_bull_score"] = df["bos_bullish"] + df["bull_ob"] + df["fvg_bull"] + df["near_bull_ob"]
    df["smc_bear_score"] = df["bos_bearish"] + df["bear_ob"] + df["fvg_bear"]
    return df
