# ============================================================
# indicators/technical.py — RSI, MACD, EMA200, ATR, Volume, ADX
# ============================================================
import pandas as pd
import numpy as np
from loguru import logger


def add_all_indicators(df: pd.DataFrame) -> pd.DataFrame:
    if df.empty or len(df) < 30:
        return df
    df = df.copy()
    c, h, l, v = df["close"], df["high"], df["low"], df["volume"]

    # RSI
    df["rsi"]      = _rsi(c, 14)
    df["rsi_fast"] = _rsi(c, 7)

    # MACD
    ema12 = c.ewm(span=12, adjust=False).mean()
    ema26 = c.ewm(span=26, adjust=False).mean()
    df["macd"]        = ema12 - ema26
    df["macd_signal"] = df["macd"].ewm(span=9, adjust=False).mean()
    df["macd_hist"]   = df["macd"] - df["macd_signal"]

    # EMAs
    for p in [9, 21, 50, 100, 200]:
        df[f"ema_{p}"] = c.ewm(span=p, adjust=False).mean()

    # ATR
    df["atr"]     = _atr(df, 14)
    df["atr_pct"] = df["atr"] / c * 100

    # Bollinger Bands
    sma20 = c.rolling(20).mean()
    std20 = c.rolling(20).std()
    df["bb_upper"] = sma20 + 2 * std20
    df["bb_lower"] = sma20 - 2 * std20
    df["bb_mid"]   = sma20
    df["bb_width"] = (df["bb_upper"] - df["bb_lower"]) / (sma20 + 1e-9)
    df["bb_pct"]   = (c - df["bb_lower"]) / (df["bb_upper"] - df["bb_lower"] + 1e-9)

    # Volume
    df["volume_ma"]    = v.rolling(20).mean()
    df["volume_ratio"] = v / (df["volume_ma"] + 1e-9)
    df["volume_spike"] = (df["volume_ratio"] > 2.0).astype(int)

    # ADX
    df["adx"], df["di_plus"], df["di_minus"] = _adx(df, 14)
    df["trending"] = (df["adx"] > 25).astype(int)

    # Stochastic
    df["stoch_k"], df["stoch_d"] = _stochastic(df, 14, 3)

    # CCI
    tp = (h + l + c) / 3
    df["cci"] = (tp - tp.rolling(20).mean()) / (0.015 * tp.rolling(20).std() + 1e-9)

    # Momentum
    df["momentum"] = c - c.shift(10)
    df["roc"]      = c.pct_change(10) * 100

    # Price Action
    df["body"]       = abs(c - df["open"])
    df["upper_wick"] = h - df[["close","open"]].max(axis=1)
    df["lower_wick"] = df[["close","open"]].min(axis=1) - l
    df["is_bullish"] = (c > df["open"]).astype(int)

    # S/R proximity
    df["high_20"]  = h.rolling(20).max()
    df["low_20"]   = l.rolling(20).min()
    df["dist_res"] = (df["high_20"] - c) / c * 100
    df["dist_sup"] = (c - df["low_20"]) / c * 100

    return df.dropna()


def _rsi(s: pd.Series, p: int = 14) -> pd.Series:
    d = s.diff()
    g = d.clip(lower=0).rolling(p).mean()
    ls= (-d.clip(upper=0)).rolling(p).mean()
    return 100 - (100 / (1 + g / (ls + 1e-9)))


def _atr(df: pd.DataFrame, p: int = 14) -> pd.Series:
    tr = pd.concat([
        df["high"] - df["low"],
        (df["high"] - df["close"].shift()).abs(),
        (df["low"]  - df["close"].shift()).abs(),
    ], axis=1).max(axis=1)
    return tr.rolling(p).mean()


def _adx(df: pd.DataFrame, p: int = 14):
    h, l, c = df["high"], df["low"], df["close"]
    tr = pd.concat([h-l,(h-c.shift()).abs(),(l-c.shift()).abs()],axis=1).max(axis=1)
    up, dn = h.diff(), -l.diff()
    dmp = np.where((up > dn) & (up > 0), up, 0.0)
    dmm = np.where((dn > up) & (dn > 0), dn, 0.0)
    atr_s  = pd.Series(tr.values, index=df.index).rolling(p).mean()
    dip    = 100 * pd.Series(dmp, index=df.index).rolling(p).mean() / (atr_s + 1e-9)
    dim    = 100 * pd.Series(dmm, index=df.index).rolling(p).mean() / (atr_s + 1e-9)
    dx     = 100 * (dip - dim).abs() / (dip + dim + 1e-9)
    return dx.rolling(p).mean(), dip, dim


def _stochastic(df: pd.DataFrame, kp: int = 14, dp: int = 3):
    lo = df["low"].rolling(kp).min()
    hi = df["high"].rolling(kp).max()
    k  = 100 * (df["close"] - lo) / (hi - lo + 1e-9)
    return k, k.rolling(dp).mean()


def get_market_regime(df: pd.DataFrame) -> str:
    if df.empty or len(df) < 50:
        return "unknown"
    last = df.iloc[-1]
    adx  = last.get("adx", 0)
    e50  = last.get("ema_50",  last["close"])
    e200 = last.get("ema_200", last["close"])
    if adx < 25:
        return "ranging"
    elif last["close"] > e50 > e200:
        return "trending_up"
    elif last["close"] < e50 < e200:
        return "trending_down"
    return "mixed"
