# ============================================================
# news/scraper.py — Gold News Scraper
# ============================================================
import requests
from bs4 import BeautifulSoup
import feedparser
from datetime import datetime, timedelta
from loguru import logger
import re

HEADERS = {"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36"}
TIMEOUT = 10

GOLD_KEYWORDS = [
    "gold", "xau", "bullion", "precious metal", "ذهب",
    "federal reserve", "fed", "inflation", "cpi", "ppi",
    "interest rate", "dollar", "usd", "dxy", "treasury",
    "geopolit", "war", "conflict", "safe haven",
]

HIGH_IMPACT_KEYWORDS = [
    "fed rate", "interest rate decision", "cpi report", "nonfarm",
    "nfp", "gdp", "fomc", "powell", "yellen",
    "war", "nuclear", "crisis", "crash", "collapse",
]


def _is_gold_related(text: str) -> bool:
    t = text.lower()
    return any(k in t for k in GOLD_KEYWORDS)


def _impact_level(text: str) -> str:
    t = text.lower()
    if any(k in t for k in HIGH_IMPACT_KEYWORDS):
        return "high"
    if any(k in t for k in ["gold", "xau", "silver", "commodit"]):
        return "medium"
    return "low"


def scrape_kitco() -> list[dict]:
    """Kitco Gold News RSS"""
    items = []
    try:
        feed = feedparser.parse("https://www.kitco.com/rss/Lo_RSS20.xml")
        for e in feed.entries[:10]:
            title = e.get("title", "")
            if _is_gold_related(title):
                items.append({
                    "source":    "Kitco",
                    "title":     title,
                    "url":       e.get("link", ""),
                    "time":      datetime(*e.published_parsed[:6]) if hasattr(e, "published_parsed") and e.published_parsed else datetime.utcnow(),
                    "impact":    _impact_level(title),
                    "sentiment": _quick_sentiment(title),
                })
    except Exception as e:
        logger.debug(f"Kitco scrape error: {e}")
    return items


def scrape_forexfactory_calendar() -> list[dict]:
    """ForexFactory Economic Calendar RSS"""
    items = []
    try:
        feed = feedparser.parse("https://nfs.faireconomy.media/ff_calendar_thisweek.xml")
        for e in feed.entries[:20]:
            title   = e.get("title", "")
            country = e.get("country", "")
            impact  = e.get("impact", "").lower()
            if country in ["USD", "US"] and impact in ["high", "medium"]:
                items.append({
                    "source":    "ForexFactory",
                    "title":     title,
                    "url":       e.get("link", ""),
                    "time":      datetime(*e.published_parsed[:6]) if hasattr(e, "published_parsed") and e.published_parsed else datetime.utcnow(),
                    "impact":    impact,
                    "sentiment": "neutral",
                    "is_calendar": True,
                })
    except Exception as e:
        logger.debug(f"ForexFactory scrape error: {e}")
    return items


def scrape_reuters() -> list[dict]:
    """Reuters Markets RSS"""
    items = []
    try:
        feed = feedparser.parse("https://feeds.reuters.com/reuters/businessNews")
        for e in feed.entries[:15]:
            title = e.get("title", "")
            if _is_gold_related(title):
                items.append({
                    "source":    "Reuters",
                    "title":     title,
                    "url":       e.get("link", ""),
                    "time":      datetime(*e.published_parsed[:6]) if hasattr(e, "published_parsed") and e.published_parsed else datetime.utcnow(),
                    "impact":    _impact_level(title),
                    "sentiment": _quick_sentiment(title),
                })
    except Exception as e:
        logger.debug(f"Reuters scrape error: {e}")
    return items


def scrape_investing_gold() -> list[dict]:
    """Investing.com Gold News"""
    items = []
    try:
        r = requests.get(
            "https://www.investing.com/rss/news_301.rss",
            headers=HEADERS, timeout=TIMEOUT
        )
        feed = feedparser.parse(r.text)
        for e in feed.entries[:10]:
            title = e.get("title", "")
            items.append({
                "source":    "Investing.com",
                "title":     title,
                "url":       e.get("link", ""),
                "time":      datetime.utcnow(),
                "impact":    _impact_level(title),
                "sentiment": _quick_sentiment(title),
            })
    except Exception as e:
        logger.debug(f"Investing.com scrape error: {e}")
    return items


def _quick_sentiment(text: str) -> str:
    t = text.lower()
    bull = ["rise","surge","rally","gain","jump","bull","high","strong","up","positive","boost"]
    bear = ["fall","drop","decline","plunge","bear","low","weak","down","negative","crash","sink"]
    bs = sum(1 for w in bull if w in t)
    brs= sum(1 for w in bear if w in t)
    if bs > brs:
        return "bullish"
    elif brs > bs:
        return "bearish"
    return "neutral"


def get_all_gold_news() -> list[dict]:
    """يجمع الأخبار من جميع المصادر."""
    all_news = []
    for scraper in [scrape_kitco, scrape_reuters, scrape_forexfactory_calendar, scrape_investing_gold]:
        try:
            items = scraper()
            all_news.extend(items)
        except Exception:
            pass

    # فرز حسب التوقيت
    all_news.sort(key=lambda x: x.get("time", datetime.min), reverse=True)
    logger.info(f"📰 الأخبار المجموعة: {len(all_news)} خبر")
    return all_news


def has_high_impact_news_soon(minutes: int = 30) -> bool:
    """هل هناك خبر عالي التأثير خلال الـ minutes القادمة؟"""
    now = datetime.utcnow()
    window_end = now + timedelta(minutes=minutes)
    window_start = now - timedelta(minutes=minutes)
    news = get_all_gold_news()
    for item in news:
        if item.get("impact") == "high":
            t = item.get("time", now)
            if window_start <= t <= window_end:
                logger.warning(f"⚠️ خبر عالي التأثير قريب: {item['title']}")
                return True
    return False
