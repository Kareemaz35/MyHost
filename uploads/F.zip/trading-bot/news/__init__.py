from news.analyzer import get_analyzer, GoldNewsAnalyzer
from news.scraper  import get_all_gold_news, has_high_impact_news_soon
