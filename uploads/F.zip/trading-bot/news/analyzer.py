# ============================================================
# news/analyzer.py — تحليل الأخبار وتأثيرها على الذهب
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from datetime import datetime, timedelta
from loguru import logger
from news.scraper import get_all_gold_news, has_high_impact_news_soon
import config


class GoldNewsAnalyzer:
    def __init__(self):
        self._cache       = []
        self._cache_time  = None
        self._cache_ttl   = 15  # دقائق

    def _refresh(self):
        now = datetime.utcnow()
        if self._cache_time and (now - self._cache_time).seconds < self._cache_ttl * 60:
            return
        self._cache      = get_all_gold_news()
        self._cache_time = now

    def get_news_sentiment(self) -> dict:
        """
        يُعيد:
          sentiment_score: -1 (هابط) إلى +1 (صاعد)
          high_impact:     هل هناك خبر عالي التأثير؟
          news_pause:      هل يجب إيقاف التداول؟
          summary:         ملخص نصي
        """
        self._refresh()
        if not self._cache:
            return {"sentiment_score": 0, "high_impact": False, "news_pause": False, "summary": "لا أخبار"}

        bull_count = sum(1 for n in self._cache if n.get("sentiment") == "bullish")
        bear_count = sum(1 for n in self._cache if n.get("sentiment") == "bearish")
        total      = len(self._cache)

        score = (bull_count - bear_count) / (total + 1e-9)
        high_impact = any(n.get("impact") == "high" for n in self._cache[:5])
        news_pause  = has_high_impact_news_soon(config.NEWS_PAUSE_MINUTES)

        return {
            "sentiment_score": round(score, 2),
            "high_impact":     high_impact,
            "news_pause":      news_pause,
            "bull_count":      bull_count,
            "bear_count":      bear_count,
            "total_news":      total,
            "summary":         f"صاعد:{bull_count} هابط:{bear_count} | {'⚠️ أخبار قوية' if high_impact else '✅ هادئ'}",
        }

    def should_pause_trading(self) -> bool:
        """هل يجب إيقاف التداول بسبب الأخبار؟"""
        result = self.get_news_sentiment()
        if result["news_pause"]:
            logger.warning(f"⏸️ إيقاف التداول بسبب الأخبار: {result['summary']}")
            return True
        return False

    def get_recent_headlines(self, n: int = 5) -> list[str]:
        self._refresh()
        return [f"[{i['source']}] {i['title']}" for i in self._cache[:n]]


# Singleton
_analyzer = None

def get_analyzer() -> GoldNewsAnalyzer:
    global _analyzer
    if _analyzer is None:
        _analyzer = GoldNewsAnalyzer()
    return _analyzer
