# ============================================================
# setup_check.py — فحص إعداد روبوت الذهب (Bybit)
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.abspath(__file__)))

from loguru import logger
logger.remove()
logger.add(sys.stdout, format="<level>{message}</level>", colorize=True)

OK, WARN, ERR = "✅", "⚠️", "❌"

checks_ok   = []
checks_warn = []
checks_err  = []

def ok(msg):   checks_ok.append(msg);   print(f"  {OK} {msg}")
def warn(msg): checks_warn.append(msg); print(f"  {WARN} {msg}")
def err(msg):  checks_err.append(msg);  print(f"  {ERR} {msg}")

print("\n" + "="*55)
print("  💰 فحص إعداد روبوت الذهب (Bybit Futures)")
print("="*55)

# ── Python ──
print("\n🔧 فحص Python...")
v = sys.version_info
if v.major == 3 and v.minor >= 10:
    ok(f"Python {v.major}.{v.minor}.{v.micro}")
else:
    warn(f"Python {v.major}.{v.minor} (يُفضَّل 3.10+)")

# ── المكتبات ──
print("\n📦 فحص المكتبات...")
libs = {
    "pybit":        ("pybit",         "Bybit API",         True),
    "ccxt":         ("ccxt",          "CCXT للبيانات",     True),
    "pandas":       ("pandas",        "Pandas",            True),
    "numpy":        ("numpy",         "NumPy",             True),
    "yfinance":     ("yfinance",      "Yahoo Finance",     True),
    "ta":           ("ta",            "المؤشرات الفنية",   True),
    "sklearn":      ("sklearn",       "Scikit-learn",      True),
    "xgboost":      ("xgboost",       "XGBoost",           True),
    "joblib":       ("joblib",        "Joblib",            True),
    "requests":     ("requests",      "Requests",          True),
    "bs4":          ("bs4",           "BeautifulSoup",     True),
    "feedparser":   ("feedparser",    "Feedparser",        True),
    "schedule":     ("schedule",      "Schedule",          True),
    "loguru":       ("loguru",        "Loguru",            True),
    "dotenv":       ("dotenv",        "Python-dotenv",     True),
    "telegram":     ("telegram",      "python-telegram-bot",False),
    "aiohttp":      ("aiohttp",       "AioHTTP",           False),
    "matplotlib":   ("matplotlib",    "Matplotlib",        False),
    "websocket":    ("websocket",     "Websocket-client",  False),
}

for imp, (module, name, required) in libs.items():
    try:
        __import__(module)
        ok(name)
    except ImportError:
        if required:
            err(f"{name} — pip install {module.split('.')[0]}")
        else:
            warn(f"{name} (اختياري)")

# ── ملف .env ──
print("\n🔑 فحص .env...")
if os.path.exists(".env"):
    ok(".env موجود")
else:
    err(".env غير موجود — انسخ .env.example وعدّله")

try:
    from dotenv import load_dotenv
    load_dotenv()
    import config

    # Bybit API
    if config.BYBIT_API_KEY and config.BYBIT_API_SECRET:
        ok(f"BYBIT_API_KEY مُعيَّن | وضع: {'Testnet' if config.BYBIT_TESTNET else 'Real'}")
    else:
        warn("BYBIT_API_KEY غير مُعيَّن (مطلوب للتداول الحقيقي)")

    # Telegram
    if config.TELEGRAM_TOKEN and config.TELEGRAM_CHAT_ID:
        ok("TELEGRAM_TOKEN و CHAT_ID مُعيَّنان")
    else:
        warn("TELEGRAM_TOKEN أو CHAT_ID غير مُعيَّن — لن تصلك إشعارات")

except Exception as e:
    err(f"خطأ في تحميل config: {e}")

# ── الاتصال بـ Bybit ──
print("\n🌐 اختبار الاتصال بـ Bybit...")
try:
    from broker.bybit_connector import connect, disconnect, account_summary
    if config.BYBIT_API_KEY:
        if connect():
            acc = account_summary()
            ok(f"Bybit متصل | رصيد: {acc.get('balance', 0):.2f}$ USDT")
            disconnect()
        else:
            warn("تعذّر الاتصال بـ Bybit — تحقق من المفاتيح")
    else:
        warn("Bybit: مفاتيح غير مُعيَّنة — وضع Demo سيعمل")
except Exception as e:
    warn(f"Bybit: {e}")

# ── النموذج ──
print("\n🧠 فحص النموذج...")
if os.path.exists("model/saved_model.pkl"):
    ok("النموذج موجود ومحفوظ")
else:
    warn("النموذج غير مدرَّب — شغّل: python main.py --train-only")

# ── الملخص ──
print(f"\n{'='*55}")
print(f"  {OK} يعمل بشكل صحيح : {len(checks_ok)}")
print(f"  {WARN} تحذيرات (يمكن المتابعة): {len(checks_warn)}")
print(f"  {ERR} أخطاء (يجب الإصلاح): {len(checks_err)}")
print(f"{'='*55}")

if checks_warn:
    print(f"\n{WARN} تحذيرات:")
    for w in checks_warn:
        print(f"  • {w}")

if checks_err:
    print(f"\n{ERR} أخطاء:")
    for e in checks_err:
        print(f"  • {e}")
else:
    print(f"\n🎉 الإعداد صحيح! يمكنك تشغيل الروبوت:")
    print(f"  python main.py --train-only   ← للتدريب")
    print(f"  python main.py --backtest     ← Backtest 5 سنوات")
    print(f"  python main.py --demo         ← للاختبار")
    print(f"  python main.py                ← للتداول الحقيقي")
print("="*55 + "\n")
