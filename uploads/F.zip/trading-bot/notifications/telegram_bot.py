# ============================================================
# notifications/telegram_bot.py — Telegram Bot كامل مع أوامر
# ============================================================
import asyncio
import aiohttp
import requests
from datetime import datetime
from loguru import logger
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

# ──────────────────────────────────────────────────────────
# إرسال الرسائل
# ──────────────────────────────────────────────────────────

def _send(text: str, parse_mode: str = "HTML") -> bool:
    if not config.TELEGRAM_TOKEN or not config.TELEGRAM_CHAT_ID:
        logger.warning("⚠️ TELEGRAM غير مُعيَّن في .env")
        return False
    try:
        url  = f"https://api.telegram.org/bot{config.TELEGRAM_TOKEN}/sendMessage"
        resp = requests.post(url, json={
            "chat_id": config.TELEGRAM_CHAT_ID,
            "text": text, "parse_mode": parse_mode,
        }, timeout=10)
        return resp.status_code == 200
    except Exception as e:
        logger.error(f"Telegram error: {e}")
        return False


def test_connection() -> bool:
    msg = (
        "🤖 <b>روبوت الذهب — اختبار الاتصال</b>\n"
        f"⏰ {datetime.now().strftime('%Y-%m-%d %H:%M')}\n"
        f"🌐 الوضع: {'Testnet 🧪' if config.BYBIT_TESTNET else 'Real 🔴'}\n"
        "✅ <b>الاتصال يعمل بشكل صحيح!</b>"
    )
    ok = _send(msg)
    if ok:
        logger.info("✅ تيليجرام: الاتصال ناجح")
    return ok


# ──────────────────────────────────────────────────────────
# إشعارات التداول
# ──────────────────────────────────────────────────────────

def notify_bot_started():
    mode = "🧪 Testnet" if config.BYBIT_TESTNET else "🔴 تداول حقيقي"
    _send(
        f"🚀 <b>بوت الذهب بدأ العمل</b>\n"
        f"💎 الأصل: <code>{config.SYMBOL}</code>\n"
        f"🌐 الوضع: {mode}\n"
        f"⏰ {datetime.now().strftime('%H:%M:%S')}\n"
        f"🎯 حد الثقة: {config.MIN_CONFIDENCE*100:.0f}%"
    )


def notify_signal(
    signal: str, symbol: str, price: float, confidence: float,
    reason: str = "", rsi: float = 0, atr: float = 0,
    regime: str = "", sl: float = 0, tp: float = 0, rr: float = 0,
):
    emoji = "📈" if signal == "BUY" else "📉"
    stars = "⭐" * min(5, int(confidence * 5))
    _send(
        f"{emoji} <b>إشارة {signal} | {symbol}</b>\n"
        f"💰 السعر: <code>{price:.2f}</code>\n"
        f"🎯 ثقة: <b>{confidence*100:.1f}%</b> {stars}\n"
        f"🛡️ SL: <code>{sl:.2f}</code> | TP: <code>{tp:.2f}</code>\n"
        f"⚖️ R:R = 1:{rr:.1f}\n"
        f"📊 RSI: {rsi:.1f} | ATR: {atr:.2f}\n"
        f"🔍 السبب: {reason}\n"
        f"📐 السوق: {regime}"
    )


def notify_trade_opened(side: str, symbol: str, price: float, qty: float, sl: float, tp: float):
    emoji = "🟢" if side == "Buy" else "🔴"
    _send(
        f"{emoji} <b>صفقة مفتوحة!</b>\n"
        f"📌 {side} {qty} لوت {symbol}\n"
        f"💰 سعر الدخول: <code>{price:.2f}</code>\n"
        f"🛡️ SL: <code>{sl:.2f}</code>\n"
        f"🎯 TP: <code>{tp:.2f}</code>"
    )


def notify_trade_closed(side: str, symbol: str, profit: float, entry: float, exit_p: float):
    emoji = "✅" if profit > 0 else "❌"
    result = "ربح" if profit > 0 else "خسارة"
    _send(
        f"{emoji} <b>صفقة مُغلقة | {result}</b>\n"
        f"📌 {side} {symbol}\n"
        f"🔵 دخول: <code>{entry:.2f}</code> → خروج: <code>{exit_p:.2f}</code>\n"
        f"💵 PnL: <b>{'+' if profit > 0 else ''}{profit:.2f}$</b>"
    )


def notify_daily_report(
    balance: float, equity: float, daily_profit: float,
    total_trades: int, winning_trades: int,
):
    winrate = winning_trades / (total_trades + 1e-9) * 100
    emoji   = "📈" if daily_profit >= 0 else "📉"
    _send(
        f"📊 <b>التقرير اليومي</b>\n"
        f"{'─'*25}\n"
        f"💰 الرصيد: <code>{balance:.2f}$</code>\n"
        f"📊 الإكويتي: <code>{equity:.2f}$</code>\n"
        f"{emoji} ربح اليوم: <b>{'+' if daily_profit >= 0 else ''}{daily_profit:.2f}$</b>\n"
        f"🔢 الصفقات: {total_trades} | فائزة: {winning_trades}\n"
        f"🎯 Winrate: {winrate:.1f}%"
    )


def notify_warning(msg: str):
    _send(f"⚠️ <b>تحذير</b>\n{msg}")


def notify_error(msg: str):
    _send(f"🚨 <b>خطأ</b>\n<code>{msg}</code>")


def notify_news_pause(headlines: str):
    _send(
        f"⏸️ <b>إيقاف التداول — أخبار مهمة</b>\n"
        f"📰 {headlines}\n"
        f"⏳ سيستأنف بعد {config.NEWS_PAUSE_MINUTES} دقيقة"
    )


def notify_backtest_results(results: dict):
    _send(
        f"🔬 <b>نتائج Backtest ({config.HISTORICAL_YEARS} سنوات)</b>\n"
        f"{'─'*25}\n"
        f"📊 الصفقات: {results.get('total_trades', 0)}\n"
        f"🎯 Winrate: {results.get('winrate', 0)*100:.1f}%\n"
        f"💰 PnL: {results.get('total_pnl', 0):.2f}$\n"
        f"⚖️ Profit Factor: {results.get('profit_factor', 0):.2f}\n"
        f"📉 Max Drawdown: {results.get('max_drawdown', 0):.1f}%"
    )


# ──────────────────────────────────────────────────────────
# استقبال الأوامر (Polling بسيط)
# ──────────────────────────────────────────────────────────

_last_update_id = 0
_bot_running    = True
_risk_manager   = None  # يُحدَّد من main.py


def set_risk_manager(rm):
    global _risk_manager
    _risk_manager = rm


def poll_commands(demo_mode: bool = True):
    """يفحص الأوامر الواردة من تيليجرام (يُستدعى دورياً)."""
    global _last_update_id, _bot_running

    if not config.TELEGRAM_TOKEN:
        return

    try:
        url  = f"https://api.telegram.org/bot{config.TELEGRAM_TOKEN}/getUpdates"
        resp = requests.get(url, params={"offset": _last_update_id + 1, "timeout": 5}, timeout=10)
        if resp.status_code != 200:
            return

        updates = resp.json().get("result", [])
        for upd in updates:
            _last_update_id = upd["update_id"]
            msg  = upd.get("message", {})
            text = msg.get("text", "").strip().lower()
            _handle_command(text, demo_mode)
    except Exception:
        pass


def _handle_command(cmd: str, demo_mode: bool):
    global _bot_running

    if cmd in ["/start", "/resume"]:
        if _risk_manager:
            _risk_manager.resume_trading()
        _send("▶️ <b>التداول مستأنف</b>")

    elif cmd in ["/stop", "/pause"]:
        if _risk_manager:
            _risk_manager.halt_trading("إيقاف يدوي من تيليجرام")
        _send("⏸️ <b>التداول موقوف</b>")

    elif cmd == "/status":
        if _risk_manager:
            s = _risk_manager.get_summary()
            _send(
                f"📊 <b>الحالة</b>\n"
                f"صفقات اليوم: {s['trades_today']}\n"
                f"ربح اليوم: {s['daily_pnl']:.2f}$\n"
                f"W/L: {s['wins_today']}/{s['losses_today']}\n"
                f"خسائر متتالية: {s['consecutive_losses']}\n"
                f"الحالة: {'⏸️ موقوف' if s['trading_halted'] else '▶️ نشط'}"
            )

    elif cmd == "/help":
        _send(
            "🤖 <b>أوامر البوت</b>\n"
            "/start  — استئناف التداول\n"
            "/stop   — إيقاف التداول\n"
            "/status — عرض الإحصائيات\n"
            "/help   — هذه القائمة"
        )
