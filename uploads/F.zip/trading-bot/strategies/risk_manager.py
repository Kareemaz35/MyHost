# ============================================================
# strategies/risk_manager.py — إدارة المخاطر الصارمة
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

from datetime import datetime, date
from loguru import logger


class RiskManager:
    def __init__(self):
        self.reset_daily()

    def reset_daily(self):
        self._date               = date.today()
        self.daily_pnl           = 0.0
        self.trades_today        = 0
        self.wins_today          = 0
        self.losses_today        = 0
        self.consecutive_losses  = 0
        self.trading_halted      = False
        self.halt_reason         = ""

    def _check_new_day(self):
        if date.today() != self._date:
            logger.info("🌅 يوم جديد — إعادة تعيين إحصائيات المخاطر")
            self.reset_daily()

    def can_open_trade(self, account_balance: float) -> tuple[bool, str]:
        """يُعيد (مسموح, السبب)"""
        self._check_new_day()

        # إيقاف يدوي
        if self.trading_halted:
            return False, f"تداول موقوف: {self.halt_reason}"

        # الخسارة اليومية القصوى
        max_daily_loss = account_balance * (config.MAX_DAILY_LOSS_PERCENT / 100)
        if self.daily_pnl <= -max_daily_loss:
            self.trading_halted = True
            self.halt_reason    = f"الخسارة اليومية وصلت {self.daily_pnl:.2f}$"
            logger.warning(f"🛑 {self.halt_reason}")
            return False, self.halt_reason

        # عدد الصفقات اليومي
        if self.trades_today >= config.MAX_TRADES_PER_DAY:
            return False, f"وصلت الحد اليومي ({config.MAX_TRADES_PER_DAY} صفقات)"

        # سلسلة الخسائر
        if self.consecutive_losses >= config.MAX_CONSECUTIVE_LOSSES:
            self.trading_halted = True
            self.halt_reason    = f"سلسلة {self.consecutive_losses} خسائر متتالية"
            logger.warning(f"🛑 {self.halt_reason}")
            return False, self.halt_reason

        return True, "مسموح"

    def record_trade_open(self):
        self._check_new_day()
        self.trades_today += 1
        logger.info(f"📈 صفقة #{self.trades_today} اليوم")

    def record_trade_close(self, profit: float):
        self._check_new_day()
        self.daily_pnl += profit
        if profit > 0:
            self.wins_today         += 1
            self.consecutive_losses  = 0
        else:
            self.losses_today       += 1
            self.consecutive_losses += 1

        logger.info(
            f"{'✅' if profit > 0 else '❌'} إغلاق صفقة | "
            f"ربح: {profit:.2f}$ | يومي: {self.daily_pnl:.2f}$ | "
            f"W/L: {self.wins_today}/{self.losses_today}"
        )

    def halt_trading(self, reason: str):
        self.trading_halted = True
        self.halt_reason    = reason
        logger.warning(f"🛑 إيقاف يدوي: {reason}")

    def resume_trading(self):
        self.trading_halted = False
        self.halt_reason    = ""
        self.consecutive_losses = 0
        logger.info("▶️ استئناف التداول")

    def get_summary(self) -> dict:
        return {
            "trades_today":       self.trades_today,
            "wins_today":         self.wins_today,
            "losses_today":       self.losses_today,
            "daily_pnl":          self.daily_pnl,
            "consecutive_losses": self.consecutive_losses,
            "trading_halted":     self.trading_halted,
            "halt_reason":        self.halt_reason,
            "winrate_today":      self.wins_today / (self.trades_today + 1e-9),
        }
