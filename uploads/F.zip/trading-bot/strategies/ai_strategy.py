# ============================================================
# strategies/ai_strategy.py — الاستراتيجية الرئيسية (Multi-TF + SMC)
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

from loguru import logger
from datetime import datetime
import pandas as pd

from data.collector         import fetch_ohlcv, fetch_multi_timeframe
from data.preprocessor      import preprocess, get_feature_columns
from indicators.technical   import get_market_regime
from model.predictor        import TradingPredictor
from model.self_learning    import SelfLearning
from strategies.risk_manager import RiskManager
from news.analyzer          import get_analyzer
from broker.bybit_connector import (
    get_current_price, open_trade, close_position,
    get_open_positions, calculate_sl_tp, calculate_qty,
    account_summary,
)
from notifications.telegram_bot import (
    notify_signal, notify_trade_opened, notify_trade_closed,
    notify_warning, notify_news_pause,
)


class AITradingStrategy:
    def __init__(self):
        self.predictor    = TradingPredictor()
        self.risk_mgr     = RiskManager()
        self.self_learn   = SelfLearning()
        self.news_analyzer= get_analyzer()
        self._loaded      = False

    def initialize(self) -> bool:
        self._loaded = self.predictor.load()
        if not self._loaded:
            logger.warning("⚠️ النموذج غير محمّل — سيعمل البوت بعد التدريب")
        return self._loaded

    # ──────────────────────────────────────────────────────
    # فحص السوق (الدالة الرئيسية)
    # ──────────────────────────────────────────────────────

    def scan_and_trade(self, demo_mode: bool = True) -> dict:
        """يفحص السوق ويقرر الدخول أو لا."""
        result = {"action": "HOLD", "reason": "", "confidence": 0}

        # 1. فحص الأخبار
        if self.news_analyzer.should_pause_trading():
            headlines = self.news_analyzer.get_recent_headlines(3)
            notify_news_pause("\n".join(headlines))
            return {**result, "reason": "أخبار عالية التأثير — إيقاف مؤقت"}

        # 2. فحص الصفقات المفتوحة
        positions = get_open_positions()
        if not positions.empty:
            logger.info(f"📊 صفقة مفتوحة بالفعل: {len(positions)} صفقة")
            return {**result, "reason": "يوجد صفقة مفتوحة بالفعل"}

        # 3. فحص إدارة المخاطر
        acc = account_summary()
        balance = acc.get("balance", 0)
        can_trade, reason = self.risk_mgr.can_open_trade(balance)
        if not can_trade:
            logger.info(f"🚫 Risk Manager: {reason}")
            return {**result, "reason": reason}

        # 4. تحليل Multi-Timeframe
        mtf_signal = self._analyze_multi_timeframe()
        if mtf_signal["agreement"] < 2:
            return {**result, "reason": f"لا توافق بين الأطر الزمنية ({mtf_signal['agreement']}/3)"}

        # 5. جلب بيانات الإطار الرئيسي
        df = fetch_ohlcv(timeframe=config.TIMEFRAME_PRIMARY, n_bars=config.BARS_TO_FETCH)
        if df.empty:
            return {**result, "reason": "فشل جلب البيانات"}

        # 6. فحص حالة السوق
        df_proc = preprocess(df.copy())
        if df_proc.empty:
            return {**result, "reason": "فشل معالجة البيانات"}

        regime = get_market_regime(df_proc)
        if regime == "ranging":
            return {**result, "reason": "سوق عرضي — لا تداول"}

        # 7. فحص الحجم
        last = df_proc.iloc[-1]
        vol_ratio = last.get("volume_ratio", 1.0)
        if vol_ratio < config.MIN_VOLUME_RATIO:
            return {**result, "reason": f"حجم تداول ضعيف ({vol_ratio:.2f}x)"}

        # 8. فحص ATR (تقلب معقول)
        atr = float(last.get("atr", 0))
        if atr < config.MIN_ATR_THRESHOLD or atr > config.MAX_ATR_THRESHOLD:
            return {**result, "reason": f"ATR خارج النطاق ({atr:.2f})"}

        # 9. تنبؤ AI
        pred = self.predictor.predict(df)
        confidence = pred["confidence"]
        signal     = pred["signal"]

        # تعديل حد الثقة من التعلم الذاتي
        dynamic_threshold = self.self_learn.get_confidence_adjustment()
        if confidence < dynamic_threshold:
            return {**result, "reason": f"ثقة منخفضة {confidence*100:.0f}% < {dynamic_threshold*100:.0f}%"}

        if signal == "HOLD":
            return {**result, "reason": "النموذج: HOLD", "confidence": confidence}

        # 10. التحقق من توافق الاتجاه مع mtf
        if signal == "BUY" and mtf_signal["direction"] == "bearish":
            return {**result, "reason": "تعارض: AI=BUY لكن MTF=هابط"}
        if signal == "SELL" and mtf_signal["direction"] == "bullish":
            return {**result, "reason": "تعارض: AI=SELL لكن MTF=صاعد"}

        # 11. إرسال الإشارة
        price_info = get_current_price()
        price = price_info.get("last", 0)

        side = "Buy" if signal == "BUY" else "Sell"
        sl_price, tp_price, sl_dist = calculate_sl_tp(side, price, atr)
        rr = (abs(tp_price - price)) / (abs(sl_price - price) + 1e-9)

        if rr < config.MIN_RR_RATIO:
            return {**result, "reason": f"R:R ضعيف ({rr:.1f} < {config.MIN_RR_RATIO})"}

        notify_signal(
            signal=signal, symbol=config.SYMBOL, price=price,
            confidence=confidence, reason=pred["reason"],
            rsi=pred["rsi"], atr=atr, regime=regime,
            sl=sl_price, tp=tp_price, rr=rr,
        )

        if not demo_mode:
            qty = calculate_qty(sl_dist)
            trade_result = open_trade(side=side, qty=qty, sl_price=sl_price, tp_price=tp_price)
            if trade_result["success"]:
                self.risk_mgr.record_trade_open()
                self.self_learn.log_trade({
                    "order_id": trade_result.get("order_id", ""),
                    "signal":   signal, "price": price,
                    "sl": sl_price, "tp": tp_price, "atr": atr,
                    "confidence": confidence, "reason": pred["reason"],
                    "regime": regime, "volume_ratio": vol_ratio,
                    "time": str(datetime.utcnow()),
                })
                notify_trade_opened(signal, config.SYMBOL, price, qty, sl_price, tp_price)
                result["action"] = signal

        return {**result, "action": signal, "confidence": confidence,
                "reason": pred["reason"], "price": price}

    # ──────────────────────────────────────────────────────
    # تحليل متعدد الأطر الزمنية
    # ──────────────────────────────────────────────────────

    def _analyze_multi_timeframe(self) -> dict:
        """
        يحلل الاتجاه في D1, H4, H1.
        يُعيد: {direction, agreement (0-3)}
        """
        directions = {"bullish": 0, "bearish": 0}
        tfs_to_check = [config.TIMEFRAME_TREND, config.TIMEFRAME_CONFIRM, config.TIMEFRAME_PRIMARY]

        for tf in tfs_to_check:
            df = fetch_ohlcv(timeframe=tf, n_bars=100)
            if df.empty or len(df) < 50:
                continue
            df_proc = preprocess(df.copy())
            if df_proc.empty:
                continue
            last  = df_proc.iloc[-1]
            c     = last["close"]
            e50   = last.get("ema_50", c)
            e200  = last.get("ema_200", c)
            macdh = last.get("macd_hist", 0)

            if c > e50 and (c > e200 or macdh > 0):
                directions["bullish"] += 1
            elif c < e50 and (c < e200 or macdh < 0):
                directions["bearish"] += 1

        total   = directions["bullish"] + directions["bearish"]
        if total == 0:
            return {"direction": "neutral", "agreement": 0}

        direction = "bullish" if directions["bullish"] >= directions["bearish"] else "bearish"
        agreement = max(directions["bullish"], directions["bearish"])
        logger.info(f"📐 MTF: {direction} | توافق: {agreement}/{len(tfs_to_check)}")
        return {"direction": direction, "agreement": agreement}
