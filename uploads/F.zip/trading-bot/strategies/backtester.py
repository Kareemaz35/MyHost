# ============================================================
# strategies/backtester.py — Backtesting على بيانات الذهب
# ============================================================
import pandas as pd
import numpy as np
from loguru import logger
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from data.collector    import fetch_ohlcv
from data.preprocessor import preprocess, get_feature_columns


def run_backtest(
    model,
    scaler,
    feat_cols: list[str],
    timeframe: str  = None,
    years:     int  = None,
    min_confidence: float = None,
) -> dict:
    """
    يُشغّل Backtest على بيانات تاريخية للذهب.
    يُعيد: winrate, profit_factor, total_trades, total_pnl, max_drawdown
    """
    tf  = timeframe     or config.DEFAULT_TIMEFRAME
    yrs = years         or config.HISTORICAL_YEARS
    mc  = min_confidence or config.MIN_CONFIDENCE

    logger.info(f"🔄 Backtest | {yrs} سنوات | TF={tf} | Min Confidence={mc}")

    df = fetch_ohlcv(timeframe=tf, n_bars=10000, years=yrs)
    if df.empty:
        return {"error": "لا بيانات للـ Backtest"}

    df = preprocess(df, lookahead=1)
    if df.empty or len(df) < 100:
        return {"error": "بيانات غير كافية"}

    avail = [c for c in feat_cols if c in df.columns]
    X     = scaler.transform(df[avail].values)
    probs = model.predict_proba(X)[:, 1]

    trades     = []
    balance    = 10000.0
    equity_curve = [balance]
    in_trade   = False
    entry_idx  = 0
    entry_price= 0.0
    entry_side = ""

    for i in range(len(df) - 1):
        p   = probs[i]
        row = df.iloc[i]
        atr = row.get("atr", df["close"].iloc[i] * 0.005)

        if not in_trade:
            if p >= mc:
                side        = "BUY"
                entry_price = df["close"].iloc[i+1]
                entry_idx   = i
                sl          = entry_price - atr * config.STOP_LOSS_ATR
                tp          = entry_price + atr * config.TAKE_PROFIT_ATR
                in_trade    = True
                entry_side  = side
                entry_sl    = sl
                entry_tp    = tp
            elif (1-p) >= mc:
                side        = "SELL"
                entry_price = df["close"].iloc[i+1]
                entry_idx   = i
                sl          = entry_price + atr * config.STOP_LOSS_ATR
                tp          = entry_price - atr * config.TAKE_PROFIT_ATR
                in_trade    = True
                entry_side  = side
                entry_sl    = sl
                entry_tp    = tp
        else:
            current = df["close"].iloc[i]
            hit_tp  = (entry_side == "BUY"  and current >= entry_tp) or \
                      (entry_side == "SELL" and current <= entry_tp)
            hit_sl  = (entry_side == "BUY"  and current <= entry_sl) or \
                      (entry_side == "SELL" and current >= entry_sl)

            if hit_tp or hit_sl or (i - entry_idx) > 48:
                if hit_tp:
                    pnl = abs(entry_tp - entry_price)
                elif hit_sl:
                    pnl = -abs(entry_sl - entry_price)
                else:
                    pnl = (current - entry_price) if entry_side == "BUY" else (entry_price - current)

                # حجم ثابت 0.01 للـ backtest (لتبسيط الحساب)
                pnl_usd  = pnl * 0.01 * 100
                balance += pnl_usd
                trades.append({
                    "side": entry_side, "pnl": pnl_usd,
                    "result": "win" if pnl_usd > 0 else "loss",
                    "bars_held": i - entry_idx,
                })
                equity_curve.append(balance)
                in_trade = False

    if not trades:
        return {"error": "لا صفقات في الـ Backtest"}

    wins   = [t for t in trades if t["result"] == "win"]
    losses = [t for t in trades if t["result"] == "loss"]
    total_pnl    = sum(t["pnl"] for t in trades)
    gross_profit = sum(t["pnl"] for t in wins)
    gross_loss   = abs(sum(t["pnl"] for t in losses))
    profit_factor= gross_profit / (gross_loss + 1e-9)

    # Max Drawdown
    equity  = pd.Series(equity_curve)
    peak    = equity.cummax()
    drawdown= ((equity - peak) / peak).min() * 100

    results = {
        "total_trades":   len(trades),
        "wins":           len(wins),
        "losses":         len(losses),
        "winrate":        len(wins) / (len(trades) + 1e-9),
        "total_pnl":      round(total_pnl, 2),
        "profit_factor":  round(profit_factor, 2),
        "max_drawdown":   round(drawdown, 2),
        "avg_bars_held":  round(sum(t["bars_held"] for t in trades) / len(trades), 1),
        "final_balance":  round(balance, 2),
    }

    logger.info(
        f"\n{'='*50}\n"
        f"  📊 نتائج Backtest ({yrs} سنوات)\n"
        f"  الصفقات:    {results['total_trades']}\n"
        f"  Winrate:    {results['winrate']*100:.1f}%\n"
        f"  PnL:        {results['total_pnl']}$\n"
        f"  PF:         {results['profit_factor']}\n"
        f"  Max DD:     {results['max_drawdown']}%\n"
        f"{'='*50}"
    )
    return results
