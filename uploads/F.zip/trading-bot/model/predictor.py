# ============================================================
# model/predictor.py — التنبؤ مع Confidence Score
# ============================================================
import numpy as np
import pandas as pd
import joblib
from loguru import logger
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from data.preprocessor import preprocess, get_feature_columns


class TradingPredictor:
    def __init__(self):
        self.model     = None
        self.scaler    = None
        self.feat_cols = None
        self._loaded   = False

    def load(self) -> bool:
        try:
            if not os.path.exists(config.MODEL_PATH):
                logger.warning("⚠️ النموذج غير موجود — شغّل --train-only أولاً")
                return False
            self.model     = joblib.load(config.MODEL_PATH)
            self.scaler    = joblib.load(config.SCALER_PATH)
            self.feat_cols = joblib.load(config.FEATURES_PATH)
            self._loaded   = True
            logger.info(f"✅ النموذج محمّل ({len(self.feat_cols)} ميزة)")
            return True
        except Exception as e:
            logger.error(f"❌ فشل تحميل النموذج: {e}")
            return False

    def predict(self, df: pd.DataFrame) -> dict:
        """
        يُعيد:
          signal:     "BUY" | "SELL" | "HOLD"
          confidence: 0.0 - 1.0
          buy_prob:   احتمال الشراء
          sell_prob:  احتمال البيع
          reason:     سبب الإشارة
        """
        if not self._loaded:
            if not self.load():
                return self._no_signal("النموذج غير محمّل")

        try:
            df_proc = preprocess(df.copy())
            if df_proc.empty:
                return self._no_signal("بيانات فارغة بعد المعالجة")

            avail = [c for c in self.feat_cols if c in df_proc.columns]
            X     = df_proc[avail].tail(1).values
            X_sc  = self.scaler.transform(X)

            buy_prob  = float(self.model.predict_proba(X_sc)[0][1])
            sell_prob = 1.0 - buy_prob
            last      = df_proc.iloc[-1]

            # تحديد الإشارة
            if buy_prob >= config.MIN_CONFIDENCE:
                signal     = "BUY"
                confidence = buy_prob
            elif sell_prob >= config.MIN_CONFIDENCE:
                signal     = "SELL"
                confidence = sell_prob
            else:
                signal     = "HOLD"
                confidence = max(buy_prob, sell_prob)

            reason = self._build_reason(last, signal)

            return {
                "signal":     signal,
                "confidence": round(confidence, 3),
                "buy_prob":   round(buy_prob, 3),
                "sell_prob":  round(sell_prob, 3),
                "reason":     reason,
                "rsi":        round(float(last.get("rsi", 0)), 1),
                "macd_hist":  round(float(last.get("macd_hist", 0)), 4),
                "atr":        round(float(last.get("atr", 0)), 2),
                "adx":        round(float(last.get("adx", 0)), 1),
                "regime":     self._get_regime(last),
            }
        except Exception as e:
            logger.error(f"خطأ في التنبؤ: {e}")
            return self._no_signal(str(e))

    def _build_reason(self, row, signal: str) -> str:
        parts = []
        rsi = row.get("rsi", 50)
        if signal == "BUY":
            if rsi < 40: parts.append("RSI تشبع بيع")
            if row.get("macd_hist", 0) > 0: parts.append("MACD إيجابي")
            if row.get("bos_bullish", 0): parts.append("BOS صاعد")
            if row.get("candle_bull_score", 0) > 0: parts.append("نمط شموع صاعد")
            if row.get("smc_bull_score", 0) > 1: parts.append("SMC دعم")
        elif signal == "SELL":
            if rsi > 60: parts.append("RSI تشبع شراء")
            if row.get("macd_hist", 0) < 0: parts.append("MACD سلبي")
            if row.get("bos_bearish", 0): parts.append("BOS هابط")
            if row.get("candle_bear_score", 0) > 0: parts.append("نمط شموع هابط")
        if not parts:
            parts.append("تحليل AI")
        return " | ".join(parts)

    def _get_regime(self, row) -> str:
        adx = row.get("adx", 0)
        e50 = row.get("ema_50", 0)
        e200= row.get("ema_200", 0)
        c   = row.get("close", 0)
        if adx < 25: return "ranging"
        if c > e50 > e200: return "trending_up"
        if c < e50 < e200: return "trending_down"
        return "mixed"

    def _no_signal(self, reason: str) -> dict:
        return {"signal":"HOLD","confidence":0.0,"buy_prob":0.0,"sell_prob":0.0,"reason":reason}

    @property
    def is_loaded(self) -> bool:
        return self._loaded
