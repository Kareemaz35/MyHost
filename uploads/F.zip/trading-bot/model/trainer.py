# ============================================================
# model/trainer.py — تدريب XGBoost على بيانات الذهب
# ============================================================
import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit
from sklearn.preprocessing   import StandardScaler
from sklearn.metrics         import classification_report, roc_auc_score
import xgboost as xgb
import joblib
from loguru import logger
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from data.collector     import fetch_ohlcv
from data.preprocessor  import preprocess, get_feature_columns


def prepare_training_data(
    timeframe: str = None,
    n_bars:    int = None,
    years:     int = None,
) -> tuple[np.ndarray, np.ndarray, list[str]]:
    tf     = timeframe or config.DEFAULT_TIMEFRAME
    n      = n_bars    or config.BARS_TO_FETCH
    yrs    = years     or config.HISTORICAL_YEARS

    logger.info(f"📥 جلب بيانات الذهب ({yrs} سنوات من Yahoo Finance)...")
    df = fetch_ohlcv(timeframe=tf, n_bars=n, years=yrs)

    if df.empty:
        raise ValueError("لم يتم جلب أي بيانات")

    df = preprocess(df, lookahead=1)
    if df.empty:
        raise ValueError("فشل تحضير البيانات")

    feat_cols = get_feature_columns(df)
    X = df[feat_cols].values
    y = df["target"].values

    logger.info(f"✅ بيانات التدريب: {len(X)} عينة | {len(feat_cols)} ميزة | "
                f"نسبة البيع: {y.mean()*100:.1f}%")
    return X, y, feat_cols


def train_model(X: np.ndarray, y: np.ndarray) -> tuple:
    scaler = StandardScaler()
    X_sc   = scaler.fit_transform(X)

    tscv  = TimeSeriesSplit(n_splits=5)
    split = int(len(X_sc) * config.TRAIN_TEST_SPLIT)
    X_tr, X_te = X_sc[:split], X_sc[split:]
    y_tr, y_te = y[:split],    y[split:]

    model = xgb.XGBClassifier(
        n_estimators=config.N_ESTIMATORS,
        max_depth=5,
        learning_rate=0.05,
        subsample=0.8,
        colsample_bytree=0.8,
        scale_pos_weight=len(y_tr[y_tr==0]) / (len(y_tr[y_tr==1]) + 1e-9),
        use_label_encoder=False,
        eval_metric="logloss",
        random_state=42,
        n_jobs=-1,
    )

    logger.info("🧠 تدريب النموذج...")
    model.fit(
        X_tr, y_tr,
        eval_set=[(X_te, y_te)],
        verbose=False,
    )

    # تقييم
    y_pred = model.predict(X_te)
    y_prob = model.predict_proba(X_te)[:, 1]
    auc    = roc_auc_score(y_te, y_prob)
    report = classification_report(y_te, y_pred, output_dict=True)
    winrate= report.get("1", {}).get("precision", 0)

    logger.info(f"\n{'='*50}")
    logger.info(f"  AUC:      {auc:.3f}")
    logger.info(f"  Winrate:  {winrate*100:.1f}%")
    logger.info(f"  Accuracy: {report['accuracy']*100:.1f}%")
    logger.info(f"{'='*50}\n")

    return model, scaler, {
        "auc": auc, "winrate": winrate,
        "accuracy": report["accuracy"],
        "n_train": len(X_tr), "n_test": len(X_te),
    }


def save_model(model, scaler, feat_cols: list[str]):
    os.makedirs(os.path.dirname(config.MODEL_PATH), exist_ok=True)
    joblib.dump(model,     config.MODEL_PATH)
    joblib.dump(scaler,    config.SCALER_PATH)
    joblib.dump(feat_cols, config.FEATURES_PATH)
    logger.info(f"💾 النموذج محفوظ: {config.MODEL_PATH}")


def full_training_pipeline(
    timeframe: str = None,
    n_bars:    int = None,
    years:     int = None,
) -> dict:
    try:
        X, y, feat_cols = prepare_training_data(timeframe, n_bars, years)
        model, scaler, metrics = train_model(X, y)
        save_model(model, scaler, feat_cols)
        return metrics
    except Exception as e:
        logger.error(f"❌ فشل التدريب: {e}")
        raise
