# ============================================================
# model/self_learning.py — نظام التعلم الذاتي
# ============================================================
import json
import os
from datetime import datetime
from loguru import logger
import sys
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


class SelfLearning:
    """يسجّل الصفقات ويحلل أسباب الربح والخسارة."""

    def __init__(self):
        self.path = config.TRADES_LOG_PATH
        os.makedirs(os.path.dirname(self.path), exist_ok=True)
        self._trades = self._load()

    def _load(self) -> list:
        if os.path.exists(self.path):
            try:
                with open(self.path) as f:
                    return json.load(f)
            except Exception:
                pass
        return []

    def _save(self):
        with open(self.path, "w") as f:
            json.dump(self._trades, f, indent=2, default=str)

    def log_trade(self, trade: dict):
        """تسجيل صفقة جديدة."""
        trade["logged_at"] = str(datetime.utcnow())
        self._trades.append(trade)
        self._save()
        logger.info(f"📝 تم تسجيل الصفقة: {trade.get('signal')} | ربح: {trade.get('profit', 0):.2f}$")

    def log_result(self, order_id: str, profit: float, exit_reason: str = ""):
        """تحديث نتيجة صفقة موجودة."""
        for t in reversed(self._trades):
            if t.get("order_id") == order_id:
                t["profit"]      = profit
                t["result"]      = "win" if profit > 0 else "loss"
                t["exit_reason"] = exit_reason
                t["closed_at"]   = str(datetime.utcnow())
                break
        self._save()

    def get_statistics(self) -> dict:
        """إحصائيات أداء البوت."""
        closed = [t for t in self._trades if "profit" in t]
        if not closed:
            return {"total": 0, "winrate": 0, "avg_profit": 0, "avg_loss": 0}

        wins   = [t for t in closed if t["profit"] > 0]
        losses = [t for t in closed if t["profit"] <= 0]

        stats = {
            "total":        len(closed),
            "wins":         len(wins),
            "losses":       len(losses),
            "winrate":      len(wins) / len(closed),
            "avg_profit":   sum(t["profit"] for t in wins)   / (len(wins)   + 1e-9),
            "avg_loss":     sum(t["profit"] for t in losses) / (len(losses) + 1e-9),
            "total_pnl":    sum(t["profit"] for t in closed),
            "profit_factor": abs(sum(t["profit"] for t in wins)) / (abs(sum(t["profit"] for t in losses)) + 1e-9),
        }

        logger.info(
            f"📊 إحصائيات: {stats['total']} صفقة | "
            f"Winrate={stats['winrate']*100:.1f}% | "
            f"PnL={stats['total_pnl']:.2f}$"
        )
        return stats

    def analyze_losses(self) -> dict:
        """يحلل أسباب الخسارة الشائعة."""
        losses = [t for t in self._trades if t.get("result") == "loss"]
        if not losses:
            return {}

        reasons = {}
        for t in losses:
            r = t.get("reason", "unknown")
            reasons[r] = reasons.get(r, 0) + 1

        # الإشارات التي تؤدي لخسارة أكثر
        worst_signals = sorted(reasons.items(), key=lambda x: -x[1])
        logger.info(f"🔍 أكثر أسباب الخسارة: {worst_signals[:3]}")
        return {"loss_reasons": reasons, "worst_signals": worst_signals[:3]}

    def should_retrain(self) -> bool:
        """هل يجب إعادة التدريب؟ (بعد كل 50 صفقة أو winrate أقل من 40%)"""
        stats = self.get_statistics()
        if stats["total"] > 0 and stats["total"] % 50 == 0:
            return True
        if stats["total"] >= 20 and stats["winrate"] < 0.40:
            logger.warning("⚠️ Winrate منخفض — يُنصح بإعادة التدريب")
            return True
        return False

    def get_confidence_adjustment(self) -> float:
        """
        يعدّل حد الثقة تلقائياً:
        إذا كان winrate منخفضاً ← رفع الحد
        إذا كان مرتفعاً        ← خفض الحد قليلاً (لزيادة الصفقات)
        """
        stats = self.get_statistics()
        if stats["total"] < 10:
            return config.MIN_CONFIDENCE

        wr = stats["winrate"]
        if wr < 0.45:
            return min(0.90, config.MIN_CONFIDENCE + 0.05)
        elif wr > 0.60:
            return max(0.70, config.MIN_CONFIDENCE - 0.03)
        return config.MIN_CONFIDENCE
