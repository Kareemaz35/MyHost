# ============================================================
# broker/bybit_connector.py — الاتصال بـ Bybit Futures API
# ============================================================
# يدعم: Testnet و Real Trading
# الأصل: XAUUSDT (ذهب)
# ============================================================

import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

from loguru import logger
from datetime import datetime
import pandas as pd

try:
    from pybit.unified_trading import HTTP
    PYBIT_AVAILABLE = True
except ImportError:
    PYBIT_AVAILABLE = False
    logger.warning("⚠️ pybit غير مثبّت — شغّل: pip install pybit")

_session = None


# ──────────────────────────────────────────────────────────
# الاتصال
# ──────────────────────────────────────────────────────────

def connect() -> bool:
    global _session
    if not PYBIT_AVAILABLE:
        logger.error("❌ pybit غير متاح")
        return False
    if not config.BYBIT_API_KEY or not config.BYBIT_API_SECRET:
        logger.error("❌ BYBIT_API_KEY أو BYBIT_API_SECRET غير مُعيَّن في .env")
        return False
    try:
        _session = HTTP(
            testnet=config.BYBIT_TESTNET,
            api_key=config.BYBIT_API_KEY,
            api_secret=config.BYBIT_API_SECRET,
        )
        info = _session.get_wallet_balance(accountType="UNIFIED")
        if info.get("retCode") == 0:
            mode = "Testnet 🧪" if config.BYBIT_TESTNET else "Real 🔴"
            logger.info(f"✅ متصل بـ Bybit {mode}")
            return True
        else:
            logger.error(f"❌ فشل الاتصال: {info.get('retMsg')}")
            return False
    except Exception as e:
        logger.error(f"❌ خطأ في الاتصال: {e}")
        return False


def disconnect():
    global _session
    _session = None
    logger.info("🔌 تم قطع الاتصال بـ Bybit")


def get_session():
    return _session


# ──────────────────────────────────────────────────────────
# معلومات الحساب
# ──────────────────────────────────────────────────────────

def account_summary() -> dict:
    if not _session:
        return {"balance": 0, "equity": 0, "msg": "غير متصل"}
    try:
        resp = _session.get_wallet_balance(accountType="UNIFIED")
        if resp["retCode"] != 0:
            return {"balance": 0, "equity": 0}
        coins = resp["result"]["list"][0]["coin"]
        usdt  = next((c for c in coins if c["coin"] == "USDT"), {})
        return {
            "balance":     float(usdt.get("walletBalance",     0)),
            "equity":      float(usdt.get("equity",            0)),
            "unrealised":  float(usdt.get("unrealisedPnl",     0)),
            "available":   float(usdt.get("availableToWithdraw", 0)),
            "mode":        "Testnet" if config.BYBIT_TESTNET else "Real",
        }
    except Exception as e:
        logger.error(f"خطأ في جلب الحساب: {e}")
        return {}


# ──────────────────────────────────────────────────────────
# السعر الحالي
# ──────────────────────────────────────────────────────────

def get_current_price(symbol: str = None) -> dict:
    sym = symbol or config.SYMBOL
    if not _session:
        return {}
    try:
        resp = _session.get_tickers(category=config.CATEGORY, symbol=sym)
        if resp["retCode"] != 0:
            return {}
        t = resp["result"]["list"][0]
        return {
            "bid":    float(t["bid1Price"]),
            "ask":    float(t["ask1Price"]),
            "last":   float(t["lastPrice"]),
            "spread": float(t["ask1Price"]) - float(t["bid1Price"]),
        }
    except Exception as e:
        logger.error(f"خطأ في جلب السعر: {e}")
        return {}


# ──────────────────────────────────────────────────────────
# حساب حجم الصفقة
# ──────────────────────────────────────────────────────────

def calculate_qty(
    sl_distance_usd: float,
    risk_percent:    float = None,
) -> float:
    """
    حجم اللوت بناءً على المخاطرة.
    XAUUSDT: الحد الأدنى 0.01 لوت (1 أوقية).
    """
    risk_pct = risk_percent or config.RISK_PERCENT
    acc = account_summary()
    balance = acc.get("balance", 0)
    if balance <= 0 or sl_distance_usd <= 0:
        return 0.01

    risk_usd = balance * (risk_pct / 100)
    qty = risk_usd / sl_distance_usd
    qty = max(0.01, round(qty, 2))
    logger.info(f"📐 حجم اللوت: رصيد={balance:.2f} | خطر={risk_usd:.2f}$ | qty={qty}")
    return qty


# ──────────────────────────────────────────────────────────
# فتح صفقة
# ──────────────────────────────────────────────────────────

def open_trade(
    side:     str,          # "Buy" أو "Sell"
    qty:      float,
    sl_price: float = 0.0,
    tp_price: float = 0.0,
    comment:  str   = "AI_Bot",
) -> dict:
    if not _session:
        return {"success": False, "msg": "غير متصل بـ Bybit"}

    # فحص السبريد
    price_info = get_current_price()
    if price_info:
        spread = price_info.get("spread", 0)
        if spread > config.MAX_SPREAD_POINTS:
            return {"success": False, "msg": f"سبريد عالٍ: {spread:.1f}"}

    try:
        params = {
            "category":   config.CATEGORY,
            "symbol":     config.SYMBOL,
            "side":       side,
            "orderType":  "Market",
            "qty":        str(qty),
        }
        if sl_price > 0:
            params["stopLoss"]    = str(round(sl_price, 2))
            params["slTriggerBy"] = "MarkPrice"
        if tp_price > 0:
            params["takeProfit"]  = str(round(tp_price, 2))
            params["tpTriggerBy"] = "MarkPrice"

        resp = _session.place_order(**params)
        if resp["retCode"] == 0:
            order_id = resp["result"]["orderId"]
            logger.info(f"✅ صفقة مفتوحة | {side} {qty} {config.SYMBOL} | ID: {order_id}")
            return {"success": True, "order_id": order_id, "msg": "تم"}
        else:
            msg = resp.get("retMsg", "خطأ غير معروف")
            logger.error(f"❌ فشل فتح الصفقة: {msg}")
            return {"success": False, "msg": msg}
    except Exception as e:
        logger.error(f"❌ استثناء عند فتح الصفقة: {e}")
        return {"success": False, "msg": str(e)}


# ──────────────────────────────────────────────────────────
# إغلاق الصفقة
# ──────────────────────────────────────────────────────────

def close_position(symbol: str = None) -> dict:
    sym = symbol or config.SYMBOL
    if not _session:
        return {"success": False, "msg": "غير متصل"}
    try:
        positions = get_open_positions(sym)
        if positions.empty:
            return {"success": False, "msg": "لا توجد صفقات مفتوحة"}

        pos = positions.iloc[0]
        close_side = "Sell" if pos["side"] == "Buy" else "Buy"
        qty        = pos["size"]

        resp = _session.place_order(
            category=config.CATEGORY,
            symbol=sym,
            side=close_side,
            orderType="Market",
            qty=str(qty),
            reduceOnly=True,
        )
        if resp["retCode"] == 0:
            logger.info(f"✅ تم إغلاق {sym} | ربح: {pos['unrealised_pnl']:.2f}$")
            return {"success": True, "profit": pos["unrealised_pnl"]}
        else:
            return {"success": False, "msg": resp.get("retMsg")}
    except Exception as e:
        logger.error(f"خطأ في إغلاق الصفقة: {e}")
        return {"success": False, "msg": str(e)}


# ──────────────────────────────────────────────────────────
# الصفقات المفتوحة
# ──────────────────────────────────────────────────────────

def get_open_positions(symbol: str = None) -> pd.DataFrame:
    sym = symbol or config.SYMBOL
    if not _session:
        return pd.DataFrame()
    try:
        resp = _session.get_positions(category=config.CATEGORY, symbol=sym)
        if resp["retCode"] != 0:
            return pd.DataFrame()
        data = []
        for p in resp["result"]["list"]:
            if float(p.get("size", 0)) > 0:
                data.append({
                    "symbol":        p["symbol"],
                    "side":          p["side"],
                    "size":          float(p["size"]),
                    "entry_price":   float(p["avgPrice"]),
                    "mark_price":    float(p.get("markPrice", 0)),
                    "sl":            float(p.get("stopLoss", 0)),
                    "tp":            float(p.get("takeProfit", 0)),
                    "unrealised_pnl":float(p.get("unrealisedPnl", 0)),
                    "leverage":      float(p.get("leverage", 1)),
                })
        return pd.DataFrame(data)
    except Exception as e:
        logger.error(f"خطأ في جلب الصفقات: {e}")
        return pd.DataFrame()


# ──────────────────────────────────────────────────────────
# حساب SL/TP من ATR
# ──────────────────────────────────────────────────────────

def calculate_sl_tp(
    side: str,
    current_price: float,
    atr: float,
) -> tuple[float, float, float]:
    """
    يُعيد: (sl_price, tp_price, sl_distance_usd)
    """
    sl_dist = atr * config.STOP_LOSS_ATR
    tp_dist = atr * config.TAKE_PROFIT_ATR

    if side == "Buy":
        sl_price = round(current_price - sl_dist, 2)
        tp_price = round(current_price + tp_dist, 2)
    else:
        sl_price = round(current_price + sl_dist, 2)
        tp_price = round(current_price - tp_dist, 2)

    rr = tp_dist / sl_dist if sl_dist > 0 else 0
    logger.debug(f"SL/TP | {side} @ {current_price:.2f} | SL={sl_price} TP={tp_price} | R:R={rr:.1f}")
    return sl_price, tp_price, sl_dist
