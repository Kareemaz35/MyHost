# 🚀 دليل التشغيل السريع — روبوت الذهب (Bybit)

## الخطوات من الصفر

```bash
cd ~/Downloads
unzip -o trading-bot.zip
cd trading-bot
python -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
```

## إعداد .env

```bash
cp .env.example .env
nano .env
```

أضف:
```
BYBIT_API_KEY=...
BYBIT_API_SECRET=...
BYBIT_TESTNET=true          # ← ابدأ بـ Testnet دائماً!
TELEGRAM_TOKEN=...
TELEGRAM_CHAT_ID=...
```

## كيف تحصل على Bybit API Key؟
1. سجّل على: https://testnet.bybit.com (للتجريب)
2. API Management → New Key
3. صلاحيات: Read + Trade (فقط)
4. انسخ Key و Secret في .env

## تشغيل البوت

```bash
# فحص الإعداد
python setup_check.py

# تدريب النموذج (5 سنوات بيانات — 5-10 دقائق)
python main.py --train-only

# Backtest لمعرفة الأداء التاريخي
python main.py --backtest

# اختبار تيليجرام
python main.py --test-telegram

# تشغيل (Demo - بدون صفقات حقيقية)
python main.py --demo

# تشغيل حقيقي على Testnet
python main.py
```

## بعد إطفاء الحاسوب

```bash
cd ~/Downloads/trading-bot
source venv/bin/activate
python main.py --demo
```

## أوامر تيليجرام

| الأمر | الوظيفة |
|-------|---------|
| `/start` | استئناف التداول |
| `/stop` | إيقاف التداول |
| `/status` | إحصائيات اليوم |
| `/help` | قائمة الأوامر |

## هيكل القرار (كيف يعمل البوت)

```
1. فحص الأخبار (إيقاف إذا أخبار قوية ±30 دق)
2. فحص Risk Manager (حدود الخسارة اليومية)
3. تحليل D1 + H4 + H1 (يجب توافق 2/3)
4. فحص حالة السوق (تجنب السوق العرضي)
5. فحص حجم التداول (> 1.2x المتوسط)
6. فحص ATR (تقلب معقول)
7. تنبؤ AI (ثقة > 75%)
8. فحص R:R (> 1:2)
9. ✅ دخول الصفقة
```
