# ============================================================
# config.py — الإعدادات المركزية (Bybit + XAUUSDT)
# ============================================================
import os
from dotenv import load_dotenv

load_dotenv()

# ──────────────────────────────────────────────
# وضع التشغيل: Testnet أم Real
# ──────────────────────────────────────────────
BYBIT_TESTNET   = os.getenv("BYBIT_TESTNET", "true").lower() == "true"
BYBIT_API_KEY   = os.getenv("BYBIT_API_KEY", "")
BYBIT_API_SECRET= os.getenv("BYBIT_API_SECRET", "")

# ──────────────────────────────────────────────
# الأصل المتداول (الذهب فقط)
# ──────────────────────────────────────────────
SYMBOL          = "XAUUSDT"          # Bybit Futures Gold
SYMBOL_YFINANCE = "GC=F"             # Yahoo Finance Gold Futures (للبيانات التاريخية)
CATEGORY        = "linear"           # USDT Perpetual

# ──────────────────────────────────────────────
# الأطر الزمنية (Multi-Timeframe)
# ──────────────────────────────────────────────
# Bybit timeframes: "1","3","5","15","30","60","120","240","D"
TIMEFRAME_PRIMARY  = "60"    # H1 — الإطار الرئيسي
TIMEFRAME_CONFIRM  = "240"   # H4 — تأكيد الاتجاه
TIMEFRAME_TREND    = "D"     # D1 — الاتجاه الكبير
TIMEFRAME_ENTRY    = "15"    # M15 — الدخول الدقيق
ALL_TIMEFRAMES     = ["D", "240", "60", "15"]

DEFAULT_TIMEFRAME  = TIMEFRAME_PRIMARY
BARS_TO_FETCH      = 500     # عدد الشموع لكل إطار
HISTORICAL_YEARS   = 5       # سنوات للبيانات التاريخية (Backtesting)

# ──────────────────────────────────────────────
# إعدادات تيليجرام
# ──────────────────────────────────────────────
TELEGRAM_TOKEN   = os.getenv("TELEGRAM_TOKEN", "")
TELEGRAM_CHAT_ID = os.getenv("TELEGRAM_CHAT_ID", "")

# ──────────────────────────────────────────────
# إدارة المخاطر (Risk Management)
# ──────────────────────────────────────────────
RISK_PERCENT           = float(os.getenv("RISK_PERCENT", "1.0"))   # % من الرصيد لكل صفقة
MAX_OPEN_TRADES        = 1        # صفقة واحدة فقط على الذهب
MAX_DAILY_LOSS_PERCENT = 3.0      # إيقاف التداول إذا خسر 3% يومياً
MAX_TRADES_PER_DAY     = 5        # أقصى عدد صفقات يومياً
MAX_CONSECUTIVE_LOSSES = 3        # إيقاف بعد 3 خسائر متتالية
STOP_LOSS_ATR          = 1.5      # SL = ATR × 1.5
TAKE_PROFIT_ATR        = 3.0      # TP = ATR × 3.0  (R:R = 1:2)
MIN_RR_RATIO           = 2.0      # الحد الأدنى لنسبة R:R
MAX_SPREAD_POINTS      = 50       # أقصى سبريد مسموح (نقاط)

# ──────────────────────────────────────────────
# إعدادات الذكاء الاصطناعي
# ──────────────────────────────────────────────
MODEL_PATH         = "model/saved_model.pkl"
SCALER_PATH        = "model/scaler.pkl"
FEATURES_PATH      = "model/features.pkl"
TRADES_LOG_PATH    = "model/trades_history.json"
MIN_CONFIDENCE     = 0.75         # لا دخول إلا بثقة فوق 75%
TRAIN_TEST_SPLIT   = 0.8
LOOKBACK_CANDLES   = 30
N_ESTIMATORS       = 200
TARGET_WINRATE     = 0.55         # هدف 55% (بين 50-60%)

# ──────────────────────────────────────────────
# فلاتر السوق
# ──────────────────────────────────────────────
MIN_ATR_THRESHOLD      = 0.5      # تجنب السوق الهادئ جداً
MAX_ATR_THRESHOLD      = 30.0     # تجنب التقلب الشديد جداً
MIN_VOLUME_RATIO       = 1.2      # حجم التداول أعلى من المتوسط بـ 20%
NEWS_PAUSE_MINUTES     = 30       # إيقاف قبل وبعد الأخبار القوية بـ 30 دقيقة
RANGING_MARKET_ADX     = 25       # ADX أقل من 25 = سوق عرضي

# ──────────────────────────────────────────────
# الجدولة
# ──────────────────────────────────────────────
SCAN_INTERVAL_MINUTES  = 60
RETRAIN_HOURS          = 24
DAILY_REPORT_TIME      = "22:00"
