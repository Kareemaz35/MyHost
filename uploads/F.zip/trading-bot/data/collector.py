# ============================================================
# data/collector.py — جلب بيانات الذهب (Bybit + Yahoo Finance)
# ============================================================
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from loguru import logger

# Bybit عبر ccxt
try:
    import ccxt
    CCXT_AVAILABLE = True
except ImportError:
    CCXT_AVAILABLE = False
    logger.info("ℹ️ ccxt غير متاح — سيُستخدم Yahoo Finance")

# Yahoo Finance للبيانات التاريخية الطويلة
try:
    import yfinance as yf
    YFINANCE_AVAILABLE = True
except ImportError:
    YFINANCE_AVAILABLE = False


# ──────────────────────────────────────────────────────────
# خريطة الأطر الزمنية
# ──────────────────────────────────────────────────────────

BYBIT_TO_CCXT = {
    "1": "1m", "3": "3m", "5": "5m", "15": "15m",
    "30": "30m", "60": "1h", "120": "2h", "240": "4h",
    "D": "1d", "W": "1w",
}

BYBIT_TO_YF = {
    "1": "1m", "5": "5m", "15": "15m", "30": "30m",
    "60": "1h", "120": "1h", "240": "1h", "D": "1d", "W": "1wk",
}


# ──────────────────────────────────────────────────────────
# جلب البيانات من Bybit عبر ccxt
# ──────────────────────────────────────────────────────────

def _get_ccxt_exchange():
    if not CCXT_AVAILABLE:
        return None
    try:
        exchange = ccxt.bybit({
            "apiKey":  config.BYBIT_API_KEY,
            "secret":  config.BYBIT_API_SECRET,
            "options": {"defaultType": "future"},
        })
        if config.BYBIT_TESTNET:
            exchange.set_sandbox_mode(True)
        return exchange
    except Exception as e:
        logger.warning(f"ccxt init failed: {e}")
        return None


def fetch_ohlcv_bybit(
    symbol:    str = None,
    timeframe: str = "60",
    n_bars:    int = 500,
) -> pd.DataFrame:
    sym = symbol or config.SYMBOL
    ccxt_tf = BYBIT_TO_CCXT.get(timeframe, "1h")
    exchange = _get_ccxt_exchange()
    if exchange is None:
        return pd.DataFrame()
    try:
        # XAUUSDT Futures على ccxt
        ohlcv = exchange.fetch_ohlcv(
            "XAU/USDT:USDT", ccxt_tf, limit=n_bars
        )
        df = pd.DataFrame(ohlcv, columns=["timestamp","open","high","low","close","volume"])
        df["time"] = pd.to_datetime(df["timestamp"], unit="ms")
        df = df.drop("timestamp", axis=1)
        logger.info(f"✅ Bybit OHLCV: {sym} {timeframe} | {len(df)} شمعة")
        return df
    except Exception as e:
        logger.warning(f"⚠️ فشل Bybit: {e} — سينتقل لـ Yahoo Finance")
        return pd.DataFrame()


# ──────────────────────────────────────────────────────────
# جلب البيانات من Yahoo Finance (للبيانات التاريخية الطويلة)
# ──────────────────────────────────────────────────────────

def fetch_ohlcv_yahoo(
    timeframe: str = "60",
    n_bars:    int = 500,
    years:     int = None,
) -> pd.DataFrame:
    if not YFINANCE_AVAILABLE:
        return pd.DataFrame()
    try:
        yf_tf = BYBIT_TO_YF.get(timeframe, "1h")
        ticker = yf.Ticker(config.SYMBOL_YFINANCE)

        if years:
            start = datetime.now() - timedelta(days=years * 365)
            df = ticker.history(start=start, interval=yf_tf)
        else:
            # حساب الفترة الزمنية
            period_map = {"1m":"7d","5m":"60d","15m":"60d","30m":"60d",
                          "1h":"730d","1d":"max","1wk":"max"}
            period = period_map.get(yf_tf, "730d")
            df = ticker.history(period=period, interval=yf_tf)

        if df.empty:
            return pd.DataFrame()

        df = df.rename(columns={
            "Open": "open", "High": "high", "Low": "low",
            "Close": "close", "Volume": "volume",
        })
        df["time"] = df.index
        df = df[["time","open","high","low","close","volume"]].tail(n_bars)
        df = df.reset_index(drop=True)
        logger.info(f"✅ Yahoo Finance OHLCV: XAUUSD {timeframe} | {len(df)} شمعة")
        return df
    except Exception as e:
        logger.error(f"❌ فشل Yahoo Finance: {e}")
        return pd.DataFrame()


# ──────────────────────────────────────────────────────────
# الدالة الرئيسية
# ──────────────────────────────────────────────────────────

def fetch_ohlcv(
    symbol:    str  = None,
    timeframe: str  = "60",
    n_bars:    int  = 500,
    years:     int  = None,
) -> pd.DataFrame:
    """
    يحاول Bybit أولاً، يرجع لـ Yahoo Finance عند الفشل.
    إذا حُدِّد years يُحضر بيانات تاريخية طويلة من Yahoo.
    """
    if years:
        return fetch_ohlcv_yahoo(timeframe, n_bars, years)

    df = fetch_ohlcv_bybit(symbol, timeframe, n_bars)
    if df.empty:
        df = fetch_ohlcv_yahoo(timeframe, n_bars)
    return df


# ──────────────────────────────────────────────────────────
# جلب بيانات متعددة الأطر الزمنية
# ──────────────────────────────────────────────────────────

def fetch_multi_timeframe(n_bars: int = 300) -> dict[str, pd.DataFrame]:
    """يُعيد dict: {timeframe: DataFrame} لكل الأطر الزمنية."""
    result = {}
    for tf in config.ALL_TIMEFRAMES:
        df = fetch_ohlcv(timeframe=tf, n_bars=n_bars)
        if not df.empty:
            result[tf] = df
            logger.info(f"  ✅ TF {tf}: {len(df)} شمعة")
        else:
            logger.warning(f"  ⚠️ TF {tf}: فشل جلب البيانات")
    return result


# ──────────────────────────────────────────────────────────
# السعر الحالي (بدون مفتاح API)
# ──────────────────────────────────────────────────────────

def get_current_price_public() -> float:
    """يجلب آخر سعر من Yahoo Finance بدون API key."""
    try:
        df = fetch_ohlcv_yahoo("60", n_bars=2)
        if not df.empty:
            return float(df["close"].iloc[-1])
    except Exception:
        pass
    return 0.0
