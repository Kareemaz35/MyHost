# ============================================================
# data/preprocessor.py — تحضير البيانات للنموذج
# ============================================================
import pandas as pd
import numpy as np
import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

from indicators.technical    import add_all_indicators
from indicators.candlestick  import add_candlestick_patterns
from indicators.smart_money  import add_smc_indicators
from loguru import logger


FEATURE_COLS = [
    "rsi","rsi_fast","macd","macd_signal","macd_hist",
    "ema_9","ema_21","ema_50","ema_200",
    "atr","atr_pct","bb_width","bb_pct",
    "volume_ratio","volume_spike",
    "adx","di_plus","di_minus","trending",
    "stoch_k","stoch_d","cci","momentum","roc",
    "body","upper_wick","lower_wick","is_bullish",
    "dist_res","dist_sup",
    "doji","hammer","shooting_star",
    "bullish_engulfing","bearish_engulfing",
    "marubozu_bull","marubozu_bear",
    "three_soldiers","three_crows",
    "morning_star","evening_star",
    "candle_bull_score","candle_bear_score",
    "bos_bullish","bos_bearish","bull_ob","bear_ob",
    "fvg_bull","fvg_bear","near_bull_ob",
    "smc_bull_score","smc_bear_score",
    "dist_liq_high","dist_liq_low",
]


def preprocess(df: pd.DataFrame, lookahead: int = 1) -> pd.DataFrame:
    """يحضّر DataFrame كامل مع الميزات والهدف."""
    if df.empty:
        return df
    df = add_all_indicators(df)
    df = add_candlestick_patterns(df)
    df = add_smc_indicators(df)

    # الهدف: هل السعر سيرتفع فوق ATR بعد lookahead شمعة؟
    future_ret = df["close"].shift(-lookahead) / df["close"] - 1
    atr_thresh = df["atr"] / df["close"]
    df["target"] = (future_ret > atr_thresh * 0.5).astype(int)

    # إزالة القيم الناقصة
    df = df.dropna()
    logger.info(f"📊 بيانات جاهزة: {len(df)} صف | {len(get_feature_columns(df))} ميزة")
    return df


def get_feature_columns(df: pd.DataFrame) -> list[str]:
    """يُعيد أعمدة الميزات الموجودة فعلاً في الـ DataFrame."""
    return [c for c in FEATURE_COLS if c in df.columns]
