# ============================================================
# main.py — نقطة الدخول الرئيسية للروبوت
# ============================================================
# الدور:
#   الملف الذي تُشغِّله لبدء الروبوت. يجمع كل المكوّنات
#   في حلقة تشغيل مستمرة تعمل على مدار الساعة.
#
# طريقة التشغيل:
#   python main.py               ← الوضع الكامل (يتطلب MT5)
#   python main.py --demo        ← وضع العرض بدون MT5
#   python main.py --train-only  ← تدريب النموذج فقط
#
# المكتبات: schedule, loguru, argparse
# ============================================================

import argparse
import schedule
import time
import sys
from datetime import datetime
from loguru import logger

import config
from data.collector       import fetch_ohlcv, connect_mt5, disconnect_mt5
from model.trainer        import full_training_pipeline
from model.predictor      import TradingPredictor
from strategies.ai_strategy import AITradingStrategy, can_open_trade
from notifications.telegram_bot import (
    notify_bot_started, notify_signal, notify_error,
    notify_trade_opened, notify_daily_report, test_connection
)

# ──────────────────────────────────────────────────────────
# إعداد نظام السجلات
# ──────────────────────────────────────────────────────────

logger.remove()
logger.add(
    sys.stdout,
    format="<green>{time:HH:mm:ss}</green> | <level>{level:<8}</level> | {message}",
    colorize=True,
)
logger.add(
    "logs/trading_bot_{time:YYYY-MM-DD}.log",
    rotation="00:00",      # ملف جديد كل يوم
    retention="30 days",   # احتفظ بـ 30 يوم
    level="DEBUG",
    encoding="utf-8",
)


# ──────────────────────────────────────────────────────────
# الحالة العامة للروبوت
# ──────────────────────────────────────────────────────────

class BotState:
    """تتبّع إحصائيات الروبوت خلال الجلسة."""
    def __init__(self):
        self.trades_today   = 0
        self.wins_today     = 0
        self.profit_today   = 0.0
        self.scans_done     = 0
        self.start_time     = datetime.now()
        self.last_balance   = 0.0

    def uptime(self) -> str:
        delta = datetime.now() - self.start_time
        h, rem = divmod(int(delta.total_seconds()), 3600)
        m, s   = divmod(rem, 60)
        return f"{h:02d}:{m:02d}:{s:02d}"


state    = BotState()
strategy = AITradingStrategy()


# ──────────────────────────────────────────────────────────
# دورة الفحص الرئيسية
# ──────────────────────────────────────────────────────────

def scan_market(demo_mode: bool = False):
    """
    فحص السوق لجميع الرموز واتخاذ قرارات التداول.
    تُستدعى دورياً بحسب SCAN_INTERVAL_MINUTES.
    """
    state.scans_done += 1
    logger.info(f"\n{'─'*60}")
    logger.info(f"🔍 الفحص #{state.scans_done} | {datetime.now():%Y-%m-%d %H:%M} | وقت التشغيل: {state.uptime()}")
    logger.info(f"{'─'*60}")

    for symbol in config.SYMBOLS:
        try:
            _analyze_symbol(symbol, demo_mode)
        except Exception as e:
            msg = f"خطأ في فحص {symbol}: {e}"
            logger.error(msg)
            notify_error(msg)


def _analyze_symbol(symbol: str, demo_mode: bool):
    """تحليل رمز واحد واتخاذ القرار."""
    logger.info(f"\n📊 تحليل {symbol}...")

    # جلب البيانات
    df = fetch_ohlcv(
        symbol,
        timeframe = config.DEFAULT_TIMEFRAME,
        n_bars    = config.BARS_TO_FETCH,
        use_mt5   = not demo_mode,
    )

    if df is None or df.empty:
        logger.warning(f"  ⚠️ لا توجد بيانات لـ {symbol}")
        return

    # التحليل الشامل
    decision = strategy.analyze(
        symbol    = symbol,
        timeframe = config.DEFAULT_TIMEFRAME,
        df        = df,
        use_news  = bool(config.NEWS_API_KEY),
    )

    # إرسال إشعار الإشارة دائماً
    notify_signal(
        symbol       = symbol,
        timeframe    = config.DEFAULT_TIMEFRAME,
        signal       = decision.action,
        confidence   = decision.ai_confidence,
        indicators   = {"buy_count": 0, "sell_count": 0, "atr": decision.atr},
        news_label   = decision.news_label,
        candle_bias  = decision.candle_bias,
    )

    # تنفيذ الصفقة إذا لم نكن في وضع العرض
    if decision.action in ("BUY", "SELL") and not demo_mode:
        _execute_trade(symbol, decision)
    elif decision.action in ("BUY", "SELL") and demo_mode:
        logger.info(f"  🎭 وضع العرض: سيُنفَّذ {decision.action} في الواقع")


def _execute_trade(symbol: str, decision):
    """تنفيذ صفقة بناءً على القرار."""
    try:
        from broker.mt5_connector import (
            calculate_lot_size, calculate_sl_tp, open_trade
        )

        # التحقق من إمكانية فتح الصفقة
        can_trade, reason = can_open_trade(symbol, decision.action)
        if not can_trade:
            logger.info(f"  ⏭️ تم تخطي الصفقة: {reason}")
            return

        # حساب SL/TP
        sl, tp = calculate_sl_tp(symbol, decision.action, decision.atr)

        # حساب حجم اللوت
        sl_pips = abs(decision.atr * config.STOP_LOSS_ATR) * 10000
        lot     = calculate_lot_size(symbol, sl_pips)

        # فتح الصفقة
        result = open_trade(
            symbol     = symbol,
            order_type = decision.action,
            lot        = lot,
            sl_price   = sl,
            tp_price   = tp,
            comment    = f"AI_{decision.ai_confidence:.0%}",
        )

        if result["success"]:
            state.trades_today += 1
            tick = None
            try:
                import MetaTrader5 as mt5
                t = mt5.symbol_info_tick(symbol)
                price = t.ask if decision.action == "BUY" else t.bid
            except Exception:
                price = 0.0

            notify_trade_opened(
                symbol     = symbol,
                order_type = decision.action,
                lot        = lot,
                price      = price,
                sl         = sl,
                tp         = tp,
                confidence = decision.ai_confidence,
                ticket     = result["ticket"],
            )
        else:
            logger.error(f"  ❌ فشل فتح الصفقة: {result['msg']}")

    except ImportError:
        logger.warning("  ⚠️ MT5 غير متاح في هذه البيئة")


# ──────────────────────────────────────────────────────────
# إعادة تدريب النموذج دورياً
# ──────────────────────────────────────────────────────────

def retrain_model(demo_mode: bool = False):
    """إعادة تدريب النموذج بأحدث البيانات."""
    logger.info("🔄 بدء إعادة تدريب النموذج...")
    try:
        full_training_pipeline(
            symbol    = config.SYMBOLS[0],
            timeframe = config.DEFAULT_TIMEFRAME,
            n_bars    = config.BARS_TO_FETCH,
            use_mt5   = not demo_mode,
        )
    except Exception as e:
        msg = f"فشلت إعادة التدريب: {e}"
        logger.error(msg)
        notify_error(msg)


# ──────────────────────────────────────────────────────────
# التقرير اليومي
# ──────────────────────────────────────────────────────────

def send_daily_report():
    """إرسال تقرير يومي عبر تيليجرام."""
    try:
        from broker.mt5_connector import account_summary, MT5_AVAILABLE
        info = account_summary() if MT5_AVAILABLE else {}
        notify_daily_report(
            balance        = info.get("balance", 0.0),
            equity         = info.get("equity",  0.0),
            daily_profit   = state.profit_today,
            total_trades   = state.trades_today,
            winning_trades = state.wins_today,
        )
    except Exception as e:
        logger.error(f"خطأ في إرسال التقرير اليومي: {e}")


# ──────────────────────────────────────────────────────────
# نقطة الدخول
# ──────────────────────────────────────────────────────────

def main():
    parser = argparse.ArgumentParser(description="روبوت تداول بالذكاء الاصطناعي")
    parser.add_argument("--demo",       action="store_true", help="وضع العرض بدون تنفيذ صفقات")
    parser.add_argument("--train-only", action="store_true", help="تدريب النموذج فقط")
    parser.add_argument("--test-telegram", action="store_true", help="اختبار اتصال تيليجرام")
    args = parser.parse_args()

    # ── اختبار تيليجرام ───────────────────────────────────
    if args.test_telegram:
        logger.info("اختبار اتصال تيليجرام...")
        test_connection()
        return

    # ── التدريب فقط ───────────────────────────────────────
    if args.train_only:
        logger.info("🏋️ تشغيل التدريب فقط...")
        full_training_pipeline(
            symbol    = config.SYMBOLS[0],
            timeframe = config.DEFAULT_TIMEFRAME,
            n_bars    = config.BARS_TO_FETCH,
            use_mt5   = False,
        )
        return

    # ── الوضع الكامل ──────────────────────────────────────
    demo = args.demo
    mode = "🎭 وضع العرض" if demo else "🔴 وضع حي"
    logger.info(f"\n{'='*60}")
    logger.info(f"  🤖 روبوت تداول AI | {mode}")
    logger.info(f"  الرموز: {', '.join(config.SYMBOLS)}")
    logger.info(f"  الإطار: {config.DEFAULT_TIMEFRAME}")
    logger.info(f"  الفحص كل: {config.SCAN_INTERVAL_MINUTES} دقيقة")
    logger.info(f"{'='*60}\n")

    # الاتصال بـ MT5 (اختياري — يعمل بدونه على Linux)
    mt5_connected = connect_mt5()
    if not demo and not mt5_connected:
        logger.warning("⚠️ MT5 غير متاح — سيعمل البوت مع Yahoo Finance (بدون تنفيذ صفقات حقيقية)")
        demo = True   # تحويل تلقائي لوضع المحاكاة

    # إشعار البدء
    notify_bot_started()

    # التدريب الأولي إذا لم يكن النموذج موجوداً
    import os
    if not os.path.exists(config.MODEL_PATH):
        logger.info("🏋️ تدريب النموذج للمرة الأولى...")
        retrain_model(demo)

    # فحص فوري عند البدء
    scan_market(demo)

    # ── جدولة المهام ──────────────────────────────────────
    schedule.every(config.SCAN_INTERVAL_MINUTES).minutes.do(
        scan_market, demo_mode=demo
    )
    schedule.every(config.RETRAIN_HOURS).hours.do(
        retrain_model, demo_mode=demo
    )
    schedule.every().day.at("22:00").do(send_daily_report)

    logger.info(f"⏰ الجدولة: فحص كل {config.SCAN_INTERVAL_MINUTES} دقيقة")
    logger.info("📡 الروبوت يعمل... (Ctrl+C للإيقاف)\n")

    # ── الحلقة الرئيسية ────────────────────────────────────
    try:
        while True:
            schedule.run_pending()
            time.sleep(30)   # فحص الجدول كل 30 ثانية
    except KeyboardInterrupt:
        logger.info("\n🛑 تم إيقاف الروبوت يدوياً")
    finally:
        if not demo:
            disconnect_mt5()
        logger.info("👋 وداعاً!")


if __name__ == "__main__":
    main()
