# ============================================================
# data/collector.py — جمع البيانات التاريخية وبيانات السوق
# ============================================================
# الدور:
#   مسؤول عن جلب بيانات OHLCV (افتتاح، أعلى، أدنى، إغلاق، حجم)
#   من MetaTrader 5 أو Yahoo Finance كبديل للاختبار.
#   الناتج: DataFrame جاهز للتحليل والتدريب.
#
# المكتبات: MetaTrader5, yfinance, pandas, numpy
# ============================================================

import yfinance as yf
import pandas as pd
import numpy as np
from datetime import datetime, timedelta
from loguru import logger
import sys
import os

# MetaTrader5 يعمل على Windows فقط — يُحمَّل بشكل اختياري
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    mt5 = None
    MT5_AVAILABLE = False
    logger.info("ℹ️ MetaTrader5 غير متاح على هذا النظام — سيُستخدم Yahoo Finance تلقائياً")

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


# ──────────────────────────────────────────────────────────
# الاتصال بـ MetaTrader 5
# ──────────────────────────────────────────────────────────

def connect_mt5() -> bool:
    """
    تهيئة الاتصال بمنصة MetaTrader 5.
    تُعيد False تلقائياً على Linux أو عند غياب المكتبة.
    """
    if not MT5_AVAILABLE:
        logger.info("ℹ️ MT5 غير متاح — سيُستخدم Yahoo Finance")
        return False
    if not mt5.initialize(
        path=config.MT5_PATH,
        login=config.MT5_LOGIN,
        password=config.MT5_PASSWORD,
        server=config.MT5_SERVER,
    ):
        logger.error(f"فشل تهيئة MT5: {mt5.last_error()}")
        return False

    info = mt5.account_info()
    if info is None:
        logger.error("تعذّر جلب معلومات الحساب.")
        return False

    logger.info(
        f"✅ متصل بـ MT5 | الحساب: {info.login} | الرصيد: {info.balance} {info.currency}"
    )
    return True


def disconnect_mt5():
    """قطع الاتصال بـ MT5 وتحرير الموارد."""
    if not MT5_AVAILABLE:
        return
    mt5.shutdown()
    logger.info("🔌 تم قطع الاتصال بـ MT5")


# ──────────────────────────────────────────────────────────
# تحويل الإطار الزمني
# ──────────────────────────────────────────────────────────

_TF_MAP = {
    "M1":  1,
    "M5":  5,
    "M15": 15,
    "M30": 30,
    "H1":  16385,
    "H4":  16388,
    "D1":  16408,
    "W1":  32769,
}
if MT5_AVAILABLE:
    _TF_MAP = {
        "M1":  mt5.TIMEFRAME_M1,
        "M5":  mt5.TIMEFRAME_M5,
        "M15": mt5.TIMEFRAME_M15,
        "M30": mt5.TIMEFRAME_M30,
        "H1":  mt5.TIMEFRAME_H1,
        "H4":  mt5.TIMEFRAME_H4,
        "D1":  mt5.TIMEFRAME_D1,
        "W1":  mt5.TIMEFRAME_W1,
    }


def _resolve_timeframe(tf: str) -> int:
    """تحويل نص الإطار الزمني إلى ثابت MT5."""
    val = _TF_MAP.get(tf.upper())
    if val is None:
        raise ValueError(f"إطار زمني غير معروف: {tf}. الخيارات: {list(_TF_MAP)}")
    return val


# ──────────────────────────────────────────────────────────
# جلب البيانات من MT5
# ──────────────────────────────────────────────────────────

def fetch_ohlcv_mt5(
    symbol: str,
    timeframe: str = "H1",
    n_bars: int = 5000,
) -> pd.DataFrame:
    """
    جلب بيانات الشموع من MetaTrader 5.

    المعاملات:
        symbol    — رمز الأصل (مثال: "EURUSD")
        timeframe — الإطار الزمني (مثال: "H1")
        n_bars    — عدد الشموع المطلوبة

    العائد: DataFrame بالأعمدة:
        time, open, high, low, close, tick_volume, spread
    """
    tf = _resolve_timeframe(timeframe)

    # جلب الشموع من MT5
    rates = mt5.copy_rates_from_pos(symbol, tf, 0, n_bars)

    if rates is None or len(rates) == 0:
        logger.warning(f"لا توجد بيانات لـ {symbol} على {timeframe}")
        return pd.DataFrame()

    df = pd.DataFrame(rates)

    # تحويل الطابع الزمني من Unix إلى datetime
    df["time"] = pd.to_datetime(df["time"], unit="s", utc=True)
    df.set_index("time", inplace=True)

    # الاحتفاظ فقط بالأعمدة الضرورية
    cols = ["open", "high", "low", "close", "tick_volume", "spread"]
    df = df[[c for c in cols if c in df.columns]].copy()
    df.rename(columns={"tick_volume": "volume"}, inplace=True)

    df.sort_index(inplace=True)
    logger.info(f"📊 MT5 | {symbol} {timeframe}: {len(df)} شمعة")
    return df


# ──────────────────────────────────────────────────────────
# جلب البيانات من Yahoo Finance (بديل للاختبار)
# ──────────────────────────────────────────────────────────

# خريطة تحويل رموز MT5 إلى رموز Yahoo Finance
_YAHOO_SYMBOLS = {
    "EURUSD": "EURUSD=X",
    "GBPUSD": "GBPUSD=X",
    "USDJPY": "USDJPY=X",
    "XAUUSD": "GC=F",
    "BTCUSD": "BTC-USD",
    "ETHUSD": "ETH-USD",
}

_YAHOO_TF = {
    "M1": "1m", "M5": "5m", "M15": "15m", "M30": "30m",
    "H1": "1h", "H4": "1h",   # Yahoo لا يدعم H4 مباشرة
    "D1": "1d", "W1": "1wk",
}


def fetch_ohlcv_yahoo(
    symbol: str,
    timeframe: str = "H1",
    n_bars: int = 5000,
) -> pd.DataFrame:
    """
    جلب بيانات الشموع من Yahoo Finance.
    مفيد للاختبار بدون MT5 أو في بيئة Linux.

    المعاملات:
        symbol    — رمز MT5 (يُحوَّل تلقائياً لرمز Yahoo)
        timeframe — الإطار الزمني
        n_bars    — عدد الشموع التقريبي

    العائد: DataFrame بنفس هيكل MT5
    """
    yahoo_sym = _YAHOO_SYMBOLS.get(symbol, symbol)
    yahoo_tf  = _YAHOO_TF.get(timeframe.upper(), "1h")

    # تقدير فترة الجلب بحسب الإطار الزمني
    tf_minutes = {"1m": 1, "5m": 5, "15m": 15, "30m": 30,
                  "1h": 60, "1d": 1440, "1wk": 10080}.get(yahoo_tf, 60)
    days_needed = max(7, int((n_bars * tf_minutes) / (60 * 16)) + 5)
    period = f"{min(days_needed, 730)}d"

    ticker = yf.Ticker(yahoo_sym)
    df = ticker.history(period=period, interval=yahoo_tf)

    if df.empty:
        logger.warning(f"لا توجد بيانات Yahoo لـ {symbol}")
        return pd.DataFrame()

    df.index = pd.to_datetime(df.index, utc=True)
    df.columns = [c.lower() for c in df.columns]
    df = df[["open", "high", "low", "close", "volume"]].copy()
    df.sort_index(inplace=True)

    # أخذ آخر n_bars شمعة فقط
    df = df.tail(n_bars)

    logger.info(f"📊 Yahoo | {symbol} ({yahoo_sym}) {timeframe}: {len(df)} شمعة")
    return df


# ──────────────────────────────────────────────────────────
# واجهة موحّدة (تستخدمها بقية أجزاء المشروع)
# ──────────────────────────────────────────────────────────

def fetch_ohlcv(
    symbol: str,
    timeframe: str = "H1",
    n_bars: int = 5000,
    use_mt5: bool = True,
) -> pd.DataFrame:
    """
    واجهة موحّدة: تحاول MT5 أولاً، ثم تنتقل إلى Yahoo تلقائياً.

    المعاملات:
        symbol    — رمز الأصل
        timeframe — الإطار الزمني
        n_bars    — عدد الشموع
        use_mt5   — True لمحاولة MT5 أولاً

    العائد: DataFrame جاهز أو DataFrame فارغ عند الفشل
    """
    if use_mt5:
        df = fetch_ohlcv_mt5(symbol, timeframe, n_bars)
        if not df.empty:
            return df
        logger.warning("MT5 فشل، جاري التبديل إلى Yahoo Finance...")

    return fetch_ohlcv_yahoo(symbol, timeframe, n_bars)


# ──────────────────────────────────────────────────────────
# سعر السوق الحالي
# ──────────────────────────────────────────────────────────

def get_current_price(symbol: str) -> dict:
    """
    جلب أسعار البيع والشراء الحالية من MT5.
    على Linux يُعيد سعر الإغلاق الأخير من Yahoo.

    العائد: {'bid': float, 'ask': float, 'spread': float}
    """
    if not MT5_AVAILABLE:
        df = fetch_ohlcv_yahoo(symbol, "M5", n_bars=2)
        if df.empty:
            return {}
        price = float(df["close"].iloc[-1])
        return {"bid": price, "ask": price, "spread": 0.0, "time": datetime.utcnow()}

    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        logger.error(f"تعذّر جلب سعر {symbol}")
        return {}

    return {
        "bid":    tick.bid,
        "ask":    tick.ask,
        "spread": round(tick.ask - tick.bid, 5),
        "time":   datetime.fromtimestamp(tick.time),
    }


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=== اختبار جلب البيانات من Yahoo Finance ===")
    df = fetch_ohlcv("EURUSD", timeframe="H1", n_bars=200, use_mt5=False)
    print(df.tail())
    print(f"\nالأعمدة: {list(df.columns)}")
    print(f"عدد الصفوف: {len(df)}")
