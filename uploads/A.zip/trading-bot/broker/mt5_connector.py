# ============================================================
# broker/mt5_connector.py — تنفيذ الصفقات عبر MetaTrader 5
# ============================================================
# ⚠️ هذا الملف يعمل على Windows فقط مع MT5 مثبّتاً
# على Linux يُعيد قيم وهمية بدون أخطاء
# ============================================================

import pandas as pd
from datetime import datetime
from loguru import logger
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config

# تحميل MT5 بشكل اختياري
try:
    import MetaTrader5 as mt5
    MT5_AVAILABLE = True
except ImportError:
    mt5 = None
    MT5_AVAILABLE = False
    logger.info("ℹ️ broker: MT5 غير متاح — وضع محاكاة للصفقات")


def _no_mt5(fn_name: str) -> dict:
    """رد موحّد عند عدم توفر MT5."""
    logger.warning(f"⚠️ {fn_name}: MT5 غير متاح على هذا النظام")
    return {"success": False, "ticket": 0, "msg": "MT5 غير متاح على Linux"}


# ──────────────────────────────────────────────────────────
# حساب حجم اللوت
# ──────────────────────────────────────────────────────────

def calculate_lot_size(
    symbol: str,
    stop_loss_pips: float,
    risk_percent: float = None,
) -> float:
    """حساب حجم اللوت بناءً على نسبة المخاطرة. يُعيد 0.01 على Linux."""
    if not MT5_AVAILABLE:
        return 0.01

    risk_pct = risk_percent or config.RISK_PERCENT
    account  = mt5.account_info()
    sym_info = mt5.symbol_info(symbol)

    if account is None or sym_info is None:
        return 0.01

    balance     = account.balance
    risk_amount = balance * (risk_pct / 100)
    pip_value   = sym_info.trade_tick_value

    if stop_loss_pips <= 0 or pip_value <= 0:
        return sym_info.volume_min

    raw_lot = risk_amount / (stop_loss_pips * pip_value)
    raw_lot = max(sym_info.volume_min, min(raw_lot, sym_info.volume_max))
    step    = sym_info.volume_step
    lot     = round(raw_lot / step) * step
    lot     = max(sym_info.volume_min, lot)

    logger.info(
        f"📐 اللوت: رصيد={balance:.2f} | خطر={risk_amount:.2f} | "
        f"SL={stop_loss_pips}pip | لوت={lot}"
    )
    return lot


# ──────────────────────────────────────────────────────────
# فتح صفقة
# ──────────────────────────────────────────────────────────

def open_trade(
    symbol:     str,
    order_type: str,
    lot:        float,
    sl_price:   float = 0.0,
    tp_price:   float = 0.0,
    comment:    str   = "AI_Bot",
    magic:      int   = 20240101,
) -> dict:
    """فتح صفقة سوق. يُعيد رسالة توضيحية على Linux."""
    if not MT5_AVAILABLE:
        logger.info(f"🎭 محاكاة: {order_type} {lot} لوت {symbol} | SL={sl_price} TP={tp_price}")
        return {"success": True, "ticket": 0, "msg": "محاكاة — MT5 غير متاح"}

    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        return {"success": False, "ticket": 0, "msg": f"لا يمكن جلب سعر {symbol}"}

    spread_pts = (tick.ask - tick.bid) * 10 ** mt5.symbol_info(symbol).digits
    if spread_pts > config.MAX_SPREAD_POINTS:
        msg = f"السبريد عالٍ جداً ({spread_pts:.1f} > {config.MAX_SPREAD_POINTS})"
        logger.warning(f"⛔ {msg}")
        return {"success": False, "ticket": 0, "msg": msg}

    if order_type.upper() == "BUY":
        mt5_type = mt5.ORDER_TYPE_BUY
        price    = tick.ask
    elif order_type.upper() == "SELL":
        mt5_type = mt5.ORDER_TYPE_SELL
        price    = tick.bid
    else:
        return {"success": False, "ticket": 0, "msg": f"نوع أمر غير معروف: {order_type}"}

    request = {
        "action":       mt5.TRADE_ACTION_DEAL,
        "symbol":       symbol,
        "volume":       lot,
        "type":         mt5_type,
        "price":        price,
        "sl":           sl_price,
        "tp":           tp_price,
        "deviation":    20,
        "magic":        magic,
        "comment":      comment,
        "type_time":    mt5.ORDER_TIME_GTC,
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)
    if result is None:
        msg = f"فشل الإرسال: {mt5.last_error()}"
        logger.error(f"❌ {msg}")
        return {"success": False, "ticket": 0, "msg": msg}

    if result.retcode == mt5.TRADE_RETCODE_DONE:
        logger.info(f"✅ صفقة مفتوحة | {order_type} {lot} {symbol} @ {price:.5f} | تذكرة: {result.order}")
        return {"success": True, "ticket": int(result.order), "msg": "تم بنجاح"}
    else:
        msg = f"خطأ {result.retcode}: {result.comment}"
        logger.error(f"❌ فشل فتح الصفقة: {msg}")
        return {"success": False, "ticket": 0, "msg": msg}


# ──────────────────────────────────────────────────────────
# إغلاق صفقة
# ──────────────────────────────────────────────────────────

def close_trade(ticket: int) -> dict:
    """إغلاق صفقة مفتوحة. لا تعمل على Linux."""
    if not MT5_AVAILABLE:
        return _no_mt5("close_trade")

    positions = mt5.positions_get(ticket=ticket)
    position  = positions[0] if positions else None

    if position is None:
        return {"success": False, "profit": 0.0, "msg": f"الصفقة {ticket} غير موجودة"}

    symbol = position.symbol
    lot    = position.volume
    tick   = mt5.symbol_info_tick(symbol)

    if tick is None:
        return {"success": False, "profit": 0.0, "msg": "لا يمكن جلب السعر"}

    if position.type == mt5.ORDER_TYPE_BUY:
        close_type = mt5.ORDER_TYPE_SELL
        price      = tick.bid
    else:
        close_type = mt5.ORDER_TYPE_BUY
        price      = tick.ask

    request = {
        "action":       mt5.TRADE_ACTION_DEAL,
        "position":     ticket,
        "symbol":       symbol,
        "volume":       lot,
        "type":         close_type,
        "price":        price,
        "deviation":    20,
        "comment":      "AI_Bot_Close",
        "type_filling": mt5.ORDER_FILLING_IOC,
    }

    result = mt5.order_send(request)
    if result and result.retcode == mt5.TRADE_RETCODE_DONE:
        profit = position.profit
        logger.info(f"✅ إغلاق الصفقة {ticket} | ربح: {profit:.2f}")
        return {"success": True, "profit": profit, "msg": "تم الإغلاق"}
    else:
        code = result.retcode if result else "None"
        return {"success": False, "profit": 0.0, "msg": f"فشل الإغلاق: {code}"}


# ──────────────────────────────────────────────────────────
# جلب الصفقات المفتوحة
# ──────────────────────────────────────────────────────────

def get_open_positions(symbol: str = None) -> pd.DataFrame:
    """جلب الصفقات المفتوحة. يُعيد DataFrame فارغ على Linux."""
    if not MT5_AVAILABLE:
        return pd.DataFrame()

    positions = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()

    if not positions:
        return pd.DataFrame()

    data = []
    for p in positions:
        data.append({
            "ticket":        p.ticket,
            "symbol":        p.symbol,
            "type":          "BUY" if p.type == mt5.ORDER_TYPE_BUY else "SELL",
            "volume":        p.volume,
            "open_price":    p.price_open,
            "current_price": p.price_current,
            "sl":            p.sl,
            "tp":            p.tp,
            "profit":        p.profit,
            "magic":         p.magic,
            "comment":       p.comment,
            "open_time":     datetime.fromtimestamp(p.time),
        })
    return pd.DataFrame(data)


# ──────────────────────────────────────────────────────────
# حساب SL/TP من ATR
# ──────────────────────────────────────────────────────────

def calculate_sl_tp(
    symbol:     str,
    order_type: str,
    atr:        float,
) -> tuple[float, float]:
    """
    حساب أسعار SL/TP بناءً على ATR.
    على Linux يُعيد أصفاراً (لا تنفيذ حقيقي).
    """
    if not MT5_AVAILABLE:
        return 0.0, 0.0

    tick     = mt5.symbol_info_tick(symbol)
    sym_info = mt5.symbol_info(symbol)

    if tick is None or sym_info is None:
        return 0.0, 0.0

    sl_dist = atr * config.STOP_LOSS_ATR
    tp_dist = atr * config.TAKE_PROFIT_ATR

    if order_type.upper() == "BUY":
        price    = tick.ask
        sl_price = round(price - sl_dist, sym_info.digits)
        tp_price = round(price + tp_dist, sym_info.digits)
    else:
        price    = tick.bid
        sl_price = round(price + sl_dist, sym_info.digits)
        tp_price = round(price - tp_dist, sym_info.digits)

    logger.debug(f"SL/TP | {order_type} {symbol} @ {price:.5f} | SL={sl_price:.5f} TP={tp_price:.5f}")
    return sl_price, tp_price


# ──────────────────────────────────────────────────────────
# ملخص الحساب
# ──────────────────────────────────────────────────────────

def account_summary() -> dict:
    """إرجاع ملخص حساب MT5. يُعيد dict فارغ على Linux."""
    if not MT5_AVAILABLE:
        return {"msg": "MT5 غير متاح"}

    info = mt5.account_info()
    if info is None:
        return {}
    return {
        "login":       info.login,
        "balance":     info.balance,
        "equity":      info.equity,
        "margin":      info.margin,
        "free_margin": info.margin_free,
        "profit":      info.profit,
        "currency":    info.currency,
        "leverage":    info.leverage,
        "server":      info.server,
    }
