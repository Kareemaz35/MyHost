# ============================================================
# model/trainer.py — تدريب نموذج الذكاء الاصطناعي
# ============================================================
# الدور:
#   تدريب نموذج XGBoost على البيانات التاريخية المعالجة،
#   تقييم أدائه، واختيار أفضل الخصائص تلقائياً.
#   النموذج يتعلم متى يكون الشراء مربحاً بناءً على
#   المؤشرات الفنية وأنماط الشموع والأخبار.
#
# المكتبات: xgboost, scikit-learn, pandas, numpy, joblib
# ============================================================

import numpy as np
import pandas as pd
from sklearn.model_selection import TimeSeriesSplit, cross_val_score
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import (
    classification_report, confusion_matrix,
    roc_auc_score, precision_score, recall_score, f1_score
)
from sklearn.feature_selection import SelectFromModel
import xgboost as xgb
import joblib
import matplotlib
matplotlib.use("Agg")   # بدون نافذة عرض (للسيرفر)
import matplotlib.pyplot as plt
from loguru import logger
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from data.collector import fetch_ohlcv
from data.preprocessor import preprocess, get_feature_columns


# ──────────────────────────────────────────────────────────
# تحضير البيانات للتدريب
# ──────────────────────────────────────────────────────────

def prepare_training_data(
    symbol: str = "EURUSD",
    timeframe: str = "H1",
    n_bars: int = 5000,
    lookahead: int = 1,
    use_mt5: bool = True,
) -> tuple[np.ndarray, np.ndarray, list[str]]:
    """
    جمع البيانات وتحضيرها للتدريب.

    الخطوات:
        1. جلب بيانات OHLCV
        2. المعالجة وإضافة الخصائص
        3. فصل X (خصائص) عن y (هدف)
        4. إزالة الخصائص ذات القيم الثابتة أو شبه الثابتة

    العائد: (X, y, feature_names)
    """
    logger.info(f"⏳ تحضير بيانات التدريب | {symbol} {timeframe} | {n_bars} شمعة")

    df_raw = fetch_ohlcv(symbol, timeframe, n_bars=n_bars, use_mt5=use_mt5)
    if df_raw.empty:
        raise RuntimeError(f"لا يمكن جلب بيانات {symbol}")

    df = preprocess(df_raw, add_target_col=True, lookahead=lookahead)

    features = get_feature_columns(df)
    X = df[features].values.astype(np.float32)
    y = df["target"].values.astype(int)

    # حذف الخصائص ذات التباين الصفري
    std = X.std(axis=0)
    valid_mask = std > 1e-8
    X = X[:, valid_mask]
    features = [f for f, v in zip(features, valid_mask) if v]

    logger.info(
        f"✅ البيانات جاهزة | الصفوف: {len(X)} | "
        f"الخصائص: {len(features)} | "
        f"نسبة الشراء: {y.mean():.1%}"
    )
    return X, y, features


# ──────────────────────────────────────────────────────────
# التحقق من أن البيانات متوازنة
# ──────────────────────────────────────────────────────────

def check_class_balance(y: np.ndarray) -> dict:
    """
    فحص توازن الفئات (شراء vs. لا شراء).
    إذا كان الخلل كبيراً نستخدم أوزاناً مرجّحة.
    """
    buy_pct  = y.mean()
    sell_pct = 1 - buy_pct
    ratio    = max(buy_pct, sell_pct) / min(buy_pct, sell_pct) if min(buy_pct, sell_pct) > 0 else 999

    balanced = ratio < 2.0
    logger.info(
        f"📊 توازن الفئات: شراء={buy_pct:.1%} | بيع={sell_pct:.1%} | "
        f"{'متوازن ✅' if balanced else 'غير متوازن ⚠️'}"
    )
    return {"buy_pct": buy_pct, "sell_pct": sell_pct, "ratio": ratio, "balanced": balanced}


# ──────────────────────────────────────────────────────────
# بناء وتدريب النموذج
# ──────────────────────────────────────────────────────────

def build_model(scale_pos_weight: float = 1.0) -> xgb.XGBClassifier:
    """
    بناء نموذج XGBoost مُعدَّل للتداول.

    لماذا XGBoost؟
        - يتعامل جيداً مع بيانات جدولية مثل مؤشرات التداول
        - مقاوم للإفراط في التدريب مع المعلمات الصحيحة
        - سريع جداً في التنبؤ (مهم للتداول الآني)
        - يعطي أهمية الخصائص مجاناً

    المعلمات الرئيسية:
        n_estimators    — عدد الأشجار (100-500)
        max_depth       — عمق الشجرة (3-6 للتداول)
        learning_rate   — معدل التعلم (0.01-0.1)
        scale_pos_weight— لتصحيح اختلال الفئات
    """
    return xgb.XGBClassifier(
        n_estimators       = 300,
        max_depth          = 5,
        learning_rate      = 0.05,
        subsample          = 0.8,       # 80% من البيانات لكل شجرة
        colsample_bytree   = 0.8,       # 80% من الخصائص لكل شجرة
        min_child_weight   = 5,         # يمنع الإفراط في التدريب
        gamma              = 0.1,       # تنظيم إضافي
        reg_alpha          = 0.1,       # L1 regularization
        reg_lambda         = 1.0,       # L2 regularization
        scale_pos_weight   = scale_pos_weight,
        use_label_encoder  = False,
        eval_metric        = "auc",
        random_state       = 42,
        n_jobs             = -1,        # استخدام كل الأنوية المتاحة
        verbosity          = 0,
    )


def train(
    X: np.ndarray,
    y: np.ndarray,
    feature_names: list[str],
    train_ratio: float = 0.8,
) -> tuple[xgb.XGBClassifier, StandardScaler, list[str]]:
    """
    تدريب النموذج الكامل.

    الخطوات:
        1. تقسيم زمني (لا عشوائي!) للتدريب والاختبار
        2. تطبيع الخصائص باستخدام StandardScaler
        3. حساب وزن الفئات للتعامل مع الاختلال
        4. التدريب مع مراقبة التحقق
        5. اختيار أفضل الخصائص (Feature Selection)
        6. إعادة التدريب بالخصائص المختارة

    التقسيم الزمني مهم جداً في التداول:
        لا يجب أن تتداخل بيانات التدريب مع الاختبار
        لأن ذلك يسبب "تسرب البيانات" ونتائج وهمية.

    العائد: (model, scaler, selected_features)
    """
    split_idx = int(len(X) * train_ratio)
    X_train, X_test = X[:split_idx], X[split_idx:]
    y_train, y_test = y[:split_idx], y[split_idx:]

    logger.info(
        f"🔀 التقسيم: تدريب={len(X_train)} | اختبار={len(X_test)} "
        f"({100*(1-train_ratio):.0f}% اختبار)"
    )

    # تطبيع الخصائص
    scaler = StandardScaler()
    X_train_sc = scaler.fit_transform(X_train)
    X_test_sc  = scaler.transform(X_test)

    # وزن الفئات
    balance = check_class_balance(y_train)
    spw = balance["sell_pct"] / balance["buy_pct"] if balance["buy_pct"] > 0 else 1.0

    # ── المرحلة الأولى: تدريب كامل ────────────────────────
    logger.info("🏋️ تدريب المرحلة الأولى (كل الخصائص)...")
    model_full = build_model(scale_pos_weight=spw)
    model_full.fit(
        X_train_sc, y_train,
        eval_set=[(X_test_sc, y_test)],
        verbose=False,
    )

    # ── اختيار الخصائص المهمة ─────────────────────────────
    selector = SelectFromModel(model_full, threshold="median", prefit=True)
    selected_mask   = selector.get_support()
    selected_features = [f for f, s in zip(feature_names, selected_mask) if s]

    logger.info(
        f"🎯 الخصائص المختارة: {len(selected_features)}/{len(feature_names)}"
    )

    X_train_sel = X_train_sc[:, selected_mask]
    X_test_sel  = X_test_sc[:, selected_mask]

    # ── المرحلة الثانية: تدريب بالخصائص المختارة ─────────
    logger.info("🏋️ تدريب المرحلة الثانية (خصائص مختارة)...")
    model = build_model(scale_pos_weight=spw)
    model.fit(
        X_train_sel, y_train,
        eval_set=[(X_test_sel, y_test)],
        verbose=False,
    )

    # ── التقييم ───────────────────────────────────────────
    _evaluate(model, X_test_sel, y_test)

    return model, scaler, selected_features


# ──────────────────────────────────────────────────────────
# تقييم النموذج
# ──────────────────────────────────────────────────────────

def _evaluate(model, X_test: np.ndarray, y_test: np.ndarray):
    """طباعة مقاييس الأداء الكاملة."""
    y_pred  = model.predict(X_test)
    y_proba = model.predict_proba(X_test)[:, 1]

    logger.info("\n" + "="*50)
    logger.info("📈 نتائج تقييم النموذج:")
    logger.info(f"  AUC-ROC   : {roc_auc_score(y_test, y_proba):.4f}")
    logger.info(f"  Precision : {precision_score(y_test, y_pred):.4f}")
    logger.info(f"  Recall    : {recall_score(y_test, y_pred):.4f}")
    logger.info(f"  F1 Score  : {f1_score(y_test, y_pred):.4f}")
    logger.info("\nتقرير التصنيف الكامل:")
    logger.info("\n" + classification_report(y_test, y_pred,
                target_names=["لا شراء", "شراء"]))
    logger.info("="*50)


# ──────────────────────────────────────────────────────────
# حفظ وتحميل النموذج
# ──────────────────────────────────────────────────────────

def save_model(
    model,
    scaler: StandardScaler,
    features: list[str],
    model_path: str = None,
    scaler_path: str = None,
):
    """حفظ النموذج والمطبّع وأسماء الخصائص على الديسك."""
    model_path  = model_path  or config.MODEL_PATH
    scaler_path = scaler_path or config.SCALER_PATH

    os.makedirs(os.path.dirname(model_path),  exist_ok=True)
    os.makedirs(os.path.dirname(scaler_path), exist_ok=True)

    joblib.dump({"model": model, "features": features}, model_path)
    joblib.dump(scaler, scaler_path)

    logger.info(f"💾 النموذج محفوظ: {model_path}")
    logger.info(f"💾 المطبّع محفوظ: {scaler_path}")


def load_model(
    model_path: str = None,
    scaler_path: str = None,
) -> tuple:
    """تحميل النموذج المحفوظ مسبقاً."""
    model_path  = model_path  or config.MODEL_PATH
    scaler_path = scaler_path or config.SCALER_PATH

    if not os.path.exists(model_path):
        raise FileNotFoundError(f"النموذج غير موجود: {model_path}")

    data    = joblib.load(model_path)
    scaler  = joblib.load(scaler_path)
    model   = data["model"]
    features= data["features"]

    logger.info(f"✅ تم تحميل النموذج | {len(features)} خاصية")
    return model, scaler, features


# ──────────────────────────────────────────────────────────
# رسم أهمية الخصائص
# ──────────────────────────────────────────────────────────

def plot_feature_importance(
    model,
    feature_names: list[str],
    top_n: int = 20,
    save_path: str = "model/feature_importance.png",
):
    """رسم وحفظ أهمية أفضل N خاصية."""
    importances = pd.Series(
        model.feature_importances_, index=feature_names
    ).sort_values(ascending=True).tail(top_n)

    fig, ax = plt.subplots(figsize=(10, 8))
    importances.plot(kind="barh", ax=ax, color="#2196F3")
    ax.set_title(f"أهم {top_n} خصيصة في النموذج", fontsize=14)
    ax.set_xlabel("الأهمية النسبية")
    plt.tight_layout()

    os.makedirs(os.path.dirname(save_path), exist_ok=True)
    plt.savefig(save_path, dpi=120, bbox_inches="tight")
    plt.close()
    logger.info(f"📊 مخطط الأهمية محفوظ: {save_path}")


# ──────────────────────────────────────────────────────────
# الدالة الرئيسية للتدريب الكامل
# ──────────────────────────────────────────────────────────

def full_training_pipeline(
    symbol:    str  = "EURUSD",
    timeframe: str  = "H1",
    n_bars:    int  = 5000,
    use_mt5:   bool = True,
):
    """
    خط أنابيب التدريب الكامل من البداية إلى النهاية.
    استدعِ هذه الدالة لتدريب نموذج جديد أو إعادة التدريب.
    """
    logger.info(f"\n{'='*60}")
    logger.info(f"🤖 بدء تدريب نموذج AI | {symbol} {timeframe}")
    logger.info(f"{'='*60}")

    # 1. تحضير البيانات
    X, y, features = prepare_training_data(symbol, timeframe, n_bars, use_mt5=use_mt5)

    # 2. التدريب
    model, scaler, selected_features = train(X, y, features)

    # 3. الحفظ
    save_model(model, scaler, selected_features)

    # 4. رسم الأهمية
    plot_feature_importance(model, selected_features)

    logger.info("🎉 التدريب اكتمل بنجاح!")
    return model, scaler, selected_features


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    model, scaler, features = full_training_pipeline(
        symbol="EURUSD", timeframe="H1", n_bars=1000, use_mt5=False
    )
    print(f"\nالخصائص المختارة ({len(features)}):")
    for f in features[:10]:
        print(f"  - {f}")
