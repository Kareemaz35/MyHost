# ============================================================
# model/predictor.py — التنبؤ باستخدام النموذج المدرّب
# ============================================================
# الدور:
#   تحميل النموذج المحفوظ وتشغيله على بيانات جديدة
#   للحصول على إشارة تداول مع درجة الثقة.
#   هذا الملف هو "عقل" الروبوت عند التشغيل الفعلي.
#
# المكتبات: numpy, pandas, joblib
# ============================================================

import numpy as np
import pandas as pd
from loguru import logger
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from data.preprocessor import preprocess, get_feature_columns
from model.trainer import load_model


class TradingPredictor:
    """
    مُنبّئ التداول: يحمّل النموذج مرة واحدة ويستخدمه للتنبؤ.

    مثال الاستخدام:
        predictor = TradingPredictor()
        result = predictor.predict(df_ohlcv)
        if result['signal'] == 'BUY' and result['confidence'] > 0.65:
            # افتح صفقة شراء
    """

    def __init__(self):
        self._model    = None
        self._scaler   = None
        self._features = None
        self._loaded   = False

    def load(self) -> bool:
        """تحميل النموذج من الملف. يُستدعى تلقائياً عند أول تنبؤ."""
        if self._loaded:
            return True
        try:
            self._model, self._scaler, self._features = load_model()
            self._loaded = True
            return True
        except FileNotFoundError:
            logger.error(
                "❌ النموذج غير موجود! "
                "شغّل trainer.py أولاً لتدريب النموذج."
            )
            return False

    def predict(self, df_raw: pd.DataFrame) -> dict:
        """
        تشغيل التنبؤ على DataFrame من بيانات OHLCV.

        الخطوات:
            1. معالجة البيانات (بدون إضافة عمود الهدف)
            2. اختيار الخصائص التي تدرّب عليها النموذج
            3. تطبيع القيم بنفس المطبّع المستخدم في التدريب
            4. الحصول على الاحتمال من النموذج
            5. تحويله إلى إشارة واضحة

        العائد: {
            'signal':     str,   'BUY' / 'SELL' / 'NEUTRAL'
            'confidence': float,  0.0 - 1.0
            'prob_buy':   float,  احتمال الصعود
            'prob_sell':  float,  احتمال الهبوط
        }
        """
        if not self.load():
            return self._neutral_result("النموذج غير محمّل")

        if df_raw is None or df_raw.empty:
            return self._neutral_result("بيانات فارغة")

        if len(df_raw) < 210:
            return self._neutral_result(f"بيانات غير كافية ({len(df_raw)} < 210 شمعة)")

        try:
            # معالجة البيانات
            df = preprocess(df_raw, add_target_col=False)

            if df.empty:
                return self._neutral_result("فشلت المعالجة")

            # اختيار آخر صف (الشمعة الأحدث)
            available = get_feature_columns(df)
            missing   = [f for f in self._features if f not in available]

            if missing:
                logger.warning(f"خصائص مفقودة ({len(missing)}): {missing[:5]}")
                # ملء الخصائص المفقودة بالصفر
                for feat in missing:
                    df[feat] = 0.0

            # الصف الأخير فقط
            X = df[self._features].iloc[[-1]].values.astype(np.float32)

            # تطبيع
            X_sc = self._scaler.transform(X)

            # التنبؤ
            prob  = self._model.predict_proba(X_sc)[0]
            prob_sell, prob_buy = float(prob[0]), float(prob[1])

            # تحديد الإشارة
            if prob_buy >= config.MIN_CONFIDENCE:
                signal     = "BUY"
                confidence = prob_buy
            elif prob_sell >= config.MIN_CONFIDENCE:
                signal     = "SELL"
                confidence = prob_sell
            else:
                signal     = "NEUTRAL"
                confidence = max(prob_buy, prob_sell)

            result = {
                "signal":     signal,
                "confidence": round(confidence, 4),
                "prob_buy":   round(prob_buy, 4),
                "prob_sell":  round(prob_sell, 4),
            }

            logger.info(
                f"🤖 تنبؤ: {signal} | "
                f"ثقة={confidence:.1%} | "
                f"P(شراء)={prob_buy:.3f} P(بيع)={prob_sell:.3f}"
            )
            return result

        except Exception as e:
            logger.error(f"خطأ في التنبؤ: {e}")
            return self._neutral_result(str(e))

    @staticmethod
    def _neutral_result(reason: str = "") -> dict:
        """نتيجة محايدة عند وجود خطأ أو عدم الثقة الكافية."""
        if reason:
            logger.debug(f"نتيجة محايدة: {reason}")
        return {
            "signal":     "NEUTRAL",
            "confidence": 0.0,
            "prob_buy":   0.5,
            "prob_sell":  0.5,
        }


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    from data.collector import fetch_ohlcv

    df = fetch_ohlcv("EURUSD", "H1", n_bars=300, use_mt5=False)
    pred = TradingPredictor()
    result = pred.predict(df)

    print(f"\n{'='*40}")
    print(f"الإشارة   : {result['signal']}")
    print(f"الثقة     : {result['confidence']:.1%}")
    print(f"P(شراء)   : {result['prob_buy']:.3f}")
    print(f"P(بيع)    : {result['prob_sell']:.3f}")
