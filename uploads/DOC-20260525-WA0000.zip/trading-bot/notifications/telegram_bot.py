# ============================================================
# notifications/telegram_bot.py — إشعارات تيليجرام
# ============================================================
# الدور:
#   إرسال إشعارات فورية عبر بوت تيليجرام عند:
#   - فتح صفقة جديدة
#   - إغلاق صفقة (مع نتيجة الربح/الخسارة)
#   - تحذيرات المخاطر
#   - التقارير اليومية
#   - إشارات تحليل السوق
#
# إعداد البوت:
#   1. افتح تيليجرام وتحدث مع @BotFather
#   2. اكتب /newbot واتبع التعليمات
#   3. احصل على TOKEN وضعه في .env
#   4. أرسل رسالة للبوت ثم افتح:
#      https://api.telegram.org/bot<TOKEN>/getUpdates
#      لمعرفة CHAT_ID
#
# المكتبات: python-telegram-bot, aiohttp
# ============================================================

import asyncio
import aiohttp
from datetime import datetime
from loguru import logger
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


# ──────────────────────────────────────────────────────────
# إرسال الرسائل (واجهة بسيطة بدون مكتبة)
# ──────────────────────────────────────────────────────────

async def _send_async(text: str, parse_mode: str = "HTML") -> bool:
    """إرسال رسالة نصية عبر Telegram Bot API بشكل غير متزامن."""
    if not config.TELEGRAM_TOKEN or not config.TELEGRAM_CHAT_ID:
        logger.warning("⚠️ TELEGRAM_TOKEN أو TELEGRAM_CHAT_ID غير مُعيَّن")
        return False

    url  = f"https://api.telegram.org/bot{config.TELEGRAM_TOKEN}/sendMessage"
    data = {
        "chat_id":    config.TELEGRAM_CHAT_ID,
        "text":       text,
        "parse_mode": parse_mode,
    }

    try:
        async with aiohttp.ClientSession() as session:
            async with session.post(url, json=data, timeout=aiohttp.ClientTimeout(total=10)) as resp:
                if resp.status == 200:
                    return True
                body = await resp.text()
                logger.error(f"Telegram API خطأ {resp.status}: {body[:200]}")
                return False
    except Exception as e:
        logger.error(f"خطأ في إرسال تيليجرام: {e}")
        return False


def send_message(text: str, parse_mode: str = "HTML") -> bool:
    """
    إرسال رسالة نصية (واجهة متزامنة للاستخدام خارج async).
    تُنشئ حلقة أحداث مؤقتة إذا لم تكن موجودة.
    """
    try:
        loop = asyncio.get_event_loop()
        if loop.is_running():
            # داخل بيئة async — أنشئ مهمة
            future = asyncio.ensure_future(_send_async(text, parse_mode))
            return True
        else:
            return loop.run_until_complete(_send_async(text, parse_mode))
    except RuntimeError:
        return asyncio.run(_send_async(text, parse_mode))


# ──────────────────────────────────────────────────────────
# قوالب الرسائل
# ──────────────────────────────────────────────────────────

def notify_trade_opened(
    symbol:     str,
    order_type: str,
    lot:        float,
    price:      float,
    sl:         float,
    tp:         float,
    confidence: float,
    ticket:     int,
) -> bool:
    """
    إشعار فتح صفقة جديدة.

    مثال الرسالة:
    ┌─────────────────────────────┐
    │ 🟢 صفقة شراء مفتوحة         │
    │ 📊 EURUSD | H1              │
    │ 💰 السعر: 1.08523           │
    │ 🎯 TP: 1.08923 (+40 pip)   │
    │ 🛡️ SL: 1.08323 (-20 pip)   │
    │ 🤖 ثقة AI: 72%              │
    │ 🎫 تذكرة: #123456           │
    └─────────────────────────────┘
    """
    emoji  = "🟢" if order_type == "BUY" else "🔴"
    action = "شراء" if order_type == "BUY" else "بيع"

    sl_pips = round(abs(price - sl) * 10000, 1) if sl else "—"
    tp_pips = round(abs(tp - price) * 10000, 1) if tp else "—"

    msg = (
        f"{emoji} <b>صفقة {action} مفتوحة</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>الرمز:</b>   {symbol}\n"
        f"📦 <b>الحجم:</b>   {lot} لوت\n"
        f"💰 <b>السعر:</b>   {price:.5f}\n"
        f"🎯 <b>TP:</b>      {tp:.5f} <i>(+{tp_pips} pip)</i>\n"
        f"🛡️ <b>SL:</b>      {sl:.5f} <i>(-{sl_pips} pip)</i>\n"
        f"🤖 <b>ثقة AI:</b>  {confidence:.0%}\n"
        f"🎫 <b>تذكرة:</b>   #{ticket}\n"
        f"🕐 <b>الوقت:</b>   {datetime.now().strftime('%H:%M:%S')}"
    )
    return send_message(msg)


def notify_trade_closed(
    symbol:     str,
    order_type: str,
    profit:     float,
    ticket:     int,
    pips:       float = 0.0,
) -> bool:
    """إشعار إغلاق صفقة مع نتيجة الربح/الخسارة."""
    if profit > 0:
        emoji  = "💚"
        result = f"ربح: +{profit:.2f}$"
    elif profit < 0:
        emoji  = "💔"
        result = f"خسارة: {profit:.2f}$"
    else:
        emoji  = "⚪"
        result = "تعادل: 0.00$"

    action = "شراء" if order_type == "BUY" else "بيع"

    msg = (
        f"{emoji} <b>إغلاق صفقة {action}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>الرمز:</b>   {symbol}\n"
        f"💵 <b>النتيجة:</b> {result}\n"
        f"📏 <b>النقاط:</b>  {pips:+.1f} pip\n"
        f"🎫 <b>تذكرة:</b>   #{ticket}\n"
        f"🕐 <b>الوقت:</b>   {datetime.now().strftime('%H:%M:%S')}"
    )
    return send_message(msg)


def notify_signal(
    symbol:       str,
    timeframe:    str,
    signal:       str,
    confidence:   float,
    indicators:   dict,
    news_label:   str = "neutral",
    candle_bias:  str = "neutral",
) -> bool:
    """
    إشعار إشارة تحليل بدون فتح صفقة.
    مفيد لمراقبة السوق وتنبيه المستخدم يدوياً.
    """
    sig_emoji = {"BUY": "📈", "SELL": "📉", "NEUTRAL": "➖"}.get(signal, "❓")
    news_emoji= {"bullish": "📰✅", "bearish": "📰❌", "neutral": "📰➖"}.get(news_label, "📰")
    cand_emoji= {"bull": "🕯️✅", "bear": "🕯️❌", "neutral": "🕯️➖"}.get(candle_bias, "🕯️")

    buy_c  = indicators.get("buy_count", 0)
    sell_c = indicators.get("sell_count", 0)
    atr    = indicators.get("atr", 0)

    msg = (
        f"{sig_emoji} <b>إشارة تحليل: {signal}</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"📊 <b>الرمز:</b>       {symbol} ({timeframe})\n"
        f"🤖 <b>ثقة AI:</b>      {confidence:.0%}\n"
        f"📈 <b>المؤشرات:</b>    شراء={buy_c} | بيع={sell_c}\n"
        f"{news_emoji} <b>الأخبار:</b>     {news_label}\n"
        f"{cand_emoji} <b>الشموع:</b>      {candle_bias}\n"
        f"📏 <b>ATR:</b>         {atr:.5f}\n"
        f"🕐 <b>الوقت:</b>       {datetime.now().strftime('%H:%M:%S')}"
    )
    return send_message(msg)


def notify_daily_report(
    balance:       float,
    equity:        float,
    daily_profit:  float,
    total_trades:  int,
    winning_trades:int,
) -> bool:
    """تقرير يومي شامل عن أداء الروبوت."""
    win_rate = (winning_trades / total_trades * 100) if total_trades else 0
    profit_emoji = "📈" if daily_profit >= 0 else "📉"

    msg = (
        f"📋 <b>التقرير اليومي</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"💰 <b>الرصيد:</b>       {balance:.2f}$\n"
        f"⚖️ <b>الحقوق:</b>       {equity:.2f}$\n"
        f"{profit_emoji} <b>ربح اليوم:</b>    {daily_profit:+.2f}$\n"
        f"🔢 <b>إجمالي الصفقات:</b> {total_trades}\n"
        f"✅ <b>الرابحة:</b>       {winning_trades} ({win_rate:.1f}%)\n"
        f"❌ <b>الخاسرة:</b>       {total_trades - winning_trades}\n"
        f"📅 <b>التاريخ:</b>       {datetime.now().strftime('%Y-%m-%d')}"
    )
    return send_message(msg)


def notify_error(error_msg: str) -> bool:
    """إشعار خطأ أو تحذير."""
    msg = (
        f"⚠️ <b>تنبيه من البوت</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"❌ {error_msg}\n"
        f"🕐 {datetime.now().strftime('%H:%M:%S')}"
    )
    return send_message(msg)


def notify_bot_started() -> bool:
    """إشعار تشغيل البوت."""
    msg = (
        f"🤖 <b>البوت يعمل الآن!</b>\n"
        f"━━━━━━━━━━━━━━━━━━━\n"
        f"✅ تم الاتصال بـ MT5\n"
        f"✅ النموذج محمّل\n"
        f"📡 يراقب السوق...\n"
        f"🕐 {datetime.now().strftime('%Y-%m-%d %H:%M:%S')}"
    )
    return send_message(msg)


# ──────────────────────────────────────────────────────────
# اختبار الاتصال
# ──────────────────────────────────────────────────────────

def test_connection() -> bool:
    """إرسال رسالة اختبار للتحقق من صحة الإعداد."""
    msg = (
        "✅ <b>اختبار البوت ناجح!</b>\n"
        "الإعداد صحيح والبوت جاهز للعمل."
    )
    success = send_message(msg)
    if success:
        logger.info("✅ اختبار تيليجرام ناجح")
    else:
        logger.error("❌ فشل اختبار تيليجرام — تحقق من TOKEN و CHAT_ID")
    return success


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=== اختبار بوت تيليجرام ===")
    print("سيُرسَل إشعار اختبار إلى الدردشة المحددة في .env")
    print("إذا لم يصل الإشعار تحقق من TELEGRAM_TOKEN و TELEGRAM_CHAT_ID\n")
    result = test_connection()
    print(f"النتيجة: {'✅ نجح' if result else '❌ فشل'}")
