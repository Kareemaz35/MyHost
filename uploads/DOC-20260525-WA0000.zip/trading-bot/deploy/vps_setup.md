# دليل رفع المشروع على VPS

## لماذا VPS؟
الروبوت يحتاج أن يعمل **24 ساعة يومياً / 7 أيام أسبوعياً**.
جهازك الشخصي ينام ويغلق — VPS لا ينام أبداً.

---

## الخيارات الموصى بها (VPS للتداول)

| المزوّد | الخطة | السعر/شهر | الملاحظة |
|---------|-------|------------|----------|
| **Vultr** | Cloud Compute | $6-12 | موصى به للمبتدئين |
| **DigitalOcean** | Droplet Basic | $6-12 | واجهة سهلة |
| **Contabo** | VPS S | $5 | الأرخص، أداء جيد |
| **Linode** | Nanode | $5 | موثوق جداً |

> ⚠️ اختر سيرفراً في **أوروبا أو أمريكا** لأقل تأخير مع متصلي الفوركس

**المتطلبات الدنيا:**
- نظام: **Ubuntu 22.04 LTS**
- RAM: 2GB (4GB أفضل للنموذج)
- CPU: 2 نواة
- التخزين: 20GB SSD

---

## المرحلة 1: الاتصال بالـ VPS

```bash
# من جهازك الشخصي (Windows: استخدم PuTTY أو Windows Terminal)
ssh root@YOUR_VPS_IP

# مثال:
ssh root@192.168.1.100
```

---

## المرحلة 2: إعداد البيئة على VPS

```bash
# تحديث النظام
apt update && apt upgrade -y

# تثبيت Python 3.11
apt install -y python3.11 python3.11-pip python3.11-venv git screen curl wget

# التحقق
python3.11 --version   # يجب أن يظهر 3.11.x

# إنشاء مستخدم خاص بالبوت (أمان أفضل من root)
adduser tradingbot
usermod -aG sudo tradingbot
su - tradingbot
```

---

## المرحلة 3: رفع الكود

### الطريقة أ: عبر Git (الأسهل)
```bash
# على VPS
git clone https://github.com/YOUR_USERNAME/trading-bot.git
cd trading-bot
```

### الطريقة ب: رفع مباشر بـ SCP (من جهازك)
```bash
# من جهازك الشخصي
scp -r trading-bot/ root@YOUR_VPS_IP:/home/tradingbot/
```

### الطريقة ج: FileZilla (واجهة رسومية)
1. حمّل FileZilla
2. استخدم SFTP مع بيانات VPS

---

## المرحلة 4: إعداد البيئة الافتراضية وتثبيت المكتبات

```bash
# على VPS — داخل مجلد المشروع
cd /home/tradingbot/trading-bot

# إنشاء بيئة افتراضية
python3.11 -m venv venv
source venv/bin/activate   # تفعيل البيئة

# تثبيت المكتبات
pip install --upgrade pip
pip install -r requirements.txt

# ملاحظة: تثبيت المكتبات يستغرق 3-10 دقائق
```

---

## المرحلة 5: إعداد ملف .env

```bash
# إنشاء ملف الإعدادات السرية
nano .env
```

```
# الصق هذا المحتوى وعدّل القيم:
MT5_LOGIN=123456789
MT5_PASSWORD=your_password
MT5_SERVER=ICMarkets-Demo
MT5_PATH=/opt/wine/mt5/terminal64.exe

TELEGRAM_TOKEN=1234567890:ABCdef...
TELEGRAM_CHAT_ID=-1001234567890

NEWS_API_KEY=your_api_key
```

```bash
# احفظ: Ctrl+O ثم Enter ثم Ctrl+X
# حماية الملف من القراءة الخارجية
chmod 600 .env
```

---

## المرحلة 6: MetaTrader 5 على Linux (باستخدام Wine)

> ℹ️ MT5 برنامج Windows. نستخدم Wine لتشغيله على Linux.

```bash
# تثبيت Wine
dpkg --add-architecture i386
wget -nc https://dl.winehq.org/wine-builds/winehq.key
apt-key add winehq.key
add-apt-repository 'deb https://dl.winehq.org/wine-builds/ubuntu/ jammy main'
apt update
apt install -y winehq-stable winetricks

# تثبيت .NET (مطلوب لـ MT5)
winetricks -q dotnet48

# تحميل وتثبيت MT5
wget https://download.mql5.com/cdn/web/metaquotes.software.corp/mt5/mt5setup.exe
wine mt5setup.exe

# تشغيل MT5
wine ~/.wine/drive_c/Program\ Files/MetaTrader\ 5/terminal64.exe &
```

**بديل أسهل: استخدم بيانات Yahoo بدل MT5 على VPS**
```python
# في config.py غيّر:
USE_MT5 = False   # استخدام Yahoo Finance بدلاً من MT5
```

---

## المرحلة 7: التدريب الأولي للنموذج

```bash
# تأكد من تفعيل البيئة الافتراضية
source venv/bin/activate

# تدريب النموذج (يستغرق 2-10 دقائق)
python main.py --train-only

# التحقق من نجاح التدريب
ls -la model/
# يجب أن ترى: saved_model.pkl  scaler.pkl
```

---

## المرحلة 8: اختبار تيليجرام

```bash
python main.py --test-telegram
# يجب أن تصلك رسالة على تيليجرام
```

---

## المرحلة 9: تشغيل الروبوت بشكل دائم

### الطريقة أ: screen (الأبسط)

```bash
# إنشاء جلسة screen منفصلة
screen -S tradingbot

# تشغيل الروبوت
source venv/bin/activate
python main.py --demo   # جرّب Demo أولاً

# للخروج من screen مع إبقاء الروبوت يعمل
# اضغط: Ctrl+A ثم D

# للرجوع إلى الجلسة لاحقاً
screen -r tradingbot
```

### الطريقة ب: systemd (الأحترف — يُعيد التشغيل تلقائياً)

```bash
# إنشاء ملف الخدمة
sudo nano /etc/systemd/system/tradingbot.service
```

```ini
[Unit]
Description=AI Trading Bot
After=network.target
Wants=network-online.target

[Service]
Type=simple
User=tradingbot
WorkingDirectory=/home/tradingbot/trading-bot
Environment=PATH=/home/tradingbot/trading-bot/venv/bin
ExecStart=/home/tradingbot/trading-bot/venv/bin/python main.py
Restart=always
RestartSec=60
StandardOutput=journal
StandardError=journal

[Install]
WantedBy=multi-user.target
```

```bash
# تفعيل وتشغيل الخدمة
sudo systemctl daemon-reload
sudo systemctl enable tradingbot
sudo systemctl start tradingbot

# التحقق من الحالة
sudo systemctl status tradingbot

# مشاهدة السجلات المباشرة
sudo journalctl -u tradingbot -f
```

---

## المرحلة 10: المراقبة والصيانة

```bash
# مشاهدة سجلات اليوم
tail -f logs/trading_bot_$(date +%Y-%m-%d).log

# إعادة تشغيل الروبوت
sudo systemctl restart tradingbot

# إيقاف الروبوت
sudo systemctl stop tradingbot

# فحص استخدام الموارد
htop   # شاشة المراقبة (ثبّتها بـ: apt install htop)
```

---

## إعداد الأمان الأساسي للـ VPS

```bash
# 1. تغيير كلمة مرور SSH
passwd root

# 2. تغيير منفذ SSH الافتراضي (اختياري لكن مفيد)
nano /etc/ssh/sshd_config
# غيّر: Port 22  →  Port 2222
systemctl restart ssh

# 3. إعداد جدار الحماية
ufw allow 2222/tcp   # SSH (المنفذ الجديد)
ufw enable

# 4. تعطيل تسجيل الدخول بكلمة المرور (استخدم SSH Keys)
# هذه خطوة متقدمة — ابحث عن "SSH Key Authentication Ubuntu"
```

---

## جدول التحديثات الدورية

```bash
# كل أسبوع: تحديث الكود من Git
cd /home/tradingbot/trading-bot
git pull origin main
sudo systemctl restart tradingbot

# كل شهر: تحديث المكتبات
source venv/bin/activate
pip install --upgrade -r requirements.txt

# كل شهر: تحديث نظام التشغيل
apt update && apt upgrade -y
```

---

## حل المشاكل الشائعة

| المشكلة | الحل |
|---------|------|
| الروبوت يتوقف فجأة | تحقق من السجلات: `journalctl -u tradingbot --since "1 hour ago"` |
| خطأ في MT5 | تحقق من اتصال الإنترنت وبيانات الحساب |
| الذاكرة ممتلئة | `free -h` وإعادة تشغيل الروبوت |
| النموذج لا يتحسن | زد بيانات التدريب أو عدّل المعلمات |
| تيليجرام لا يرسل | تحقق من TOKEN و CHAT_ID في .env |
