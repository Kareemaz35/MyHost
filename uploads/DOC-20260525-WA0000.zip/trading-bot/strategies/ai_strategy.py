# ============================================================
# strategies/ai_strategy.py — استراتيجية التداول بالذكاء الاصطناعي
# ============================================================
# الدور:
#   تجميع جميع مكوّنات المشروع في استراتيجية متكاملة:
#   النموذج + المؤشرات الفنية + الشموع + الأخبار → قرار تداول.
#
#   منطق القرار (نظام تصويت ثلاثي):
#   ┌────────────────────────────────────────────────────┐
#   │  1. تنبؤ AI         (وزن: 40%)                     │
#   │  2. المؤشرات الفنية  (وزن: 35%)                     │
#   │  3. أنماط الشموع    (وزن: 15%)                     │
#   │  4. مشاعر الأخبار   (وزن: 10%)                     │
#   └────────────────────────────────────────────────────┘
#   إذا تجاوز المجموع المرجّح عتبة معيّنة → دخول صفقة
#
# المكتبات: جميع المكونات الداخلية
# ============================================================

from dataclasses import dataclass, field
from loguru import logger
import pandas as pd
import sys, os

sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config
from indicators.technical   import aggregate_signals, Signal
from indicators.candlestick import detect_patterns, patterns_summary
from news.analyzer          import get_market_sentiment
from model.predictor        import TradingPredictor


# ──────────────────────────────────────────────────────────
# هيكل قرار التداول
# ──────────────────────────────────────────────────────────

@dataclass
class TradeDecision:
    """قرار التداول الشامل."""
    symbol:          str
    timeframe:       str
    action:          str          # "BUY" / "SELL" / "NEUTRAL"
    composite_score: float        # -1 (بيع قوي) ... +1 (شراء قوي)
    ai_confidence:   float        # ثقة نموذج AI
    tech_signal:     str          # إشارة المؤشرات الفنية
    candle_bias:     str          # تحيّز الشموع
    news_label:      str          # مشاعر الأخبار
    news_score:      float        # درجة الأخبار
    atr:             float        # متوسط المدى الحقيقي
    reasons:         list = field(default_factory=list)   # أسباب القرار
    timestamp:       str  = ""


# ──────────────────────────────────────────────────────────
# الاستراتيجية
# ──────────────────────────────────────────────────────────

class AITradingStrategy:
    """
    استراتيجية التداول المدعومة بالذكاء الاصطناعي.

    الأوزان:
        AI            — 40%  (الأهم)
        مؤشرات فنية   — 35%
        أنماط الشموع  — 15%
        أخبار          — 10%

    عتبة الدخول:
        composite_score >= +0.5  → شراء
        composite_score <= -0.5  → بيع
        بينهما                   → محايد
    """

    WEIGHT_AI     = 0.40
    WEIGHT_TECH   = 0.35
    WEIGHT_CANDLE = 0.15
    WEIGHT_NEWS   = 0.10

    BUY_THRESHOLD  = +0.50
    SELL_THRESHOLD = -0.50

    def __init__(self):
        self._predictor = TradingPredictor()

    # ──────────────────────────────────────────
    # الدالة الرئيسية: تحليل وقرار
    # ──────────────────────────────────────────

    def analyze(
        self,
        symbol:    str,
        timeframe: str,
        df:        pd.DataFrame,
        use_news:  bool = True,
    ) -> TradeDecision:
        """
        تحليل شامل لأصل مالي وإصدار قرار التداول.

        المعاملات:
            symbol    — رمز الأصل
            timeframe — الإطار الزمني
            df        — DataFrame بيانات OHLCV
            use_news  — هل نستخدم تحليل الأخبار؟

        العائد: TradeDecision كامل
        """
        reasons = []
        scores  = {}    # تجميع الدرجات المرجّحة

        # ── 1. تنبؤ نموذج AI ────────────────────────────
        ai_result = self._predictor.predict(df)
        ai_signal  = ai_result["signal"]
        ai_conf    = ai_result["confidence"]
        ai_prob_b  = ai_result["prob_buy"]
        ai_prob_s  = ai_result["prob_sell"]

        # تحويل إشارة AI إلى درجة: +1 شراء، -1 بيع، 0 محايد
        if ai_signal == "BUY":
            ai_score = ai_prob_b
            reasons.append(f"🤖 AI: شراء (ثقة {ai_conf:.0%})")
        elif ai_signal == "SELL":
            ai_score = -ai_prob_s
            reasons.append(f"🤖 AI: بيع (ثقة {ai_conf:.0%})")
        else:
            ai_score = ai_prob_b - ai_prob_s
            reasons.append(f"🤖 AI: محايد ({ai_prob_b:.2f} vs {ai_prob_s:.2f})")

        scores["ai"] = ai_score * self.WEIGHT_AI

        # ── 2. المؤشرات الفنية ──────────────────────────
        tech_agg    = aggregate_signals(df)
        tech_sig    = tech_agg["signal"]
        tech_conf   = tech_agg["confidence"]
        atr         = tech_agg["atr"]
        buy_c       = tech_agg["buy_count"]
        sell_c      = tech_agg["sell_count"]

        if tech_sig == Signal.BUY:
            tech_score = tech_conf
            reasons.append(f"📊 مؤشرات: شراء ({buy_c}/{buy_c+sell_c})")
        elif tech_sig == Signal.SELL:
            tech_score = -tech_conf
            reasons.append(f"📊 مؤشرات: بيع ({sell_c}/{buy_c+sell_c})")
        else:
            tech_score = (buy_c - sell_c) / max(buy_c + sell_c, 1) * tech_conf
            reasons.append(f"📊 مؤشرات: محايدة")

        scores["tech"] = tech_score * self.WEIGHT_TECH

        # ── 3. أنماط الشموع ─────────────────────────────
        patterns      = detect_patterns(df)
        candle_summ   = patterns_summary(patterns)
        candle_bias   = candle_summ["bias"]
        candle_str    = candle_summ["strength"]
        candle_names  = [p["name"] for p in candle_summ["list"]]

        if candle_bias == "bull":
            candle_score = candle_str
            reasons.append(f"🕯️ شموع: صاعدة ({', '.join(candle_names[:2])})")
        elif candle_bias == "bear":
            candle_score = -candle_str
            reasons.append(f"🕯️ شموع: هابطة ({', '.join(candle_names[:2])})")
        else:
            candle_score = 0.0
            reasons.append("🕯️ شموع: لا أنماط واضحة")

        scores["candle"] = candle_score * self.WEIGHT_CANDLE

        # ── 4. تحليل الأخبار ────────────────────────────
        news_score = 0.0
        news_label = "neutral"

        if use_news:
            news_result = get_market_sentiment(symbol, hours_back=12)
            news_score  = news_result["score"]
            news_label  = news_result["label"]
            n_articles  = news_result["article_count"]

            if news_label == "bullish":
                reasons.append(f"📰 أخبار: إيجابية ({n_articles} خبر، درجة={news_score:+.2f})")
            elif news_label == "bearish":
                reasons.append(f"📰 أخبار: سلبية ({n_articles} خبر، درجة={news_score:+.2f})")
            else:
                reasons.append(f"📰 أخبار: محايدة ({n_articles} خبر)")
        else:
            reasons.append("📰 الأخبار: معطّلة")

        scores["news"] = news_score * self.WEIGHT_NEWS

        # ── 5. حساب الدرجة المركّبة ─────────────────────
        composite = sum(scores.values())
        composite = max(-1.0, min(1.0, composite))  # تثبيت في [-1, +1]

        # ── 6. القرار النهائي ────────────────────────────
        if composite >= self.BUY_THRESHOLD:
            action = "BUY"
        elif composite <= self.SELL_THRESHOLD:
            action = "SELL"
        else:
            action = "NEUTRAL"

        from datetime import datetime
        decision = TradeDecision(
            symbol          = symbol,
            timeframe       = timeframe,
            action          = action,
            composite_score = round(composite, 4),
            ai_confidence   = ai_conf,
            tech_signal     = tech_sig.value,
            candle_bias     = candle_bias,
            news_label      = news_label,
            news_score      = news_score,
            atr             = atr,
            reasons         = reasons,
            timestamp       = datetime.now().strftime("%Y-%m-%d %H:%M:%S"),
        )

        self._log_decision(decision)
        return decision

    # ──────────────────────────────────────────
    # طباعة القرار
    # ──────────────────────────────────────────

    @staticmethod
    def _log_decision(d: TradeDecision):
        action_emoji = {"BUY": "🟢", "SELL": "🔴", "NEUTRAL": "⚪"}.get(d.action, "❓")
        logger.info(
            f"\n{'='*55}\n"
            f"  {action_emoji} القرار: {d.action} | {d.symbol} {d.timeframe}\n"
            f"  الدرجة المركّبة: {d.composite_score:+.4f}\n"
            f"  الأسباب:\n" +
            "\n".join(f"    • {r}" for r in d.reasons) +
            f"\n{'='*55}"
        )


# ──────────────────────────────────────────────────────────
# فحص ما إذا كنا نستطيع فتح صفقة
# ──────────────────────────────────────────────────────────

def can_open_trade(symbol: str, action: str) -> tuple[bool, str]:
    """
    التحقق من الشروط المسبقة قبل فتح صفقة:
        1. عدد الصفقات المفتوحة لا يتجاوز الحد الأقصى
        2. لا توجد صفقة مفتوحة بنفس الاتجاه على نفس الرمز

    العائد: (يمكن_الفتح: bool, السبب: str)
    """
    try:
        from broker.mt5_connector import get_open_positions
        open_pos = get_open_positions()

        if len(open_pos) >= config.MAX_OPEN_TRADES:
            return False, f"وصلنا للحد الأقصى ({config.MAX_OPEN_TRADES} صفقات مفتوحة)"

        if not open_pos.empty:
            same = open_pos[
                (open_pos["symbol"] == symbol) &
                (open_pos["type"]   == action)
            ]
            if not same.empty:
                return False, f"صفقة {action} مفتوحة مسبقاً على {symbol}"

    except Exception as e:
        logger.warning(f"لم نتمكن من فحص الصفقات المفتوحة: {e}")
        return True, ""    # نفترض السماح عند الفشل

    return True, ""


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    from data.collector import fetch_ohlcv

    df = fetch_ohlcv("EURUSD", "H1", n_bars=300, use_mt5=False)
    strategy = AITradingStrategy()
    decision = strategy.analyze("EURUSD", "H1", df, use_news=False)

    print(f"\n{'='*50}")
    print(f"القرار  : {decision.action}")
    print(f"الدرجة  : {decision.composite_score:+.4f}")
    print(f"ATR     : {decision.atr:.5f}")
    print(f"الوقت   : {decision.timestamp}")
    print(f"\nالأسباب:")
    for r in decision.reasons:
        print(f"  {r}")
