# ============================================================
# news/analyzer.py — جلب وتحليل الأخبار الاقتصادية
# ============================================================
# الدور:
#   جلب الأخبار المتعلقة بالأصول المالية وتحليل مشاعرها
#   (إيجابي / سلبي / محايد) باستخدام نموذج NLP.
#   النتيجة: درجة مشاعر عددية تُدخَل في نموذج AI.
#
# المصادر:
#   1. NewsAPI.org       — أخبار عامة (مفتاح مجاني)
#   2. Investing.com RSS — أخبار فوركس واقتصاد (بدون مفتاح)
#   3. ForexFactory      — التقويم الاقتصادي
#
# المكتبات: requests, feedparser, transformers, torch
# ============================================================

import requests
import feedparser
import pandas as pd
from datetime import datetime, timedelta
from dataclasses import dataclass
from loguru import logger

import sys, os
sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
import config


# ──────────────────────────────────────────────────────────
# هيكل الخبر
# ──────────────────────────────────────────────────────────

@dataclass
class NewsArticle:
    title:      str
    description: str
    source:     str
    url:        str
    published:  datetime
    sentiment:  float = 0.0    # -1 سلبي جداً ... +1 إيجابي جداً


# ──────────────────────────────────────────────────────────
# جلب الأخبار من NewsAPI.org
# ──────────────────────────────────────────────────────────

# كلمات مفتاحية لكل رمز
_KEYWORDS = {
    "EURUSD": ["EUR", "Euro", "ECB", "European Central Bank", "Eurozone"],
    "GBPUSD": ["GBP", "Pound", "Bank of England", "BOE", "Brexit"],
    "XAUUSD": ["Gold", "XAU", "precious metals", "inflation", "Fed"],
    "BTCUSD": ["Bitcoin", "BTC", "crypto", "cryptocurrency"],
    "USDJPY": ["JPY", "Yen", "Bank of Japan", "BOJ"],
    "DEFAULT": ["forex", "Federal Reserve", "interest rate", "inflation", "GDP"],
}


def fetch_from_newsapi(symbol: str, hours_back: int = 12) -> list[NewsArticle]:
    """
    جلب أخبار من NewsAPI.org المجاني.

    المعاملات:
        symbol     — رمز الأصل (مثال: "EURUSD")
        hours_back — كم ساعة للخلف نبحث في الأخبار

    العائد: قائمة NewsArticle
    """
    if not config.NEWS_API_KEY:
        logger.warning("NEWS_API_KEY غير مُعيَّن — تخطي NewsAPI")
        return []

    keywords = _KEYWORDS.get(symbol, _KEYWORDS["DEFAULT"])
    query    = " OR ".join(keywords[:3])    # أول 3 كلمات فقط

    from_time = (datetime.utcnow() - timedelta(hours=hours_back)).strftime("%Y-%m-%dT%H:%M:%SZ")

    url = "https://newsapi.org/v2/everything"
    params = {
        "q":        query,
        "from":     from_time,
        "sortBy":   "relevancy",
        "language": "en",
        "pageSize": 20,
        "apiKey":   config.NEWS_API_KEY,
    }

    try:
        resp = requests.get(url, params=params, timeout=10)
        resp.raise_for_status()
        data = resp.json()
    except Exception as e:
        logger.error(f"خطأ في NewsAPI: {e}")
        return []

    articles = []
    for item in data.get("articles", []):
        pub_str = item.get("publishedAt", "")
        try:
            pub = datetime.fromisoformat(pub_str.replace("Z", "+00:00"))
        except Exception:
            pub = datetime.utcnow()

        articles.append(NewsArticle(
            title       = item.get("title", "") or "",
            description = item.get("description", "") or "",
            source      = item.get("source", {}).get("name", "NewsAPI"),
            url         = item.get("url", ""),
            published   = pub,
        ))

    logger.info(f"📰 NewsAPI: {len(articles)} خبر لـ {symbol}")
    return articles


# ──────────────────────────────────────────────────────────
# جلب الأخبار من RSS (بدون مفتاح API)
# ──────────────────────────────────────────────────────────

_RSS_FEEDS = [
    # فوركس واقتصاد
    "https://feeds.finance.yahoo.com/rss/2.0/headline?s=EURUSD=X&region=US&lang=en-US",
    "https://www.forexlive.com/feed/news",
    "https://www.marketwatch.com/rss/topstories",
    "https://feeds.bbci.co.uk/news/business/rss.xml",
]


def fetch_from_rss(hours_back: int = 12) -> list[NewsArticle]:
    """
    جلب الأخبار من موجزات RSS المجانية.
    لا تحتاج مفتاح API.
    """
    articles = []
    cutoff   = datetime.utcnow() - timedelta(hours=hours_back)

    for feed_url in _RSS_FEEDS:
        try:
            feed = feedparser.parse(feed_url)
            for entry in feed.entries[:10]:
                # محاولة تحليل التاريخ
                pub = datetime.utcnow()
                if hasattr(entry, "published_parsed") and entry.published_parsed:
                    import time
                    pub = datetime(*entry.published_parsed[:6])

                if pub < cutoff:
                    continue

                articles.append(NewsArticle(
                    title       = getattr(entry, "title", ""),
                    description = getattr(entry, "summary", ""),
                    source      = feed.feed.get("title", "RSS"),
                    url         = getattr(entry, "link", ""),
                    published   = pub,
                ))
        except Exception as e:
            logger.warning(f"خطأ في RSS ({feed_url[:40]}...): {e}")

    logger.info(f"📡 RSS: {len(articles)} خبر")
    return articles


# ──────────────────────────────────────────────────────────
# تحليل المشاعر — النسخة الخفيفة (بدون GPU)
# ──────────────────────────────────────────────────────────

class SentimentAnalyzer:
    """
    محلل المشاعر باستخدام نموذج FinBERT المدرّب على النصوص المالية.

    FinBERT هو نموذج BERT مُضبَّط خصيصاً على الأخبار المالية.
    يُصنّف النص إلى: positive / negative / neutral

    ملاحظة: أول تشغيل يتطلب تحميل النموذج (~500MB).
    """

    _instance = None    # Singleton لتحميل النموذج مرة واحدة فقط

    def __new__(cls):
        if cls._instance is None:
            cls._instance = super().__new__(cls)
            cls._instance._loaded = False
        return cls._instance

    def _load(self):
        if self._loaded:
            return
        try:
            from transformers import pipeline
            logger.info("⏳ تحميل نموذج FinBERT...")
            self._pipe = pipeline(
                "text-classification",
                model="ProsusAI/finbert",
                device=-1,          # CPU (-1) أو GPU (0)
                truncation=True,
                max_length=512,
            )
            self._loaded = True
            logger.info("✅ نموذج FinBERT جاهز")
        except Exception as e:
            logger.error(f"فشل تحميل FinBERT: {e}")
            self._pipe = None
            self._loaded = True     # نحدد loaded=True لمنع إعادة المحاولة

    def analyze(self, text: str) -> float:
        """
        تحليل مشاعر نص واحد.

        العائد: درجة من -1.0 (سلبي) إلى +1.0 (إيجابي)
        """
        self._load()

        if not text or not text.strip():
            return 0.0

        if self._pipe is None:
            return self._keyword_fallback(text)

        try:
            result = self._pipe(text[:512])[0]
            label  = result["label"].lower()
            score  = result["score"]

            if label == "positive":
                return round(score, 3)
            elif label == "negative":
                return round(-score, 3)
            else:
                return 0.0
        except Exception as e:
            logger.warning(f"خطأ في تحليل المشاعر: {e}")
            return self._keyword_fallback(text)

    @staticmethod
    def _keyword_fallback(text: str) -> float:
        """
        تحليل بسيط بالكلمات المفتاحية عند عدم توفر النموذج.
        """
        text_lower = text.lower()

        positive_words = [
            "rise", "gain", "rally", "surge", "growth", "bullish",
            "positive", "strong", "beat", "exceed", "record", "up",
            "profit", "boost", "recover", "improve", "increase"
        ]
        negative_words = [
            "fall", "drop", "decline", "crash", "loss", "bearish",
            "negative", "weak", "miss", "below", "concern", "down",
            "risk", "fear", "recession", "cut", "decrease", "plunge"
        ]

        pos_count = sum(1 for w in positive_words if w in text_lower)
        neg_count = sum(1 for w in negative_words if w in text_lower)
        total     = pos_count + neg_count

        if total == 0:
            return 0.0
        return round((pos_count - neg_count) / total, 3)

    def analyze_batch(self, articles: list[NewsArticle]) -> list[NewsArticle]:
        """تحليل قائمة من الأخبار وإضافة درجة المشاعر لكل منها."""
        for article in articles:
            text = f"{article.title}. {article.description}"
            article.sentiment = self.analyze(text)
        return articles


# ──────────────────────────────────────────────────────────
# إجمالي درجة مشاعر السوق
# ──────────────────────────────────────────────────────────

def get_market_sentiment(symbol: str, hours_back: int = 12) -> dict:
    """
    الدالة الرئيسية: جلب الأخبار، تحليل المشاعر، إرجاع الملخص.

    العائد: {
        'score':       float,   # -1 إلى +1
        'label':       str,     # 'bullish' / 'bearish' / 'neutral'
        'article_count': int,
        'top_news':    list,    # أهم 3 أخبار
    }
    """
    # جمع الأخبار من المصادر المتاحة
    articles: list[NewsArticle] = []
    articles += fetch_from_newsapi(symbol, hours_back)
    articles += fetch_from_rss(hours_back)

    if not articles:
        logger.warning(f"لا توجد أخبار لـ {symbol}")
        return {"score": 0.0, "label": "neutral", "article_count": 0, "top_news": []}

    # تحليل المشاعر
    analyzer = SentimentAnalyzer()
    articles = analyzer.analyze_batch(articles)

    # حساب المتوسط المرجّح (أحدث الأخبار لها وزن أكبر)
    if articles:
        scores = [a.sentiment for a in articles]
        avg_score = sum(scores) / len(scores)
    else:
        avg_score = 0.0

    # تصنيف الدرجة
    if avg_score > 0.15:
        label = "bullish"
    elif avg_score < -0.15:
        label = "bearish"
    else:
        label = "neutral"

    # أهم 3 أخبار (الأعلى تأثيراً)
    top = sorted(articles, key=lambda a: abs(a.sentiment), reverse=True)[:3]
    top_news = [
        {"title": a.title, "sentiment": a.sentiment, "source": a.source}
        for a in top
    ]

    result = {
        "score":         round(avg_score, 3),
        "label":         label,
        "article_count": len(articles),
        "top_news":      top_news,
    }

    logger.info(
        f"📰 مشاعر السوق ({symbol}): {label} | "
        f"الدرجة={avg_score:.3f} | {len(articles)} خبر"
    )
    return result


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    print("=== اختبار تحليل مشاعر الأخبار (بدون API key) ===\n")

    # اختبار التحليل بالكلمات المفتاحية
    analyzer = SentimentAnalyzer()
    tests = [
        "Gold prices surge to record high amid inflation concerns",
        "Euro falls sharply after weak GDP data from Eurozone",
        "Federal Reserve maintains interest rates, neutral stance",
    ]
    for text in tests:
        score = analyzer._keyword_fallback(text)
        label = "إيجابي" if score > 0 else ("سلبي" if score < 0 else "محايد")
        print(f"  [{label:^6}] {score:+.2f} — {text[:60]}")

    print("\n=== جلب من RSS (قد يستغرق لحظة) ===")
    rss_articles = fetch_from_rss(hours_back=24)
    print(f"  تم جلب {len(rss_articles)} خبر من RSS")
    if rss_articles:
        print(f"  مثال: {rss_articles[0].title[:80]}")
