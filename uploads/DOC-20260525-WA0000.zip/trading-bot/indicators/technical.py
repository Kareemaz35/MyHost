# ============================================================
# indicators/technical.py — حساب المؤشرات الفنية بالتفصيل
# ============================================================
# الدور:
#   توفير دوال مستقلة لحساب كل مؤشر فني بشكل منفصل،
#   مع تفسير الإشارة (شراء / بيع / محايد) لكل مؤشر.
#   يُستخدم في استراتيجية التداول لتوليد إشارات واضحة.
#
# المكتبات: pandas, numpy, ta
# ============================================================

import pandas as pd
import numpy as np
from dataclasses import dataclass
from enum import Enum
from loguru import logger


class Signal(Enum):
    BUY     = "شراء"
    SELL    = "بيع"
    NEUTRAL = "محايد"


@dataclass
class IndicatorResult:
    """نتيجة موحّدة لأي مؤشر فني."""
    name:   str
    value:  float
    signal: Signal
    note:   str = ""


# ──────────────────────────────────────────────────────────
# RSI — مؤشر القوة النسبية
# ──────────────────────────────────────────────────────────

def rsi_signal(df: pd.DataFrame, window: int = 14) -> IndicatorResult:
    """
    RSI (Relative Strength Index):
        - يقيس سرعة وتغيّر حركة الأسعار (0-100).
        - < 30  → منطقة تشبع بيع → إشارة شراء
        - > 70  → منطقة تشبع شراء → إشارة بيع
        - 30-70 → محايد

    الحساب:
        RS = متوسط المكاسب / متوسط الخسائر (خلال n فترة)
        RSI = 100 - (100 / (1 + RS))
    """
    delta  = df["close"].diff()
    gain   = delta.clip(lower=0)
    loss   = (-delta).clip(lower=0)

    avg_gain = gain.ewm(com=window - 1, min_periods=window).mean()
    avg_loss = loss.ewm(com=window - 1, min_periods=window).mean()

    rs  = avg_gain / avg_loss
    rsi = 100 - (100 / (1 + rs))
    val = round(float(rsi.iloc[-1]), 2)

    if val < 30:
        sig = Signal.BUY
        note = f"RSI={val} — تشبع بيع (Oversold)"
    elif val > 70:
        sig = Signal.SELL
        note = f"RSI={val} — تشبع شراء (Overbought)"
    else:
        sig = Signal.NEUTRAL
        note = f"RSI={val} — منطقة محايدة"

    return IndicatorResult("RSI", val, sig, note)


# ──────────────────────────────────────────────────────────
# MACD — تقارب/تباعد المتوسطات المتحركة
# ──────────────────────────────────────────────────────────

def macd_signal(
    df: pd.DataFrame,
    fast: int = 12,
    slow: int = 26,
    signal_period: int = 9,
) -> IndicatorResult:
    """
    MACD (Moving Average Convergence Divergence):
        - MACD_line   = EMA(12) - EMA(26)
        - Signal_line = EMA(9) لـ MACD_line
        - Histogram   = MACD_line - Signal_line

    الإشارة:
        - MACD يقطع Signal من الأسفل → شراء
        - MACD يقطع Signal من الأعلى → بيع
        - الهيستوغرام يتحول موجباً   → زخم صاعد
    """
    close  = df["close"]
    ema_f  = close.ewm(span=fast,   adjust=False).mean()
    ema_s  = close.ewm(span=slow,   adjust=False).mean()
    macd   = ema_f - ema_s
    sig    = macd.ewm(span=signal_period, adjust=False).mean()
    hist   = macd - sig

    macd_now  = float(macd.iloc[-1])
    sig_now   = float(sig.iloc[-1])
    hist_now  = float(hist.iloc[-1])
    hist_prev = float(hist.iloc[-2])

    if hist_now > 0 and hist_prev <= 0:
        signal = Signal.BUY
        note = f"MACD تقاطع صاعد | Hist={hist_now:.5f}"
    elif hist_now < 0 and hist_prev >= 0:
        signal = Signal.SELL
        note = f"MACD تقاطع هابط | Hist={hist_now:.5f}"
    elif hist_now > 0:
        signal = Signal.BUY
        note = f"MACD هيستوغرام موجب | Hist={hist_now:.5f}"
    elif hist_now < 0:
        signal = Signal.SELL
        note = f"MACD هيستوغرام سالب | Hist={hist_now:.5f}"
    else:
        signal = Signal.NEUTRAL
        note = "MACD محايد"

    return IndicatorResult("MACD", round(macd_now, 5), signal, note)


# ──────────────────────────────────────────────────────────
# Bollinger Bands — نطاقات بولنجر
# ──────────────────────────────────────────────────────────

def bollinger_signal(
    df: pd.DataFrame,
    window: int = 20,
    std_dev: float = 2.0,
) -> IndicatorResult:
    """
    Bollinger Bands:
        - Upper = SMA(20) + 2*STD
        - Lower = SMA(20) - 2*STD
        - Width = (Upper - Lower) / Mid

    الإشارة:
        - السعر يلمس النطاق السفلي → شراء (ارتداد محتمل)
        - السعر يلمس النطاق العلوي → بيع
        - انضغاط النطاق → توقع حركة كبيرة قريبة
    """
    close  = df["close"]
    mid    = close.rolling(window).mean()
    std    = close.rolling(window).std()
    upper  = mid + std_dev * std
    lower  = mid - std_dev * std

    c_now = float(close.iloc[-1])
    u_now = float(upper.iloc[-1])
    l_now = float(lower.iloc[-1])
    m_now = float(mid.iloc[-1])

    pct_b = (c_now - l_now) / (u_now - l_now) if (u_now - l_now) != 0 else 0.5

    if c_now <= l_now:
        signal = Signal.BUY
        note = f"السعر عند النطاق السفلي | %B={pct_b:.2f}"
    elif c_now >= u_now:
        signal = Signal.SELL
        note = f"السعر عند النطاق العلوي | %B={pct_b:.2f}"
    else:
        signal = Signal.NEUTRAL
        note = f"السعر داخل النطاق | %B={pct_b:.2f}"

    return IndicatorResult("BB", round(pct_b, 3), signal, note)


# ──────────────────────────────────────────────────────────
# ATR — متوسط المدى الحقيقي
# ──────────────────────────────────────────────────────────

def atr_value(df: pd.DataFrame, window: int = 14) -> float:
    """
    ATR (Average True Range):
        يقيس مستوى التذبذب. لا يعطي إشارة شراء/بيع لكنه
        يُستخدم لتحديد حجم Stop Loss و Take Profit.

    True Range = max(
        High - Low,
        |High - Close_prev|,
        |Low  - Close_prev|
    )
    """
    high  = df["high"]
    low   = df["low"]
    close = df["close"]

    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs(),
    ], axis=1).max(axis=1)

    atr = tr.ewm(com=window - 1, min_periods=window).mean()
    return round(float(atr.iloc[-1]), 5)


# ──────────────────────────────────────────────────────────
# EMA — المتوسطات المتحركة الأسية
# ──────────────────────────────────────────────────────────

def ema_signal(
    df: pd.DataFrame,
    fast: int = 9,
    slow: int = 21,
) -> IndicatorResult:
    """
    تقاطع المتوسطات المتحركة:
        - EMA(fast) يقطع EMA(slow) من الأسفل → شراء (Golden Cross)
        - EMA(fast) يقطع EMA(slow) من الأعلى → بيع (Death Cross)
    """
    close    = df["close"]
    ema_fast = close.ewm(span=fast, adjust=False).mean()
    ema_slow = close.ewm(span=slow, adjust=False).mean()

    diff_now  = float(ema_fast.iloc[-1]) - float(ema_slow.iloc[-1])
    diff_prev = float(ema_fast.iloc[-2]) - float(ema_slow.iloc[-2])

    if diff_now > 0 and diff_prev <= 0:
        signal = Signal.BUY
        note = f"EMA{fast} قطع EMA{slow} من الأسفل (Golden Cross)"
    elif diff_now < 0 and diff_prev >= 0:
        signal = Signal.SELL
        note = f"EMA{fast} قطع EMA{slow} من الأعلى (Death Cross)"
    elif diff_now > 0:
        signal = Signal.BUY
        note = f"EMA{fast} > EMA{slow} — اتجاه صاعد"
    else:
        signal = Signal.SELL
        note = f"EMA{fast} < EMA{slow} — اتجاه هابط"

    return IndicatorResult(f"EMA{fast}/{slow}", round(diff_now, 5), signal, note)


# ──────────────────────────────────────────────────────────
# ADX — مؤشر قوة الاتجاه
# ──────────────────────────────────────────────────────────

def adx_signal(df: pd.DataFrame, window: int = 14) -> IndicatorResult:
    """
    ADX (Average Directional Index):
        يقيس قوة الاتجاه (ليس الاتجاه نفسه).
        - ADX < 20  → سوق عرضي (لا اتجاه واضح)
        - ADX 20-40 → اتجاه معتدل
        - ADX > 40  → اتجاه قوي جداً

    +DI و -DI يحددان اتجاه الحركة.
    """
    high  = df["high"]
    low   = df["low"]
    close = df["close"]

    dm_pos = high.diff()
    dm_neg = -low.diff()
    dm_pos = dm_pos.where((dm_pos > dm_neg) & (dm_pos > 0), 0)
    dm_neg = dm_neg.where((dm_neg > dm_pos) & (dm_neg > 0), 0)

    prev_close = close.shift(1)
    tr = pd.concat([
        high - low,
        (high - prev_close).abs(),
        (low  - prev_close).abs(),
    ], axis=1).max(axis=1)

    atr    = tr.ewm(com=window - 1, min_periods=window).mean()
    di_pos = 100 * dm_pos.ewm(com=window - 1, min_periods=window).mean() / atr
    di_neg = 100 * dm_neg.ewm(com=window - 1, min_periods=window).mean() / atr
    dx     = 100 * (di_pos - di_neg).abs() / (di_pos + di_neg)
    adx    = dx.ewm(com=window - 1, min_periods=window).mean()

    adx_val = round(float(adx.iloc[-1]), 2)
    dip_val = round(float(di_pos.iloc[-1]), 2)
    din_val = round(float(di_neg.iloc[-1]), 2)

    if adx_val < 20:
        signal = Signal.NEUTRAL
        note = f"ADX={adx_val} — سوق عرضي، تجنب الدخول"
    elif dip_val > din_val:
        signal = Signal.BUY
        note = f"ADX={adx_val} — اتجاه صاعد | +DI={dip_val} > -DI={din_val}"
    else:
        signal = Signal.SELL
        note = f"ADX={adx_val} — اتجاه هابط | -DI={din_val} > +DI={dip_val}"

    return IndicatorResult("ADX", adx_val, signal, note)


# ──────────────────────────────────────────────────────────
# تجميع الإشارات: تصويت الأغلبية
# ──────────────────────────────────────────────────────────

def aggregate_signals(df: pd.DataFrame) -> dict:
    """
    تجميع إشارات جميع المؤشرات والتصويت بالأغلبية.

    العائد: {
        'signal': Signal,        # الإشارة النهائية
        'confidence': float,     # نسبة الاتفاق (0-1)
        'results': list,         # نتائج كل مؤشر
        'buy_count': int,
        'sell_count': int,
        'neutral_count': int,
    }
    """
    results = [
        rsi_signal(df),
        macd_signal(df),
        bollinger_signal(df),
        ema_signal(df, fast=9, slow=21),
        ema_signal(df, fast=21, slow=50),
        adx_signal(df),
    ]

    buy_count     = sum(1 for r in results if r.signal == Signal.BUY)
    sell_count    = sum(1 for r in results if r.signal == Signal.SELL)
    neutral_count = sum(1 for r in results if r.signal == Signal.NEUTRAL)
    total         = len(results)

    if buy_count > sell_count and buy_count > neutral_count:
        final_signal = Signal.BUY
        confidence   = buy_count / total
    elif sell_count > buy_count and sell_count > neutral_count:
        final_signal = Signal.SELL
        confidence   = sell_count / total
    else:
        final_signal = Signal.NEUTRAL
        confidence   = neutral_count / total

    logger.info(
        f"📊 الإشارة النهائية: {final_signal.value} "
        f"(ثقة {confidence:.0%}) | "
        f"شراء:{buy_count} بيع:{sell_count} محايد:{neutral_count}"
    )

    return {
        "signal":        final_signal,
        "confidence":    round(confidence, 3),
        "results":       results,
        "buy_count":     buy_count,
        "sell_count":    sell_count,
        "neutral_count": neutral_count,
        "atr":           atr_value(df),
    }


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from data.collector import fetch_ohlcv

    df = fetch_ohlcv("EURUSD", "H1", n_bars=300, use_mt5=False)
    result = aggregate_signals(df)

    print(f"\n{'='*50}")
    print(f"الإشارة النهائية : {result['signal'].value}")
    print(f"نسبة الثقة       : {result['confidence']:.0%}")
    print(f"ATR              : {result['atr']}")
    print(f"\nتفاصيل المؤشرات:")
    for r in result["results"]:
        print(f"  {r.name:<15} → {r.signal.value:<10} | {r.note}")
