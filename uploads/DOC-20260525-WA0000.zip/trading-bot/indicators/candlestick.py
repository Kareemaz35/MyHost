# ============================================================
# indicators/candlestick.py — تحليل أنماط الشموع اليابانية
# ============================================================
# الدور:
#   اكتشاف وتفسير أنماط الشموع اليابانية الكلاسيكية.
#   كل نمط يُعطي إشارة محتملة مع قوة النمط وتفسيره.
#
# الأنماط المدعومة:
#   ذرية (1 شمعة): دوجي، مطرقة، نجمة ساقطة، ماروبوزو
#   ثنائية (2 شمعة): ابتلاع صاعد/هابط، هارامي
#   ثلاثية (3 شمعة): نجمة الصباح/المساء، جنود ثلاثة بيض
#
# المكتبات: pandas, numpy
# ============================================================

import pandas as pd
import numpy as np
from dataclasses import dataclass, field
from loguru import logger


@dataclass
class CandlePattern:
    """وصف نمط شمعة مُكتشَف."""
    name:      str            # اسم النمط بالعربي
    en_name:   str            # الاسم الإنجليزي
    bullish:   bool           # True=صاعد / False=هابط
    strength:  float          # قوة النمط 0-1
    candles:   int            # عدد الشموع في النمط
    note:      str = ""       # تفسير النمط


# ──────────────────────────────────────────────────────────
# أدوات مساعدة
# ──────────────────────────────────────────────────────────

def _candle_parts(df: pd.DataFrame, idx: int) -> dict:
    """استخراج مكوّنات شمعة بعينها."""
    row = df.iloc[idx]
    o, h, l, c = row["open"], row["high"], row["low"], row["close"]
    body         = abs(c - o)
    total_range  = h - l if h != l else 1e-10
    upper_shadow = h - max(o, c)
    lower_shadow = min(o, c) - l
    return {
        "open":         o,
        "high":         h,
        "low":          l,
        "close":        c,
        "body":         body,
        "range":        total_range,
        "upper_shadow": upper_shadow,
        "lower_shadow": lower_shadow,
        "body_ratio":   body / total_range,
        "is_bull":      c > o,
        "is_bear":      c < o,
    }


# ──────────────────────────────────────────────────────────
# أنماط الشمعة الواحدة
# ──────────────────────────────────────────────────────────

def detect_doji(c: dict) -> CandlePattern | None:
    """
    دوجي (Doji):
        جسم صغير جداً (< 10% من المدى الكلي).
        يعني التردد — لا مشترون ولا بائعون يسيطرون.
        قوي جداً عند مستويات دعم/مقاومة.
    """
    if c["body_ratio"] < 0.1:
        return CandlePattern(
            name="دوجي", en_name="Doji",
            bullish=False,   # محايد
            strength=0.6,
            candles=1,
            note="تردد في السوق — انتظر تأكيداً من الشمعة التالية"
        )
    return None


def detect_hammer(c: dict) -> CandlePattern | None:
    """
    مطرقة (Hammer) — صاعد:
        ظل سفلي طويل (> 2× الجسم)، جسم صغير في الأعلى.
        يعني أن البائعين دفعوا السعر للأسفل لكن المشترين عادوا.
        أقوى ما يكون بعد هبوط.
    """
    ls = c["lower_shadow"]
    us = c["upper_shadow"]
    body = c["body"]
    if body > 0 and ls > 2 * body and us < 0.3 * body:
        strength = min(1.0, ls / (body * 3))
        return CandlePattern(
            name="مطرقة", en_name="Hammer",
            bullish=True, strength=round(strength, 2),
            candles=1,
            note="إشارة انعكاس صاعد — قوية بعد هبوط"
        )
    return None


def detect_inverted_hammer(c: dict) -> CandlePattern | None:
    """
    مطرقة مقلوبة (Inverted Hammer) — صاعد محتمل:
        ظل علوي طويل، جسم صغير في الأسفل.
        تحتاج تأكيداً في الشمعة التالية.
    """
    us = c["upper_shadow"]
    ls = c["lower_shadow"]
    body = c["body"]
    if body > 0 and us > 2 * body and ls < 0.3 * body:
        return CandlePattern(
            name="مطرقة مقلوبة", en_name="Inverted Hammer",
            bullish=True, strength=0.5,
            candles=1,
            note="انعكاس صاعد محتمل — يحتاج تأكيداً"
        )
    return None


def detect_shooting_star(c: dict) -> CandlePattern | None:
    """
    نجمة ساقطة (Shooting Star) — هابط:
        ظل علوي طويل، جسم صغير في الأسفل.
        أقوى ما يكون بعد صعود (عكس المطرقة المقلوبة).
    """
    us = c["upper_shadow"]
    ls = c["lower_shadow"]
    body = c["body"]
    if body > 0 and us > 2 * body and ls < 0.3 * body:
        return CandlePattern(
            name="نجمة ساقطة", en_name="Shooting Star",
            bullish=False, strength=0.65,
            candles=1,
            note="إشارة انعكاس هابط — قوية بعد صعود"
        )
    return None


def detect_marubozu(c: dict) -> CandlePattern | None:
    """
    ماروبوزو (Marubozu) — قوي جداً:
        لا ظل أو ظل ضئيل جداً. جسم يمثل > 90% من المدى.
        يعني سيطرة كاملة للمشترين (صاعد) أو البائعين (هابط).
    """
    if c["body_ratio"] > 0.9:
        bull = c["is_bull"]
        return CandlePattern(
            name=f"ماروبوزو {'صاعد' if bull else 'هابط'}",
            en_name=f"{'Bull' if bull else 'Bear'} Marubozu",
            bullish=bull, strength=0.85,
            candles=1,
            note=f"{'مشترون' if bull else 'بائعون'} يسيطرون بالكامل على الشمعة"
        )
    return None


# ──────────────────────────────────────────────────────────
# أنماط الشمعتين
# ──────────────────────────────────────────────────────────

def detect_engulfing(prev: dict, curr: dict) -> CandlePattern | None:
    """
    الابتلاع (Engulfing):
        - صاعد: شمعة هابطة ثم صاعدة أكبر منها تماماً
        - هابط: شمعة صاعدة ثم هابطة أكبر منها تماماً
        يعني انعكاس حاد في السيطرة.
    """
    # ابتلاع صاعد
    if (prev["is_bear"] and curr["is_bull"] and
            curr["open"]  < prev["close"] and
            curr["close"] > prev["open"]):
        size_ratio = curr["body"] / max(prev["body"], 1e-10)
        return CandlePattern(
            name="ابتلاع صاعد", en_name="Bullish Engulfing",
            bullish=True, strength=min(1.0, 0.6 + size_ratio * 0.1),
            candles=2,
            note="انعكاس صاعد قوي — المشترون ابتلعوا البائعين"
        )
    # ابتلاع هابط
    if (prev["is_bull"] and curr["is_bear"] and
            curr["open"]  > prev["close"] and
            curr["close"] < prev["open"]):
        size_ratio = curr["body"] / max(prev["body"], 1e-10)
        return CandlePattern(
            name="ابتلاع هابط", en_name="Bearish Engulfing",
            bullish=False, strength=min(1.0, 0.6 + size_ratio * 0.1),
            candles=2,
            note="انعكاس هابط قوي — البائعون ابتلعوا المشترين"
        )
    return None


def detect_harami(prev: dict, curr: dict) -> CandlePattern | None:
    """
    هارامي (Harami) — صاعد/هابط:
        شمعة كبيرة تتبعها شمعة أصغر تقع بالكامل داخل جسم الأولى.
        يعني تراجع الزخم — انعكاس محتمل.
    """
    if (curr["open"] > min(prev["open"], prev["close"]) and
            curr["close"] < max(prev["open"], prev["close"]) and
            curr["body"] < 0.5 * prev["body"]):
        bull = prev["is_bear"]  # هارامي صاعد بعد شمعة هابطة
        return CandlePattern(
            name=f"هارامي {'صاعد' if bull else 'هابط'}",
            en_name=f"{'Bullish' if bull else 'Bearish'} Harami",
            bullish=bull, strength=0.5,
            candles=2,
            note="تراجع زخم — انعكاس محتمل (يحتاج تأكيداً)"
        )
    return None


# ──────────────────────────────────────────────────────────
# أنماط الثلاث شموع
# ──────────────────────────────────────────────────────────

def detect_morning_star(c1: dict, c2: dict, c3: dict) -> CandlePattern | None:
    """
    نجمة الصباح (Morning Star) — صاعد قوي:
        1. شمعة هابطة كبيرة
        2. شمعة صغيرة (دوجي أو جسم صغير) تفجوة للأسفل
        3. شمعة صاعدة كبيرة تغلق فوق منتصف الشمعة الأولى
    """
    if (c1["is_bear"] and c1["body_ratio"] > 0.5 and
            c2["body_ratio"] < 0.3 and
            c3["is_bull"] and c3["body_ratio"] > 0.5 and
            c3["close"] > (c1["open"] + c1["close"]) / 2):
        return CandlePattern(
            name="نجمة الصباح", en_name="Morning Star",
            bullish=True, strength=0.8,
            candles=3,
            note="نمط انعكاس صاعد قوي جداً — فرصة شراء"
        )
    return None


def detect_evening_star(c1: dict, c2: dict, c3: dict) -> CandlePattern | None:
    """
    نجمة المساء (Evening Star) — هابط قوي:
        عكس نجمة الصباح تماماً.
        1. شمعة صاعدة كبيرة
        2. شمعة صغيرة
        3. شمعة هابطة كبيرة
    """
    if (c1["is_bull"] and c1["body_ratio"] > 0.5 and
            c2["body_ratio"] < 0.3 and
            c3["is_bear"] and c3["body_ratio"] > 0.5 and
            c3["close"] < (c1["open"] + c1["close"]) / 2):
        return CandlePattern(
            name="نجمة المساء", en_name="Evening Star",
            bullish=False, strength=0.8,
            candles=3,
            note="نمط انعكاس هابط قوي جداً — فرصة بيع"
        )
    return None


def detect_three_white_soldiers(c1: dict, c2: dict, c3: dict) -> CandlePattern | None:
    """
    ثلاثة جنود بيض (Three White Soldiers) — صاعد قوي:
        ثلاث شموع خضراء متتالية ذات أجسام كبيرة،
        كل منها تغلق أعلى من السابقة.
    """
    if (c1["is_bull"] and c2["is_bull"] and c3["is_bull"] and
            c1["body_ratio"] > 0.6 and c2["body_ratio"] > 0.6 and c3["body_ratio"] > 0.6 and
            c2["close"] > c1["close"] and c3["close"] > c2["close"]):
        return CandlePattern(
            name="ثلاثة جنود بيض", en_name="Three White Soldiers",
            bullish=True, strength=0.85,
            candles=3,
            note="صعود قوي ومستمر — اتجاه صاعد يتشكل"
        )
    return None


# ──────────────────────────────────────────────────────────
# المُكتشِف الرئيسي
# ──────────────────────────────────────────────────────────

def detect_patterns(df: pd.DataFrame) -> list[CandlePattern]:
    """
    فحص آخر 3 شموع في DataFrame واكتشاف جميع الأنماط.

    العائد: قائمة بالأنماط المُكتشَفة (قد تكون فارغة)
    """
    if len(df) < 3:
        logger.warning("البيانات أقل من 3 شموع — لا يمكن الكشف عن الأنماط")
        return []

    c3 = _candle_parts(df, -1)   # الأحدث
    c2 = _candle_parts(df, -2)
    c1 = _candle_parts(df, -3)

    patterns = []

    # أنماط الشمعة الواحدة (آخر شمعة فقط)
    for fn in [detect_doji, detect_hammer, detect_inverted_hammer,
               detect_shooting_star, detect_marubozu]:
        p = fn(c3)
        if p:
            patterns.append(p)

    # أنماط الشمعتين
    for fn in [detect_engulfing, detect_harami]:
        p = fn(c2, c3)
        if p:
            patterns.append(p)

    # أنماط الثلاث شموع
    for fn in [detect_morning_star, detect_evening_star, detect_three_white_soldiers]:
        p = fn(c1, c2, c3)
        if p:
            patterns.append(p)

    if patterns:
        logger.info(f"🕯️ أنماط مُكتشَفة: {[p.name for p in patterns]}")
    else:
        logger.debug("لا توجد أنماط شموع واضحة في آخر 3 شموع")

    return patterns


def patterns_summary(patterns: list[CandlePattern]) -> dict:
    """
    ملخّص الأنماط المُكتشَفة:
    العائد: {'bias': 'bull'|'bear'|'neutral', 'strength': float, 'list': [...]}
    """
    if not patterns:
        return {"bias": "neutral", "strength": 0.0, "list": []}

    bull_score = sum(p.strength for p in patterns if p.bullish)
    bear_score = sum(p.strength for p in patterns if not p.bullish)

    if bull_score > bear_score:
        bias = "bull"
        strength = bull_score / len(patterns)
    elif bear_score > bull_score:
        bias = "bear"
        strength = bear_score / len(patterns)
    else:
        bias = "neutral"
        strength = 0.0

    return {
        "bias":     bias,
        "strength": round(strength, 3),
        "list":     [{"name": p.name, "bullish": p.bullish, "note": p.note} for p in patterns],
    }


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from data.collector import fetch_ohlcv

    df = fetch_ohlcv("XAUUSD", "H1", n_bars=100, use_mt5=False)
    found = detect_patterns(df)
    summary = patterns_summary(found)

    print(f"\n{'='*50}")
    print(f"تحيّز الأنماط: {summary['bias']} | القوة: {summary['strength']:.0%}")
    if found:
        for p in found:
            print(f"  🕯️ {p.name} ({p.en_name}) — {'صاعد' if p.bullish else 'هابط'}")
            print(f"     {p.note}")
    else:
        print("  لا توجد أنماط مُكتشَفة")
