# ============================================================
# data/preprocessor.py — معالجة البيانات وهندسة الخصائص
# ============================================================
# الدور:
#   تنظيف بيانات OHLCV وإضافة جميع الخصائص (Features) اللازمة
#   لتدريب نموذج الذكاء الاصطناعي. هذا الملف هو "مطبخ"
#   البيانات — ما يخرج منه يذهب مباشرة للنموذج.
#
# الخصائص المُضافة:
#   - المؤشرات الفنية (RSI, MACD, BB, ATR...)
#   - أنماط الشموع (مطرقة، ابتلاع، دوجي...)
#   - خصائص السعر المشتقة (تغيّر، نسبة الجسم...)
#   - خصائص الوقت (ساعة، يوم الأسبوع...)
#   - تسمية الهدف (Target): هل ارتفع السعر في الشمعة التالية؟
#
# المكتبات: pandas, numpy, ta
# ============================================================

import pandas as pd
import numpy as np
from ta import momentum, trend, volatility, volume as vol_ind
from loguru import logger


# ──────────────────────────────────────────────────────────
# المؤشرات الفنية الأساسية
# ──────────────────────────────────────────────────────────

def add_technical_indicators(df: pd.DataFrame) -> pd.DataFrame:
    """
    إضافة مجموعة شاملة من المؤشرات الفنية إلى DataFrame.

    المؤشرات المضافة:
        RSI(14)     — مؤشر القوة النسبية
        MACD        — تقارب/تباعد المتوسطات المتحركة
        BB_upper/lower/mid — بولنجر باندز
        ATR(14)     — متوسط المدى الحقيقي (قياس التذبذب)
        EMA9/21/50  — المتوسطات المتحركة الأسية
        Stoch(14)   — مذبذب ستوكاستيك
        CCI(20)     — مؤشر قناة السلعة
        ADX(14)     — مؤشر قوة الاتجاه
        OBV         — حجم الرصيد
        Williams%R  — ويليامز %R
    """
    close = df["close"]
    high  = df["high"]
    low   = df["low"]
    vol   = df.get("volume", pd.Series(np.ones(len(df)), index=df.index))

    # ── RSI ─────────────────────────────────────────────
    df["rsi_14"] = momentum.RSIIndicator(close, window=14).rsi()

    # ── MACD ────────────────────────────────────────────
    macd_obj = trend.MACD(close, window_slow=26, window_fast=12, window_sign=9)
    df["macd"]        = macd_obj.macd()
    df["macd_signal"] = macd_obj.macd_signal()
    df["macd_diff"]   = macd_obj.macd_diff()   # الهيستوغرام

    # ── Bollinger Bands ──────────────────────────────────
    bb = volatility.BollingerBands(close, window=20, window_dev=2)
    df["bb_upper"]   = bb.bollinger_hband()
    df["bb_lower"]   = bb.bollinger_lband()
    df["bb_mid"]     = bb.bollinger_mavg()
    df["bb_width"]   = (df["bb_upper"] - df["bb_lower"]) / df["bb_mid"]
    df["bb_pct"]     = bb.bollinger_pband()    # موضع السعر داخل النطاق (0-1)

    # ── ATR ─────────────────────────────────────────────
    df["atr_14"] = volatility.AverageTrueRange(high, low, close, window=14).average_true_range()

    # ── EMAs ────────────────────────────────────────────
    df["ema_9"]  = trend.EMAIndicator(close, window=9).ema_indicator()
    df["ema_21"] = trend.EMAIndicator(close, window=21).ema_indicator()
    df["ema_50"] = trend.EMAIndicator(close, window=50).ema_indicator()
    df["ema_200"]= trend.EMAIndicator(close, window=200).ema_indicator()

    # ── Stochastic ──────────────────────────────────────
    stoch = momentum.StochasticOscillator(high, low, close, window=14, smooth_window=3)
    df["stoch_k"] = stoch.stoch()
    df["stoch_d"] = stoch.stoch_signal()

    # ── CCI ─────────────────────────────────────────────
    df["cci_20"] = trend.CCIIndicator(high, low, close, window=20).cci()

    # ── ADX ─────────────────────────────────────────────
    adx = trend.ADXIndicator(high, low, close, window=14)
    df["adx"]    = adx.adx()
    df["di_pos"] = adx.adx_pos()
    df["di_neg"] = adx.adx_neg()

    # ── OBV ─────────────────────────────────────────────
    df["obv"] = vol_ind.OnBalanceVolumeIndicator(close, vol).on_balance_volume()

    # ── Williams %R ─────────────────────────────────────
    df["willr_14"] = momentum.WilliamsRIndicator(high, low, close, lbp=14).williams_r()

    return df


# ──────────────────────────────────────────────────────────
# خصائص السعر المشتقة
# ──────────────────────────────────────────────────────────

def add_price_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    إضافة خصائص مشتقة من OHLCV:
        - نسبة جسم الشمعة    (body_ratio)
        - اتجاه الشمعة        (candle_dir: +1 صاعدة / -1 هابطة)
        - تغيّر السعر (%)     (pct_change_1)
        - نسبة الظل العلوي/السفلي
        - فجوة الافتتاح       (gap)
    """
    o, h, l, c = df["open"], df["high"], df["low"], df["close"]

    body         = abs(c - o)
    candle_range = h - l
    candle_range = candle_range.replace(0, np.nan)   # تجنب القسمة على صفر

    df["body_ratio"]        = body / candle_range
    df["candle_dir"]        = np.where(c >= o, 1, -1)
    df["upper_shadow_ratio"]= (h - c.where(c > o, o)) / candle_range
    df["lower_shadow_ratio"]= (c.where(c < o, o) - l) / candle_range

    df["pct_change_1"] = c.pct_change(1)
    df["pct_change_3"] = c.pct_change(3)
    df["pct_change_5"] = c.pct_change(5)

    # فجوة الافتتاح عن إغلاق الشمعة السابقة
    df["gap"] = o - c.shift(1)

    # قرب السعر من أعلى/أدنى نطاق
    rolling_h = h.rolling(20).max()
    rolling_l = l.rolling(20).min()
    df["dist_high_20"] = (rolling_h - c) / c
    df["dist_low_20"]  = (c - rolling_l) / c

    return df


# ──────────────────────────────────────────────────────────
# خصائص الوقت
# ──────────────────────────────────────────────────────────

def add_time_features(df: pd.DataFrame) -> pd.DataFrame:
    """
    استخراج خصائص الوقت من الفهرس (index).
    مفيدة لأن السوق يتصرف بشكل مختلف في ساعات/أيام مختلفة.
    """
    idx = df.index

    if hasattr(idx, "hour"):
        df["hour"]       = idx.hour
        df["day_of_week"]= idx.dayofweek   # 0=الاثنين ... 4=الجمعة
        df["is_london"]  = ((idx.hour >= 8)  & (idx.hour < 17)).astype(int)
        df["is_ny"]      = ((idx.hour >= 13) & (idx.hour < 22)).astype(int)
        df["is_overlap"] = ((idx.hour >= 13) & (idx.hour < 17)).astype(int)

    return df


# ──────────────────────────────────────────────────────────
# أنماط الشموع اليابانية (مبسّطة)
# ──────────────────────────────────────────────────────────

def add_candlestick_patterns(df: pd.DataFrame) -> pd.DataFrame:
    """
    اكتشاف أنماط الشموع الكلاسيكية وإضافتها كأعمدة ثنائية (0/1).

    الأنماط:
        doji          — دوجي
        hammer        — مطرقة
        shooting_star — نجمة ساقطة
        engulfing_bull— ابتلاع صاعد
        engulfing_bear— ابتلاع هابط
        morning_star  — نجمة الصباح (3 شموع)
    """
    o, h, l, c = df["open"], df["high"], df["low"], df["close"]
    body  = abs(c - o)
    rng   = (h - l).replace(0, np.nan)

    # ── دوجي: جسم صغير جداً ─────────────────────────────
    df["doji"] = (body / rng < 0.1).astype(int)

    # ── مطرقة: ظل سفلي طويل، جسم صغير في الأعلى ─────────
    lower_shadow = (o.where(o < c, c)) - l
    df["hammer"] = (
        (lower_shadow > 2 * body) &
        (body / rng < 0.4) &
        ((h - o.where(o > c, c)) < 0.1 * rng)
    ).astype(int)

    # ── نجمة ساقطة: ظل علوي طويل ──────────────────────────
    upper_shadow = h - (c.where(c > o, o))
    df["shooting_star"] = (
        (upper_shadow > 2 * body) &
        (body / rng < 0.4) &
        ((o.where(o < c, c) - l) < 0.1 * rng)
    ).astype(int)

    # ── ابتلاع صاعد: شمعة حمراء ثم شمعة خضراء أكبر ───────
    prev_bear = (c.shift(1) < o.shift(1))
    curr_bull = (c > o)
    df["engulfing_bull"] = (
        prev_bear & curr_bull &
        (o < c.shift(1)) & (c > o.shift(1))
    ).astype(int)

    # ── ابتلاع هابط ──────────────────────────────────────
    prev_bull = (c.shift(1) > o.shift(1))
    curr_bear = (c < o)
    df["engulfing_bear"] = (
        prev_bull & curr_bear &
        (o > c.shift(1)) & (c < o.shift(1))
    ).astype(int)

    return df


# ──────────────────────────────────────────────────────────
# إنشاء عمود الهدف (Target)
# ──────────────────────────────────────────────────────────

def add_target(
    df: pd.DataFrame,
    lookahead: int = 1,
    threshold: float = 0.0001,
) -> pd.DataFrame:
    """
    إنشاء عمود الهدف للنموذج.

    المنطق:
        إذا ارتفع إغلاق الشمعة التالية عن الحالية بنسبة >= threshold
        → target = 1 (شراء)
        وإلا
        → target = 0 (لا شراء)

    المعاملات:
        lookahead — كم شمعة للأمام ننظر
        threshold — الحد الأدنى للحركة لاعتبارها صفقة
    """
    future_close = df["close"].shift(-lookahead)
    df["target"] = (
        (future_close - df["close"]) / df["close"] >= threshold
    ).astype(int)

    # حذف الصفوف الأخيرة التي ليس لها هدف
    df = df.iloc[:-lookahead]
    return df


# ──────────────────────────────────────────────────────────
# الدالة الرئيسية: معالجة شاملة
# ──────────────────────────────────────────────────────────

def preprocess(
    df: pd.DataFrame,
    add_target_col: bool = True,
    lookahead: int = 1,
) -> pd.DataFrame:
    """
    معالجة شاملة لـ DataFrame خام من OHLCV.

    الخطوات بالترتيب:
        1. التحقق من البيانات
        2. إضافة المؤشرات الفنية
        3. إضافة خصائص السعر
        4. إضافة خصائص الوقت
        5. إضافة أنماط الشموع
        6. إضافة عمود الهدف (اختياري)
        7. حذف القيم الناقصة

    العائد: DataFrame غني بالخصائص جاهز للنموذج
    """
    required = {"open", "high", "low", "close"}
    if not required.issubset(df.columns):
        raise ValueError(f"البيانات تفتقر إلى أعمدة: {required - set(df.columns)}")

    logger.info(f"🔧 بدء المعالجة | الصفوف: {len(df)}")

    df = df.copy()
    df = add_technical_indicators(df)
    df = add_price_features(df)
    df = add_time_features(df)
    df = add_candlestick_patterns(df)

    if add_target_col:
        df = add_target(df, lookahead=lookahead)

    initial_len = len(df)
    df.dropna(inplace=True)
    dropped = initial_len - len(df)

    logger.info(
        f"✅ المعالجة اكتملت | الصفوف: {len(df)} "
        f"(تم حذف {dropped} صف بقيم ناقصة)"
    )
    return df


def get_feature_columns(df: pd.DataFrame) -> list[str]:
    """
    إرجاع قائمة بأسماء أعمدة الخصائص (باستثناء OHLCV والهدف).
    هذه هي الأعمدة التي يستخدمها النموذج فعلاً.
    """
    exclude = {"open", "high", "low", "close", "volume", "spread", "target"}
    return [c for c in df.columns if c not in exclude]


# ──────────────────────────────────────────────────────────
# اختبار سريع
# ──────────────────────────────────────────────────────────

if __name__ == "__main__":
    import sys, os
    sys.path.append(os.path.dirname(os.path.dirname(os.path.abspath(__file__))))
    from data.collector import fetch_ohlcv

    df_raw = fetch_ohlcv("EURUSD", "H1", n_bars=500, use_mt5=False)
    df_proc = preprocess(df_raw)
    features = get_feature_columns(df_proc)

    print(f"\nعدد الخصائص: {len(features)}")
    print("أول 10 خصائص:", features[:10])
    print(df_proc[features[:5]].tail())
