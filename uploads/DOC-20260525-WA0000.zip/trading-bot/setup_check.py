# ============================================================
# setup_check.py — فحص شامل للتأكد أن كل شيء جاهز
# ============================================================
# شغّل هذا الملف أولاً قبل أي شيء:
#   python setup_check.py
# سيخبرك بالضبط ماذا يعمل وما الذي ينقصك
# ============================================================

import sys
import os

print("\n" + "="*60)
print("  🔍 فحص إعداد روبوت التداول")
print("="*60 + "\n")

errors   = []
warnings = []
ok       = []

# ──────────────────────────────────────────────────────────
# 1. إصدار Python
# ──────────────────────────────────────────────────────────
print("📌 فحص Python...")
version = sys.version_info
if version.major == 3 and version.minor >= 10:
    ok.append(f"Python {version.major}.{version.minor}.{version.micro} ✅")
else:
    errors.append(f"Python {version.major}.{version.minor} قديم — يلزم 3.10 أو أحدث")
print(f"   Python {version.major}.{version.minor}.{version.micro}")

# ──────────────────────────────────────────────────────────
# 2. المكتبات الأساسية
# ──────────────────────────────────────────────────────────
print("\n📌 فحص المكتبات...")

required_libs = {
    "pandas":       "pandas",
    "numpy":        "numpy",
    "ta":           "ta",
    "sklearn":      "scikit-learn",
    "xgboost":      "xgboost",
    "joblib":       "joblib",
    "requests":     "requests",
    "feedparser":   "feedparser",
    "dotenv":       "python-dotenv",
    "schedule":     "schedule",
    "loguru":       "loguru",
    "aiohttp":      "aiohttp",
    "matplotlib":   "matplotlib",
    "yfinance":     "yfinance",
}

optional_libs = {
    "MetaTrader5": "MetaTrader5 (Windows فقط)",
    "transformers":"transformers (تحليل الأخبار)",
    "torch":       "torch (تحليل الأخبار)",
    "telegram":    "python-telegram-bot",
}

for import_name, pip_name in required_libs.items():
    try:
        __import__(import_name)
        print(f"   ✅ {pip_name}")
        ok.append(pip_name)
    except ImportError:
        print(f"   ❌ {pip_name}  ← pip install {pip_name}")
        errors.append(f"مكتبة مفقودة: {pip_name}")

print("\n📌 فحص المكتبات الاختيارية...")
for import_name, label in optional_libs.items():
    try:
        __import__(import_name)
        print(f"   ✅ {label}")
        ok.append(label)
    except ImportError:
        print(f"   ⚠️ {label}  (اختياري)")
        warnings.append(f"{label} غير مثبّت")

# ──────────────────────────────────────────────────────────
# 3. ملف .env
# ──────────────────────────────────────────────────────────
print("\n📌 فحص ملف .env...")

env_path = os.path.join(os.path.dirname(__file__), ".env")
if os.path.exists(env_path):
    print("   ✅ ملف .env موجود")
    ok.append("ملف .env")

    from dotenv import load_dotenv
    load_dotenv(env_path)

    mt5_login = os.getenv("MT5_LOGIN", "0")
    tg_token  = os.getenv("TELEGRAM_TOKEN", "")
    tg_chat   = os.getenv("TELEGRAM_CHAT_ID", "")
    news_key  = os.getenv("NEWS_API_KEY", "")

    if mt5_login and mt5_login != "0":
        print(f"   ✅ MT5_LOGIN مُعيَّن ({mt5_login[:4]}...)")
        ok.append("MT5_LOGIN")
    else:
        print("   ⚠️ MT5_LOGIN غير مُعيَّن — ستعمل مع Yahoo Finance")
        warnings.append("MT5_LOGIN غير مُعيَّن")

    if tg_token:
        print(f"   ✅ TELEGRAM_TOKEN مُعيَّن ({tg_token[:10]}...)")
        ok.append("TELEGRAM_TOKEN")
    else:
        print("   ❌ TELEGRAM_TOKEN غير مُعيَّن — إشعارات تيليجرام لن تعمل")
        errors.append("TELEGRAM_TOKEN مفقود في .env")

    if tg_chat:
        print(f"   ✅ TELEGRAM_CHAT_ID مُعيَّن ({tg_chat})")
        ok.append("TELEGRAM_CHAT_ID")
    else:
        print("   ❌ TELEGRAM_CHAT_ID غير مُعيَّن")
        errors.append("TELEGRAM_CHAT_ID مفقود في .env")

    if news_key:
        print(f"   ✅ NEWS_API_KEY مُعيَّن")
        ok.append("NEWS_API_KEY")
    else:
        print("   ⚠️ NEWS_API_KEY غير مُعيَّن — الأخبار ستعمل من RSS فقط")
        warnings.append("NEWS_API_KEY غير مُعيَّن (اختياري)")
else:
    print("   ❌ ملف .env غير موجود!")
    print("   انسخ .env.example وسمّه .env ثم عبئ القيم")
    errors.append("ملف .env مفقود — انسخ .env.example")

# ──────────────────────────────────────────────────────────
# 4. اختبار جلب البيانات من Yahoo
# ──────────────────────────────────────────────────────────
print("\n📌 اختبار جلب البيانات (Yahoo Finance)...")
try:
    import yfinance as yf
    ticker = yf.Ticker("EURUSD=X")
    df = ticker.history(period="5d", interval="1h")
    if not df.empty:
        print(f"   ✅ تم جلب {len(df)} شمعة EURUSD بنجاح")
        ok.append("Yahoo Finance")
    else:
        print("   ⚠️ Yahoo أعاد بيانات فارغة (تحقق من الاتصال)")
        warnings.append("Yahoo Finance: بيانات فارغة")
except Exception as e:
    print(f"   ❌ فشل جلب البيانات: {e}")
    errors.append("Yahoo Finance: فشل الجلب")

# ──────────────────────────────────────────────────────────
# 5. اختبار اتصال تيليجرام
# ──────────────────────────────────────────────────────────
print("\n📌 اختبار اتصال تيليجرام...")
tg_token = os.getenv("TELEGRAM_TOKEN", "")
if tg_token:
    try:
        import requests
        r = requests.get(
            f"https://api.telegram.org/bot{tg_token}/getMe",
            timeout=8
        )
        data = r.json()
        if data.get("ok"):
            bot_name = data["result"]["first_name"]
            print(f"   ✅ البوت متصل: {bot_name}")
            ok.append(f"تيليجرام البوت: {bot_name}")
        else:
            print(f"   ❌ TOKEN خاطئ: {data.get('description')}")
            errors.append("TELEGRAM_TOKEN خاطئ أو منتهي")
    except Exception as e:
        print(f"   ❌ لا يمكن الاتصال بتيليجرام: {e}")
        errors.append("تيليجرام: لا يوجد اتصال إنترنت")
else:
    print("   ⚠️ تخطي (لا يوجد TELEGRAM_TOKEN)")

# ──────────────────────────────────────────────────────────
# 6. اختبار MetaTrader 5
# ──────────────────────────────────────────────────────────
print("\n📌 اختبار MetaTrader 5...")
try:
    import MetaTrader5 as mt5
    if mt5.initialize():
        info = mt5.account_info()
        if info:
            print(f"   ✅ MT5 متصل | حساب: {info.login} | رصيد: {info.balance} {info.currency}")
            ok.append("MetaTrader5")
        else:
            print("   ⚠️ MT5 يعمل لكن لم يسجل الدخول بعد (شغّله وسجّل الدخول أولاً)")
            warnings.append("MT5: سجّل الدخول أولاً")
        mt5.shutdown()
    else:
        print("   ⚠️ MT5 غير مفتوح — افتحه من سطح المكتب أولاً")
        warnings.append("MT5: غير مفتوح")
except ImportError:
    print("   ⚠️ مكتبة MT5 غير مثبّتة (Windows فقط)")
    warnings.append("MT5: غير متاح (يعمل على Windows فقط)")

# ──────────────────────────────────────────────────────────
# 7. التحقق من وجود النموذج المدرّب
# ──────────────────────────────────────────────────────────
print("\n📌 فحص النموذج المدرّب...")
model_path = os.path.join(os.path.dirname(__file__), "model", "saved_model.pkl")
if os.path.exists(model_path):
    size_mb = os.path.getsize(model_path) / (1024*1024)
    print(f"   ✅ النموذج موجود ({size_mb:.1f} MB)")
    ok.append("نموذج AI")
else:
    print("   ⚠️ النموذج غير موجود — شغّل أولاً:")
    print("      python main.py --train-only")
    warnings.append("النموذج غير مدرّب — شغّل: python main.py --train-only")

# ──────────────────────────────────────────────────────────
# الملخص النهائي
# ──────────────────────────────────────────────────────────
print("\n" + "="*60)
print("  📊 ملخص الفحص")
print("="*60)
print(f"\n  ✅ يعمل بشكل صحيح : {len(ok)}")
print(f"  ⚠️ تحذيرات (اختيارية): {len(warnings)}")
print(f"  ❌ أخطاء (يجب الإصلاح): {len(errors)}")

if errors:
    print("\n  ❌ الأخطاء التي يجب إصلاحها:")
    for e in errors:
        print(f"     • {e}")

if warnings:
    print("\n  ⚠️ تحذيرات (يمكن المتابعة بدونها):")
    for w in warnings:
        print(f"     • {w}")

print()
if not errors:
    print("  🎉 الإعداد صحيح! يمكنك تشغيل الروبوت:")
    print("     python main.py --demo      ← للاختبار")
    print("     python main.py             ← للتداول الحقيقي")
else:
    print("  ⛔ أصلح الأخطاء أعلاه ثم أعد الفحص")

print("\n" + "="*60 + "\n")
